## 所見への対応表

| 所見 | 状態 | 根拠 |
|---|---|---|
| 公開経路 4 nodeid の共有 repo reader 登録漏れ | partial | 登録と golden の拡張済み。指定 harness は hold 拒否でテスト開始前に停止 |

## 直した内容

`orchestrator/tests/` 以下の 2 ファイル、計 12 行追加です。

- `conftest.py:422`：`_REAL_REPO_NODE_INVENTORY` に指定 4 nodeid を追加。
- `conftest.py:595`：`_REAL_REPO_BOTH_READER_NODES` に同じ 4 nodeid を追加。
- `test_real_repo_serialization.py:194`：`_REAL_REPO_CLASSIFIED_NODES_GOLDEN` に同じ 4 nodeid を追加。

既存分類は変更せず、clone しない `test_freeze_allowlist_path_rejects_unselected_versioned_protocol` は未登録のままです。

## 引いた閉包

**直した箇所の検索：**

```bash
rg -n 'REAL_REPO_(NODE_INVENTORY|BOTH_READER_NODES|CLASSIFIED_NODES|RESOURCE_NODES|ACCESS_BY_NODE)|real_repo_priority' orchestrator tools --glob '*.py'
rg -n 'test_real_seal_protocol_to_floor_official_core_e2e|test_public_official_preflight_|test_freeze_allowlist_path_rejects_unselected_versioned_protocol' orchestrator tools --glob '*.py'
```

inventory と分類済み golden は **141→145**、両資源 reader は **64→68**。資源対象は **139→143** になります。

**検索したが修正不要と判断した箇所：**

- `_real_repo_access_golden()`：現物に独立した BOTH_READER golden はなく、分類済み集合と除外分類から `(read, read)` を導出する。
- collection・shard 検査：集合から件数を導出するため、固定総数の更新は不要。
- `test_real_repo_priority_order_is_literal_and_writers_follow_barrier`：現物は RW overlap・排他・締切・P→S 取得順の検査。nodeid 順序 literal はない。
- `34/37`、`17/9/26/29` の assertion：別の memo consumer 集合に対する件数であり変更不要。
- acceptance schedule・isolation・run-tests-shards の consumer：登録集合を参照するため変更不要。

件数・順序の検索 command：

```bash
rg -n 'priority_order_is_literal|assert len|== [0-9]{2,}' orchestrator/tests/test_real_repo_serialization.py
rg -n '\b(141|139|64|145|143|68)\b' orchestrator/tests/conftest.py orchestrator/tests/test_real_repo_serialization.py tools/acceptance_shards.py orchestrator/tests/test_acceptance_schedule_order.py orchestrator/tests/test_dev_waves_isolation_contract.py orchestrator/tests/test_run_tests_shards.py
```

## 実走結果

```bash
PYTHONPATH=. python3 orchestrator/tests/test_real_repo_serialization.py
```

- **rc=1**
- 実行完了 nodeid：**0**
- テスト pass **0** / fail **0**。harness 起動エラー **1**。
- 集計出力前に停止。stderr の末尾：

```text
orchestrator.tests.growth_test_holds.GrowthTestHoldBypassRefused: IZANAGI_GROWTH_HOLD_BYPASS_REFUSED_V1 {"node_id":"test_real_repo_serialization.py::*","release_env":"IZANAGI_RUN_GROWTH_HELD_TESTS","release_token":"explicit-user-command"}
```

`git diff --check` は rc=0 でした。

## 波及可能性の静的列挙

- 対象 4 テストは既存 collection hook により `(parent=read, ccbench=read)` と `real-repo` marker の対象になります。
- 既存 runtime hook の setup/call/teardown を覆う P/S reader lock の対象になります。
- shard の資源集合と conflict component に 4 nodeid が加わります。既存 suffix 処理も適用されます。
- `_protocol_binding_public_preflight` は各テスト内から呼ぶ helper であり、新しい共有 fixture consumer の追加はありません。
- acceptance schedule・isolation・shard consumer test の参照集合が拡張されます。production caller の変更はありません。

## 未実走・未確認

collection exact 照合、conftest の import 時検査、lock の実発火、対象 4 テスト本体、2 shard / 8 worker 受入は未確認です。**実装済み・未実走**として扱います。

## 総括

指定 4 nodeid を既存分類へ追加しました。  
変更は所有 2 ファイルの登録簿・golden の拡張だけです。  
件数・順序・consumer の閉包を検索し、追加修正は不要と判断しました。  
指定 harness は hold 拒否で停止したため、所見は `partial` です。  
hold 解除、所有外ファイルの編集、git add、commit は行っていません。