## 所見対応表

以下は静的判定です。pytest・変異走は実行していません。

参照略号：

- **C**＝[s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py)
- **T**＝[test_s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py)
- **F**＝[conftest.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/conftest.py)
- **R**＝[test_real_repo_serialization.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_real_repo_serialization.py)

| 所見／裁定 | 状態 | 現物根拠 |
|---|---|---|
| C-1 / D-1／裁定9 | **closed** | T:15484–15497 は実 official preflight の構成・strict 検証後に停止。T:15336–15337 も file 発行に進まないと明記。発行・再検証 C:7574–7582 は certificate と渡された protocol hash を使い、legacy path を再束縛しない。裁定9の反例は確認しなかった。 |
| C-2 / D-5／裁定13 | **closed（主張訂正）** | 裁定13が現物照合と親による時系列監査を明確に分離した。独立した fix 前後監査が成立した、という判定ではない。 |
| D-2／裁定10 | **partial** | M1/M2/M4 の重複した拒否理由は現物に残る。除外方針は正本にあるが、probe の実測・最終採否は未確認。さらに指定 spec の M5 は裁定10の再照準を未反映。 |
| D-3／裁定11 | **closed（静的閉包）** | F:422、595、R:194 に公開経路 nodeid が追加済み。分類と独立 golden は一致。件数・集合・順序 consumer の更新漏れは確認しなかった。lock 実発火は本レビューでは未検証。 |
| D-4／裁定12 | **closed（逐語一意性）** | 指定 spec の各 `old` は対象 C 全文にちょうど一箇所ある。ただし、一意であることと裁定10に適合することは別。M5 は後者が未充足。 |

**裁定9の検索。** 次を用いて識別子と固定 path literal を検索し、C の関数単位でも AST の `Name` を列挙した。

```bash
rg -n --hidden -g '!.git' '_FLOOR_PROTOCOL_REL|floor_protocol\.json' .
```

C 全文における識別子の文字列出現数は **16**。計数 command は次のとおり。

```python
s = Path("orchestrator/campaign/s8b_floor_campaign.py").read_text()
print(s.count("_FLOOR_PROTOCOL_REL"))
```

出現先は定義・固定集合、index/resolver、書き手、authority、preflight、core の preflight 引数構成。C:7526 は preflight **前**の fallback。別名の legacy anchor consumer も確認したが、発行後に selected protocol を legacy へ戻す反例は見つからなかった。C:5632、5642 の発行・再検証も固定 protocol path を読まない。

**裁定11の再計数。** 対象は canonical `file::function` の集合であり、parametrize 後の実行 node 数ではない。

| 対象集合 | 基底 `7e73d448e` | 現物 |
|---|---:|---:|
| `_REAL_REPO_NODE_INVENTORY` | 141 | 145 |
| `_REAL_REPO_CLASSIFIED_NODES_GOLDEN` | 141 | 145 |
| `_REAL_REPO_BOTH_READER_NODES` | 64 | 68 |
| inventory − local-only＝資源対象 | 139 | 143 |

計数は `python3 - <<'PY'` で、各版を次の方法で読み、AST のトップレベル `frozenset({...})` を `ast.literal_eval` して `len` を取った。

```python
source = (Path(file).read_text() if rev == "WORKTREE" else
          subprocess.check_output(["git", "show", rev + ":" + file], text=True))
# ast.parse(source).body の Assign → frozenset の引数を literal_eval
print(len(inventory), len(golden), len(both), len(inventory - local_only))
```

inventory と golden の集合一致、および分類除外集合から導出した BOTH-reader golden との一致も確認した。

閉包検索は次の識別子・数字・nodeid の各系列で実施した。

```bash
rg -l --hidden -g '!.git' -g '!output/**' \
 'REAL_REPO_(NODE_INVENTORY|BOTH_READER_NODES|CLASSIFIED_NODES|RESOURCE_NODES|ACCESS_BY_NODE)|real_repo_priority' .

rg -n '\b(141|139|64|145|143|68)\b' \
 orchestrator/tests/{conftest,test_real_repo_serialization,test_acceptance_schedule_order,test_dev_waves_isolation_contract,test_run_tests_shards}.py \
 tools/acceptance_shards.py

rg -l --hidden -g '!.git' -g '!output/**' \
 'test_real_seal_protocol_to_floor_official_core_e2e|test_public_official_preflight_|test_freeze_allowlist_path_rejects_unselected_versioned_protocol' .
```

fix 子の「不要」判断も妥当だった。

- R:304 の golden は分類済み集合と除外分類から導出する。
- R:1976 の歴史的な関数名に反し、本文は lock の重なり・排他・取得順を検査しており、全 nodeid の順序 literal はない。
- R:2505–2506、2622–2625 の固定件数は別の memo consumer 集合。
- acceptance schedule、isolation、shard consumer は登録集合を参照する。今回の公開 preflight helper はこれら memo consumer の追加に当たらない。

## 変異の単一理由性

P1/P2/N1/N2/N3 は依頼にある確定 nodeid の略号。予測は現行 hold と正常な基底 fixture を前提とし、負例内の対照実行も含む。

| 変異 | 予測赤集合 | 単一理由性・再照準 |
|---|---|---|
| **M1** authority record を渡さない | **{P1, N1, N2}** | **不成立。** T:15469 の path assertion が先に拒否。これを除いても T:15470、15478、および誤った legacy hash に対する C:5486 が残る。公開配線の検査として記録し、単一 hash gate の証拠から外す。 |
| **M2** legacy entry 削除 | **{P1, N1, N2}** | **不成立。** T:15470 の allowlist assertion の後にも C:5473 の namespace 集合不一致が残る。P2 は C:5325 が legacy entry を再設定する。現テストを維持した同趣旨の局所再照準では重複を除けないため、**冗長 gate として単独変異の証拠から外す**。 |
| **M3** validator を chain pattern 受理へ緩和 | **{N3}** | **直接 validator 呼出しへの帰属は成立。** T:15582 が例外を出さなくなる。後段の scan 枝は C:5473 の集合不一致でも拒否するため、その枝を同じ証拠に数えない。spec は versioned だけでなく `_CHAIN_RECORD_PATTERNS` 全体へ緩めることにも注意。 |
| **M4** resolved entry を capture の自己 hash にする | **{N1}** | **不成立。** drift 後の hash が入り T:15470 が先に赤。そこを除いても T:15488 の独立 digest assertion が拒否する。C:5486 自体は一致して通る。期待値出所の検査として記録し、**冗長 gate として単独変異の証拠から外す**。hash 比較へ再照準するなら M5 と重複する。 |
| **M5：指定 spec の現物** legacy iteration を `continue` | **{N2}** | **N2 の入力に対する hash 拒否への帰属は成立。** 注入 T:15474 は historical 比較 C:5281 後。legacy bytes は chain 分類されず、digest は期待 hash を使うため再拒否しない。ただしこの変異は phantom/file 検査 C:5481 と読取り C:5485 も飛ばし、裁定10の再照準と異なる。最小是正は裁定どおり比較条件だけを `False` にすること。 |
| **M6** selected を常に chain 分類 | **{P1, N1, N2, N3}** | 最初の拒否は C:5473。**P1 の scope gate 検査としては成立**。ただし変異全体を単一理由とするのは不可。N3 は T:15578 の正常系 scan で赤になり、scope 拒否を除いても返る非空 chain と `== {}` が衝突する。N1 の対照でも chain の実 drift hash が digest に入り T:15488 が拒否する。P1 に証拠範囲を限定し、それ以外の赤を単一 gate の独立証拠に加算しない。 |

**M5 の裁定案 `if False:` は単一理由になる。** 予測赤集合は **{N1, N2}**。両方とも C:5486 の同じ hash 比較を失い、期待した `FloorCampaignError` に代わって T:15497 の観測例外まで到達するためである。異なる入力が同じ gate の必要性を示すことは、過剰決定ではない。

この場合、T:15447 の対照用 AST anchor assertion は潜在的には壊れるが、各 node は最初の負例実行で既に失敗し、対照まで進まない。実際に到達する赤理由と、未到達の副作用は区別する。

逐語計数 command：

```python
spec = json.loads(Path(SPEC_PATH).read_text())
for mutation in spec["mutations"]:
    for replacement in mutation["replacements"]:
        text = Path(replacement["file"]).read_text()
        print(mutation["id"], text.count(replacement["old"]))
```

対象は各 replacement の指定 file 全文。結果は **M1～M6 がそれぞれ `1`**。開始行は順に C:7246、5318、5413、5325、5479、5464。

## 非帰属赤の検算

**収集有無で挙動が変わるコード上の機序は特定した。ただし、報告された赤そのものとの最終照合には traceback が不足する。**

R:2909–2913 は `test_p3_s4_loop` をテスト実行中に import し、その関数を直接呼ぶ。これに対して F:239–255 の autouse fixture は、setup 時点で `sys.modules` に存在する `orchestrator.campaign.site_policy` **だけ**について hostname と NQSV 観測を差し替える。

- 狭い選択で `site_policy` が setup 後に import されると、この差替えを受けない。
- `test_p3_s4_loop.py` を一緒に収集すると、同 file:40–62 の import が setup 前に `site_policy` をロードするため差替え対象になる。
- 内側関数は同 file:7075、7089 で `drive_iteration` を呼ぶ。production の `p3_s4_loop.py:2406` 付近は `do_build=False` の処理より先に site を解決し、`:138–144` が環境契約を選択・拒否する。
- `site_policy.py:72–77` は実 hostname を読む。ログイン判定は同 file:42–43。したがって遅延 import は実機環境をテストへ持ち込める。

一方、内側 module の autouse fixture `test_p3_s4_loop.py:84–87` は直接関数呼出しでは実行されず、他 file を収集しただけで wrapper に適用されるものでもない。これを改善の機序には数えない。

基底へ戻しても赤という提示実測は、**本 wave への非帰属**を支持する。全件収集は上記の遅延 import 条件を解消するため、「今回の全件収集では赤が消える」という説明とも整合する。ただし **「受入全走では必ず出ない」まで静的に保証したとは書けない**。今回の変更に帰属する受入全走の再現根拠は確認しなかった。

## 新たな所見

- **real / must-fix：指定 probe spec の M5 が裁定10と不一致。**  
  現物は C:5479 の loop skip を狙い、裁定の C:5486 `if False:` ではない。  
  **成果物影響：旧 spec の実測を裁定済み M5 の証拠として記録すると、期待赤集合と hash gate の証明範囲が誤記される。**

- **real / nit：M6 の期待範囲は P1 に閉じない。**  
  N3 の正常系 scan と負例の対照を含めた上表の集合で probe 結果を照合する必要がある。  
  **成果物影響：P1 だけを期待赤とすると、同じ変異による赤を非帰属扱いする記録になる。**

- **refuted：共有 reader 登録簿の件数・golden 更新漏れ。**  
  再計数と集合比較は fix 報告と一致。  
  **成果物影響：今回の公開経路 reader は既存の資源分類・shard 集合に反映されている。**

裁定パッケージ候補は確認しなかった。

## 総括

登録簿・golden の静的閉包と、指定 `old` の逐語一意性は閉じている。  
証拠上の未完は D-2 であり、指定 spec の M5 は裁定10に合わせる必要がある。  
M1/M2/M4 の赤を単一 hash gate の kill と数えてはいけない。  
M6 は P1 への帰属と、他 node の重複した拒否理由を分けて記録する。  
非帰属赤には import 時期と site fixture の具体的機序があるが、報告赤との traceback 照合は未完。  
書込み・テスト実行・commit は行っていない。