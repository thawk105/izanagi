## 所見

行番号の略記は次のとおりです。

- **C** = `orchestrator/campaign/s8b_floor_campaign.py`
- **T** = `orchestrator/tests/test_s8b_floor_campaign.py`
- **B** = 指定の `s1-brief.md`
- **P** = 指定の `s2-plan.md`
- **H** = `orchestrator/campaign/freeze_verification_hold.py`
- **D** = 指定の `rulings-d1936-items-11-15.md`

### 1. real・中：path validator の拒否条件は実際に緩む。「受理集合不変」は成立しない

**根拠:** P:22-23、P:35-41、B:74-79、B:91。現行の拒否は C:5407-5411、集合分類は C:5455-5469。

**再現の筋道:** 通常ファイルとして次の path を置き、その実 bytes の hash を allowlist に追加する。

```text
output/s8b-freeze/floor-protocols/<64桁hex>--<40桁hex>.json
```

現行は allowlist key が有界範囲外として拒否する。plan 適用後は命名規則に一致すれば validator を通り、allowlist 自身への掲載を理由に `bounded_actual` へ入り、実 hash が一致すれば通る。これは選択された versioned に限らず、呼び手が掲載した未選択 versioned にも成立する。

したがって、**この gate 単体の受理集合拡大は real**。B:79 の「検査を1本増やすだけ」という説明は、既存 entry の期待値変更と validator の緩和を数えていない。

ただし、この例だけでは production の不正 protocol 受理は証明できない。公開経路には C:7148 の resolver と C:984-1008 の別検査があり、そもそも同じファイルは従来も allowlist 外の chain として収容できた。

**最小の是正案:** B:79、B:91 を絶対的な集合不変の主張から訂正する。D:5-7 が認めた誤束縛の訂正による受理差分と、維持すべき bytes・系譜の拒否条件を分けて書く。規律2に関して、P:22-23 は「通すために既存拒否条件を外す」変更として明示的に審査対象へ残す。

### 2. refuted・重大度高の疑い：legacy の自己参照化だけで、任意の改竄が通る

**根拠:** P:21、P:72、C:5220-5228、C:5274-5280、C:5313-5347、C:5471-5482。

legacy entry **単独**は capture 時点の自己 hash なので、捕まえるのは capture 後から assert 読取り時までに残った bytes 差である。capture 前から存在する改竄、assert 前に元へ戻した一時的改変、最後の読取り後の改変は、この entry 単独では捕まえない。

しかし実 preflight が正常に返るには、必ず次が成立する。

```text
captured[legacy] == historical_protocol
```

C:5278 を回避して C:5347 に正常到達する分岐はない。先行検査の失敗は拒否であり、hold も historical 比較を飛ばさない。既存の T:11606-11619 は、capture 前の legacy 改変をこの比較で拒否する構成である。

**到達しない構成はある:** 非 official、resume、private core の `_floor_preflight_fn` 置換、`clean_scan_digest()` の直接呼出し。ただし、これらは元から実 preflight の legacy entry 構成を通らず、今回の自己 hash 化で新しく生じる抜け道ではない（C:7501-7517、T:875-878）。

**最小の是正案:** 「legacy entry が独立検証する」とは書かず、「historical 比較済み bytes を、その後の scan に束縛する」と書く。

`sha256(historical_protocol)` を期待値にしても、**現行の必須比較が残る限り受理条件は同じ**であり、実効的に強いとはいえない。権威の出所をコード上で明示する利点はある。P:70 の「versioned が過去に存在する保証がない」は journal の維持理由であって、legacy entry に historical hash を使わない理由にはならない。

### 3. refuted・重大度中の疑い：chain から bounded への移動で検査と digest 被覆が失われる

**根拠:** C:5443-5459、C:5471-5478、C:5517-5527、P:23、P:37-41。

chain 側の C:5459 は実 bytes の hash を**記録するだけ**で、独立期待値との一致は検査しない。選択 versioned の移動後も、共通の symlink・通常ファイル検査を通り、さらに supplied protocol 由来の期待 hash と比較される。

未選択 versioned は、production preflight が追加しない限り従来どおり `chain_records` に残る。resolver 時点の全 versioned 検査も C:964-1018 に残る。scan 時点での未選択ファイルの扱いは、従来と同じ実 hash の記録である。

**再現の筋道:** versioned を2件置いて1件を選択すると、選択分だけ bounded、残りは chain。両方とも C:5517 の和集合に入る。静的な同一 bytes を前提とすれば、移動による path/hash の欠落はない。

**最小の是正案:** 保証の喪失としては採らない。ただし「未選択分も scan 時に独立期待 hash で検証する」とは書かない。

### 4. real・中：「hold が結果を1 bitも変えない」は条件付きでしか真でない

**根拠:** P:20、B:80-82、C:5241-5248、C:5477-5482、H:14-37、H:68-92。

plan 適用後、hold が保留するのは **capture した resolved bytes と実行用 `protocol_sha256` の一致検査**。無条件側は **scan 時点の resolved bytes と同じ expected hash の一致**を要求する。legacy には別途 historical 比較と scan 比較が残る。

- bytes が capture から scan まで固定なら、不一致は `HELD=True` でも無条件側が拒否する。
- `HELD=False` なら同じ不一致を C:5245 で先に拒否する。
- capture 時には不一致だが scan 前に正しい bytes へ戻る時系列では、当該比較について `True` は通り得るが `False` は先に拒否する。
- marker と停止位置も同一ではない。H:86-90 は保留 marker を出力する。

**再現の筋道:** authority 検証後に resolved bytes を変え、preflight の capture 後・最初の scan 前に復元する。この読取り時点の差は、現在の2比較にも存在するため、新規欠陥とは扱わない。

**最小の是正案:** 成果物には次のように限定して書く。

> bytes が両読取り間で不変の fresh official 経路では、当該 hold の有無で最終受理可否は変わらない。停止位置・marker・変更を伴う時系列、および hold 全体の効力は証明対象外。

`HELD=False` は21件全体に作用するため、この局所読解から全体の挙動は結論できない。解除は提案しない。

### 5. refuted・重大度高の疑い：2負例は必ず先行 bytes gate に遮られる

**根拠:** P:92-105、C:984-988、C:7148-7173、C:7213-7217、C:5278、C:7511-7524。

実呼出し順は次のとおり。

```text
resolver の全件 scan
→ supplied bytes と resolver record の一致
→ authority 関数 return
→ core
→ preflight capture・historical 比較・allowlist return
→ official preflight の2回の clean scan
```

**resolved 負例:** 実 `_require_supplied_protocol_authority()` を呼ぶ wrapper が、その戻り値を得た後に書き換えれば、C:984 と C:7161 の両方より後に注入できる。現在の hold 下では C:5245 も先行拒否にならない。

**legacy 負例:** 実 preflight を呼ぶ wrapper が return 後に書き換えれば、C:5278 より後、C:7517 より前に注入できる。

**最小の是正案:** 注入位置は plan のとおり実現可能。ただし**帰属達成は未実測**として残す。先行する検索 gate は C:5506-5508 にあり、fixture 自体がここで赤なら対象 gate の実績には数えない。

また、対象比較を外す対照は C:5593 と C:5603 の**両 scan に適用**する必要がある。1回目だけ外すと2回目が拒否する。一定の改変を両 scan まで維持すれば、対象比較を外した際に独立した protocol 再 scan が必ず遮る、という呼出し順ではない。

### 6. real・中：実測1構成の値を、versioned 全構成の digest 説明に流用している

**根拠:** B:33、B:59-65、P:47-52、C:1002-1008、C:5517-5527。

B は測定時点を明示している。一方 P:49 は「resolved が versioned」という一般ケース欄に、特定の `2c8cf9be… → 261cec1c…` を置いている。コード上は versioned の導出で `contract_sha256` と `ccbench_pin` を置換するため、常に `ccbench_pin` 1 field 差とは限らない。

**再現の筋道:** 同じ pin で契約 hash が異なる versioned、または両 field が異なる versioned なら、brief の2 hash と1 field差は当てはまらない。

また、**resolved == legacy だけでは digest 不変は導けない**。必要なのは、同じ repository 列挙、同じ他ファイル・chain bytes、同じ allowlist 値、同じ schema と直列化、および両版で正常到達する入力という前提である。旧版の正常到達には legacy の実 bytes hash と expected の一致も必要となる。

**最小の是正案:** P:49 の具体値を「今回観測した構成」に限定し、一般説明では `H_legacy`・`H_resolved` を使う。P:50 の不変性は同一入力・正常到達・列挙不変を明記する。

## 裁定パッケージ候補

今回、指定された scope 外の層について、新たに real と確定できる所見はない。attempt registry、B2、共有 root、official 投入への実装提案は行わない。

## plan のどこを変えるべきか

1. **P:22-23／B:79・91:** path validator の局所的な受理拡大を認め、D1936 項11の許容差分と規律2の維持条件を分ける。
2. **P:21・72:** legacy の保証を「historical 検証＋capture 後の bytes 束縛」と明記する。historical hash 採用は可読性の選択であり、検査強化とは数えない。
3. **B:80-82／P:159:** hold の結論を、固定 bytes・当該比較・fresh official の受理可否に限定する。
4. **P:92-106:** 実関数 return 後の注入位置と、対象比較の除外を両 scan に適用する条件を明記する。
5. **P:49-50:** 実測値と一般式を分離し、digest 不変の前提を列挙する。

## 総括

最も明確な real は、「受理集合不変」という説明と path validator 緩和の矛盾である。  
legacy の自己 hash 化による全面的な恒真化は、必須 historical 比較が残るため refuted。  
chain 移動による被覆欠落、および負例が先行 bytes gate に必ず遮られるという疑いも refuted。  
hold の無効性と digest 不変性は、条件を省いたまま成果物に書けない。  
静的検査のみ実施した。実装・書込み・commit・pytest は行っておらず、負例の帰属実績は未確認。