## 所見

以下では `C`＝`orchestrator/campaign/s8b_floor_campaign.py`、`T`＝`orchestrator/tests/test_s8b_floor_campaign.py`、`B`＝`orchestrator/tests/test_s8b_protocol_builder.py` とします。行番号は指定 worktree の現物です。静的検査のみで、pytest・実装・commit は行っていません。

**real・中：新規 nodeid の duration 台帳登録が plan から抜けている。**

- 根拠：plan `s2-plan.md:84-94`、`orchestrator/tests/test_acceptance_schedule_order.py:660-713`、`docs/failures.md:23746-23784`。
- 再現の筋道：既存ファイルへの追加でも collection の分母が増える。台帳未登録の追加分は被覆の分子に入らず、既存の90%被覆 gate に影響する。F902 は既存ファイルへの追加でも再発したことを明記している。
- 最小是正：親の実走 JUnit から `tools/update_acceptance_duration_ledger.py --add-only` で登録する工程を追加する。現在の被覆率は未測定なので、「今回も必ず90%を割る」とまでは断定しない。
- `test_s8b_floor_campaign.py::` は同 producer の凍結 prefix 集合（`tools/update_acceptance_duration_ledger.py:21-30`）に含まれない。

**real・中：「既存テストへの影響の全列挙」が consumer 全体を覆っていない。**

- 根拠：plan `:108-127` に対し、`B:1606-1641`、`T:11743-11781,12115-12142`、`orchestrator/tests/test_s8b_ratified_freeze.py:1036-1048`、`orchestrator/tests/test_s8b_ratified_verify.py:2197-2216`。
- 再現の筋道：変更する chain 分類を直接検査する versioned protocol の正負例が別ファイルにある。固定集合を使う ratified fixture、実関数を保存して呼ぶ spy も、plan の10件には入っていない。
- 最小是正：下記 consumer 表を検証対象へ加える。これらすべての期待値を書き換える必要がある、という所見ではない。

**real・低：brief のアンカー表に範囲漏れと説明の混同がある。**

- 根拠と訂正は後掲の照合表。
- 特に `brief:47` の範囲には肝心の `protocol_sha256` 行が入らず、`brief:55` は先頭テストの定義と末尾テストを取りこぼす。
- 最小是正：brief のアンカーを訂正する。plan は journal の実行を `C:5293` と捉えており、この誤りは継承していない。
- 「変更面は1 file 1関数」（`brief:110` 付近）の説明も、plan 自身の wrapper・core・validator・scan 変更と一致しない。複数関数への配線変更として記述する。

**refuted・既存期待値の強制置換：plan の「0件」を否定する具体的破れは確認できなかった。**

- 根拠：`T:11538-11718`、`T:11205-11379`、`B:1617-1641`。
- legacy 既定、固定集合の既存メンバー、未選択 versioned の chain 分類を維持する限り、既存期待値は成立する。
- ただし追加 keyword を受けられない `T:875-876` は変更必須。これは plan に記載済み。
- `T:8053-8054` の authority stub は `None` を返す。plan どおり**record をそのまま core に渡す**なら mocked core が受けられる。wrapper 内で無条件に `.path` を取り出す実装へ変更すると、このテストを壊す。

**refuted・job body の legacy path 読み残し。**

- `tools/pegasus/floor_campaign.sh:1175-1198` は resolver の出力を取得し、`:1216-1219` で `--protocol "$REPO_ROOT/$PROTOCOL_PATH"` を渡す。
- 後段の protocol 読取りも `:1236,1274-1277` で同じ選択 path を使う。
- `C:8621-8640` がその入力を公開 wrapper に渡す。今回の内部 keyword と shell 引数の不整合は見つからなかった。
- approval nonce、checkpoint 環境変数、admission 分類を変更する必要もない。

## consumer 表

参照数は**文字列出現数**であり、関数呼出し数ではありません。定義・コメント・field 名・履歴記録も含みます。実行した集計：

```sh
rg -n -o '_PREFLIGHT_FIXED_FILES|_validate_freeze_allowlist_path|_assert_freeze_allowlist|clean_scan_digest|_floor_preflight_freeze_allowlist|_run_campaign_core|_require_supplied_protocol_authority|_CHAIN_RECORD_PATTERNS' orchestrator tools hooks docs output |
awk -F: '{n[$NF]++; split($1,a,"/"); r[$NF " " a[1]]++}
END {for(k in n) print k,n[k]; for(k in r) print k,r[k]}'
```

| 識別子 | orchestrator | tools / hooks | docs | output | 合計 |
|---|---:|---:|---:|---:|---:|
| `_PREFLIGHT_FIXED_FILES` | 7 | 0 / 0 | 2 | 7 | 16 |
| `_validate_freeze_allowlist_path` | 2 | 0 / 0 | 0 | 0 | 2 |
| `_assert_freeze_allowlist` | 2 | 0 / 0 | 3 | 18 | 23 |
| `clean_scan_digest` | 97 | 0 / 0 | 19 | 1296 | 1412 |
| `_floor_preflight_freeze_allowlist` | 15 | 0 / 0 | 1 | 115 | 131 |
| `_run_campaign_core` | 35 | 0 / 0 | 8 | 508 | 551 |
| `_require_supplied_protocol_authority` | 3 | 0 / 0 | 0 | 6 | 9 |
| `_CHAIN_RECORD_PATTERNS` | 2 | 0 / 0 | 0 | 12 | 14 |

以下は実行・検証上の consumer です。`output` の過去の相談逐語・実走ログを変更対象には数えません。

| 識別子 | 参照 file:line | 更新要否 |
|---|---|---|
| `_PREFLIGHT_FIXED_FILES` | 定義 `C:312`、capture `C:5221`、validator `C:5407`、scan `C:5455` | capture・validator・scan を変更。定数そのものの既存集合は維持 |
| 同 | `T:11563`、`test_s8b_ratified_freeze.py:1037`、`test_s8b_ratified_verify.py:2198` | legacy fixture の期待値変更は不要。consumer 検証対象に追加 |
| `_validate_freeze_allowlist_path` | 定義 `C:5388`、呼出し `C:5422` | 本体変更。呼出し署名変更は不要 |
| `_assert_freeze_allowlist` | 定義 `C:5415`、呼出し `C:5509` | 分類変更。返却する chain mapping の意味を維持 |
| `clean_scan_digest()` | 定義 `C:5492`、呼出し `C:5593,5603` | docstring 更新。呼出し・digest schema 変更は不要 |
| 同 | `T:11210,11228,11237,11250,11264,11293,11311,11331,11346,11363,11379,11763`、保存・spy `T:12116,12142,12163`、`B:1614` | 既存期待値は維持。後掲の既存集合を検証 |
| 同の差替え | `T:6715,13287,13310,13329,13474` | `freeze_allowlist` keyword は不変なので変更不要 |
| `clean_scan_digest` field | `C:5549,5580,5609,5643,7556`、`s8b_launch_cert.py:19,67,131,140-142` | field と strict 一致契約は変更不要 |
| field のテスト・fixture | `T:11781,12320,13234,13269-13273,13298,13311,13332,13354,13364-13371`、`test_s8b_launch_cert.py:29,52,61,67-72`、`s8b_v2_freeze_fixture.py:96`、`test_s8b_ratified_verify.py:524` | schema・既存 fixture 値の置換不要 |
| `_floor_preflight_freeze_allowlist` | 定義 `C:5201`、production 選択・呼出し `C:7508-7515` | keyword 追加と resolved path の配線が必要 |
| 同 | `T:11557,11589,11600,11616,11633,11646,11661,11672,11685,11699,11714`、保存・spy `T:12115,12137,12161` | direct call は既定で維持。spy は `**kwargs` 対応済み |
| `_floor_preflight_fn` seam | `T:802,6897,10170,10245,12492,13430,13460` が `T:875` を使用 | helper の keyword 追加が必要 |
| 同 | `T:11778,13341`、`test_s8b_ratified_freeze.py:1036,1062`、`test_s8b_ratified_verify.py:2197,2212` | `**kwargs` 対応済み |
| `_run_campaign_core` | 定義 `C:7233`、公開 wrapper `C:7217` | optional 内部 record 引数と forwarding を追加 |
| 同・直接／alias／fixture | `T:788,800,6642,7674,7737,12208`、`test_s8b_freeze_io.py:531`、`test_pegasus_floor_tools.py:1373`、`test_s8b_ratified_freeze.py:988`、`test_s8b_ratified_verify.py:2209,2216` | 既定引数により維持 |
| 同・mock | `T:4991,7692,7716,8011,8051,8111,8143,8446,8475` | 原則変更不要。authority の `None` stub は前述の注意 |
| 同・source／signature 検査 | `T:8184,8194,8219,8248,8309,8372,8379,8398`、`test_floor_submit_receipt.py:282`、`test_pegasus_floor_tools.py:1380` | 下記 pin 表参照。内部 record を seam 分類へ混入しない |
| `_require_supplied_protocol_authority` | 定義・return `C:7136,7171`、呼出し `C:7213`、stub `T:8053` | production は戻り値保持。戻り値型自体の変更は不要 |
| `_CHAIN_RECORD_PATTERNS` | 定義 `C:318-325`、消費 `C:5458` | versioned pattern の共有化後も既存 exact pattern を維持 |
| 同の挙動検査 | `B:1617-1641`、`T:11336-11379` | 期待値変更不要。焦点検証から落とさない |

`docs/failures.md:24947-24969`、`docs/archive/worklog-phase3-0817-636.md:566` などは過去の停止記録です。過去記述の置換ではなく、今回の是正結果を追記する対象です。現行 brief の更新対象は次表です。

**既存テストの関数名集合**

`orchestrator/tests/*.py` を `ast.parse` し、`ast.Call` の `func.attr` が対象名と一致する `FunctionDef` を列挙しました。結果は **23関数＝test 関数22＋helper 1**。parametrize 展開後の nodeid 数ではありません。

| 呼出し | test 関数名と定義行 |
|---|---|
| preflight | `T:11538 test_floor_preflight_allowlist_hashes_verified_prediction_and_selector_run_files` |
| | `T:11585 test_floor_protocol_expected_pin_hold_and_release_positive_control` |
| | `T:11606 test_floor_protocol_head_bytes_positive_control_fires_during_hold` |
| | `T:11622 test_floor_preflight_requires_prediction_before_allowlist` |
| | `T:11640 test_floor_preflight_requires_protocol` |
| | `T:11652 test_floor_preflight_rejects_prediction_that_fails_verification` |
| | `T:11667 test_floor_preflight_requires_selector_journal` |
| | `T:11678 test_floor_preflight_rejects_undeclared_selector_run_file` |
| | `T:11691 test_floor_preflight_rejects_duplicate_key_in_prediction` |
| | `T:11705 test_floor_preflight_rejects_duplicate_key_in_journal` |
| clean scan | `T:11205 test_clean_scan_digest_returns_digest_when_clean` |
| | `T:11215 test_clean_scan_digest_rejects_incomplete_or_failed_search` |
| | `T:11231 test_clean_scan_digest_rejects_file_enumeration_change` |
| | `T:11240 test_clean_scan_digest_rejects_freeze_file_outside_allowlist` |
| | `T:11253 test_clean_scan_digest_accepts_exact_freeze_allowlist` |
| | `T:11270 test_clean_scan_digest_binds_path_to_sha_not_only_hash_multiset` |
| | `T:11299 test_clean_scan_digest_rejects_allowlist_entry_deleted_after_construction` |
| | `T:11325 test_clean_scan_digest_rejects_noncanonical_allowlist_path` |
| | `T:11336 test_clean_scan_digest_binds_recognized_chain_record_path_and_bytes` |
| | `T:11353 test_clean_scan_digest_rejects_unknown_chain_filename` |
| | `T:11366 test_clean_scan_digest_rejects_symlink_anywhere_in_freeze_namespace` |
| | `T:11743 test_repo_root_seam_runs_production_clean_scan_on_real_tmp_repo` |
| helper 経由 | `B:1606 _clean_scan_with_isolated_repository_search` → `B:1617 test_clean_scan_accepts_exact_versioned_protocol_chain_record`、`B:1626 test_clean_scan_rejects_overbroad_versioned_protocol_names` |
| 保存した関数経由 | `T:11784 test_real_seal_protocol_to_floor_official_core_e2e` → `T:12137,12142` |
| `_assert_freeze_allowlist` | テストからの直接呼出しは検索上0。上記 clean scan 経由 |

したがって、plan の10件は**直接 preflight を呼ぶ test 関数としては網羅**しています。clean scan と上記 helper／spy 経由まで含めた集合は **25 test 関数**です。後者の追加分は `rg -n '^def test_|preflight_original\(|clean_original\(|_clean_scan_with_isolated_repository_search'` による参照照合で数えました。

## pin 閉包の表

| pin の型 | 所在・検索 | 抵触 |
|---|---|---|
| file 全体 sha256 golden | `sha256sum C T` で得た `8a816710…`、`47626f6b…` を、指定5ディレクトリへ別途 `rg -n` | 一致なし。現行 bytes の全文 hash を literal 固定する pin は見つからない |
| 凍結成果物 bytes／keyset | `test_frozen_artifacts.py:41-123,197-211,278` 付近 | production source の pin ではない。凍結成果物を変更しない計画なら更新不要 |
| literal 行番号 | path hit したテストを読み、`lineno == 数字`、`splitlines()[数字]` を別検索 | 変更箇所の固定行番号 pin は見つからない。`test_growth_test_holds_contract.py:1934` の `:7896` は合成 fixture の出典コメント |
| source アンカー／正規表現 | `test_pegasus_floor_tools.py:1380-1393` が `def _run_campaign_core`、fresh 分岐、journal/build 順序を文字列で抽出 | plan の追加箇所はアンカーを壊さない。無関係な整形・改名をしない |
| chain 名の exact 条件 | `B:1617-1641`、`C:324,5458` | 選択外 versioned も引き続き chain として受理する必要あり。pattern の共有化で幅を変えない |
| 関数名・呼出し件数 | `test_ccbench_spawn_sites.py:216-229`、`test_official_perf_closure.py:181-197`、`test_floor_submit_receipt.py:282` | resolver 再実行や subprocess 追加をしない計画では件数変更不要 |
| seam 名・署名集合 | `T:8183-8208,8370-8399`、`test_s8b_floor_contract.py:197-206` | 内部 authority record は既存 seam 集合へ足さない。core の全 keyword 集合を exact 固定する検査ではない |
| docstring 逐語 | `T:8171-8175` は module docstring の語句を要求。変更予定の `C:5493-5500` の文言も別検索 | 変更予定 docstring の逐語 pin は見つからない |
| `check_docs.py` dispatch／登録簿 | `tools/check_docs.py:3546,4026,4079,6480-6501`、`admission_registry.json:70-74,340-344` | dispatch task・script 集合・分類を変えないため更新不要 |
| 新規 nodeid の台帳 | `test_acceptance_schedule_order.py:660-713`、`test_update_acceptance_duration_ledger.py:306-325`、F902 | **plan に登録工程を追加**。未実測秒を合成しない |
| 新規 test file の自走 | `test_plain_runner_coverage.py:44-86`、`orchestrator/tests/README.md:113-120` | 新規 file なら harness または pytest-only allowlist が必要 |
| 既存 file への追加 | `T:15311-15312` の `pytest.main` harness | 新 harness・file allowlist 登録は不要。ただし duration 被覆は影響する |

新規 test file を作る場合は `docs/dev-wave/operations.md:183-191` と F902 に従い、file 集合を列挙するメタテストを焦点走へ含めます。既存 `T` への追加なら、**新規 file を理由とする**追加要件は発生しません。

**同名・類似名の意味**

| 名前 | 現物の意味 | 今回の扱い |
|---|---|---|
| 新 `protocol_relpath` | `rg -n -w` では指定5ディレクトリに既存一致なし | `IndexedFloorProtocol.path` の repo-relative POSIX path と明記 |
| `protocol_path` | `C:7184,8621-8640`。caller が渡した入力ファイルの場所 | resolver 選択 path と同一視しない |
| `supplied_protocol_path` | `C:7138-7163`。bytes 一致を確認する入力側 path | `.path` の代用品にしない |
| `protocol_sha256` | `C:7515` は実行 protocol の canonical hash | 新 keyword の対象 hash |
| journal の同名 field | `C:5293` は historical legacy bytes の hash | 現状維持 |
| `floor_protocol.path` | `s8b_ratified_freeze.py:3143-3148` の凍結世代 source record | current resolver の選択へ読み替えない |

**brief アンカー表の全行照合**

対象数は `sed -n '37,57p' …/s1-brief.md | wc -l` で **21行**でした。依頼文の22行とは一致しません。

| brief 行 | 現物との照合 |
|---:|---|
| 37 | `C:185` 一致 |
| 38 | `C:186` 一致 |
| 39 | `C:312-316` はメンバーを覆う。閉じ括弧までなら `:317` |
| 40 | `C:324` 一致 |
| 41 | `C:834-838` 一致 |
| 42 | 関数開始は一致。ただし返却・HEAD exact 選択は `C:1061-1075`。記載範囲外 |
| 43 | resolved path 未受領は一致。既存 `_read_bytes` keyword の省略あり |
| 44 | capture ループの範囲として一致 |
| 45 | hold 分岐の説明は一致 |
| 46 | historical legacy 比較は一致 |
| 47 | **誤り。hash field は `C:5293`** |
| 48 | `C:5315` の誤束縛を含み一致 |
| 49 | 説明は一致。分類条件の開始は `C:5455` |
| 50 | exact 集合一致は一致 |
| 51 | hash 不一致時の拒否は一致。「無条件」は hold 非依存という意味 |
| 52 | mapping の和と preimage 構成は一致 |
| 53 | authority record の返却まで一致 |
| 54 | preflight の production 呼出しとして一致 |
| 55 | **範囲不足。テスト群は `T:11538-11718`** |
| 56 | `:48-49` は hash pin、`:97` は keyset、`:123` は held 分類。三者とも bytes 比較するわけではない |
| 57 | check_id の所在は一致。hold 集合全体の列挙ではない |

plan は `C:5293` と末尾の journal duplicate-key テストを把握しているため、その誤りを継承していません。

## 裁定パッケージ候補

今回の参照・閉包検査から、新たに scope 外へ分離すべき real な実装所見は確認できませんでした。attempt slot、B2 被覆、本番 fixture、official 投入へ変更を広げる根拠はありません。

## plan のどこを変えるべきか

- `:82-94`：実走 JUnit による duration 台帳の `--add-only` 登録と、既存被覆 gate の確認を追加する。
- `:108-127`：「全列挙」を、直接 preflight・clean scan・helper／spy・source 検査に分け、上記 consumer を補う。
- 内部 record は wrapper から core へそのまま渡すと明記する。`protocol_path` と resolved repo-relative path の意味を分ける。
- brief のアンカー範囲と「1関数に閉じる」の説明を訂正する。
- 既存期待値の一括置換、凍結 pin の更新、hold の変更は追加しない。

## 総括

実装方針を破る既存期待値の不整合は、静的検査では確認できませんでした。  
実際の漏れは、新規 nodeid の台帳登録と consumer 検証範囲です。  
plan の10件は直接 preflight 呼出しとしては網羅し、全関連集合としては不足します。  
shell は既に resolved path を渡しており、変更は不要です。  
brief のアンカーには範囲漏れがあり、実表は21行です。  
pytest・被覆率測定・変更後の pin 検査は未実行です。