## 現状

指定の8ファイルを読めました。以下の行番号は現在の worktree 基準です。`C` は `orchestrator/campaign/s8b_floor_campaign.py`、`T` は `orchestrator/tests/test_s8b_floor_campaign.py` を表します。

- **欠陥1を確認:** `C:5201-5204` は resolved path を受け取らず、`C:5315` で legacy path に実行用 `protocol_sha256` を設定しています。親の実測値では legacy の `261cec1c…` に versioned の `2c8cf9be…` を要求します。
- **欠陥2を確認:** `C:5242-5248` の比較は hold 対象ですが、`C:5471-5482` の allowlist hash 比較は無条件です。現在は同じ誤った束縛を後者でも検査します。
- **修正時の追加障害:** `C:5407-5411` の path 検証は versioned path を許しません。これだけ直しても、`C:5455-5459` は versioned を `chain_records` に分類するため、`C:5464-5470` の exact 集合比較が失敗します。
- **配線上の注意:** `_require_supplied_protocol_authority()` は record を返しますが（`C:7171`）、公開入口は現在その戻り値を捨てています（`C:7213-7216`）。

D1936 項11に従い、比較対象を修正します。hold の機構・対象一覧は変更しません。

## 変更計画

| 対象 | 変更内容 | なぜこれが最小か |
|---|---|---|
| `C:7213-7231` | authority 検証の戻り値を保持し、private core へ内部引数として渡す。 | 検証済み record を再利用でき、resolver の再実行が不要。 |
| `C:7233-7243` | core に内部 record 引数を追加。既存の private-core 呼出しは従来の legacy 既定を維持する。公開入口は必ず authority 検証結果を渡す。 | 公開 API と既存テスト用 core の動作を維持できる。 |
| `C:7507-7516` | preflight に `protocol_relpath` を渡す。公開経路では保持した record の `.path` を使う。 | production の呼び手はここだけ。 |
| `C:5201-5204,5221-5231` | `protocol_relpath` keyword を追加し、既定は legacy。capture 集合を `_PREFLIGHT_FIXED_FILES ∪ {protocol_relpath}` にする。追加 path も既存の通常ファイル確認と `_read_bytes` を通す。 | 同じ読取り・エラー処理を再利用し、legacy resolution では重複読取りしない。 |
| `C:5245` | hold 配下の比較対象を `captured[protocol_relpath]` に変更。 | 既存の比較強度と hold 分岐をそのまま保つ。 |
| `C:5313-5320` | legacy entry は検証済み captured legacy bytes の hash にする。その後、resolved entry に `protocol_sha256` を設定する。両 path が同じなら最終的に1 entry。 | legacy の系譜検証を残し、実行用 protocol の期待 hash を正しい path に束縛できる。 |
| `C:318-325,5407-5411` | 既存の versioned protocol 命名規則を共有して、allowlist path の許容対象に加える。他の chain 種別は追加しない。 | 新しい命名規則や一般化を導入しない。 |
| `C:5455-5466` | scan 時の実効固定集合を「従来の固定集合＋allowlist に明示された versioned protocol path」とする。その集合を chain 分類より先に扱う。 | exact 一致を維持し、未選択 versioned protocol は従来どおり chain として被覆できる。 |
| `C:5493-5500` | docstring の固定4ファイルという説明に、選択 protocol の追加を反映する。 | 実装と説明のずれだけを直す。 |
| `T:875-879` | `_fixture_floor_preflight` が追加 keyword を受け取れるようにする。 | 既存 seam の戻り値・意味を維持できる。 |

`C:5274-5293` の historical protocol と journal header、`C:5517-5527` の digest 構成は変更しません。

## 上記 6 項目への回答

**1. exact 一致と固定集合**

単純置換は不可です。現状ではまず path validator が拒否し、それを通しても集合比較で失敗します。

legacy を削除せず、versioned resolution では次の集合にします。

- capture 対象：固定4ファイル＋resolved path。
- `bounded_actual`：固定4ファイル＋allowlist に明示された versioned path＋selector-runs。
- `chain_records`：上記に入らなかった、既存命名規則に一致する chain files。

`bounded_actual == set(freeze_allowlist)` は変更しません。versioned 全件を必須固定集合へ昇格させる案でもありません。

**2. digest preimage**

`C:5517` は mapping の和、`C:5522-5525` は path 順の列挙です。

| ケース | 結論 |
|---|---|
| resolved が versioned | path の和は不変。versioned の hash も、正しい bytes なら従来の chain 側の値と同じ。legacy entry が `2c8cf9be…` から自身の `261cec1c…` に訂正されるため、その1項目の値だけ preimage が変わる。 |
| resolved が legacy | 正常入力では元から expected hash と legacy bytes hash が一致する。entry は1件のままで、preimage は不変。 |

ただし、**修正前の versioned 構成は検査で停止するため、正常に返された旧 digest は存在しません。** 前者は旧コードの構成式との比較です。schema の変更は不要です。

**3. resolved path の受渡し**

**authority record を保持して引数で渡す案を選びます。**

関数内の再 resolution は、`C:1034-1037` の HEAD 取得・index scan と、その先の Git subprocess を preflight 時点で再実行します。既に通した authority 検証とは別時点の選択になり、追加の失敗点も生みます。

引数方式なら、公開入口で確認した同じ record を利用できます。`_read_bytes` による capture 注入は維持され、既存の `_floor_preflight_fn` は keyword 対応だけで済みます。合成 fixture に resolver 用の Git 履歴を強制する必要もありません。

内部 record は authority の受渡しであり、新しい公開 callable seam や許可条件にはしません。

**4. historical protocol と journal header**

**現状維持が正しいと判断します。**

`C:5274-5278` は prediction の `pre_oracle_head` に存在した legacy blob と現在の legacy を比較します。`C:5291-5293` はその同じ過去の blob hash を journal header に要求します。この2箇所は、prediction・journal の過去の同一性を結び付けています。

resolved versioned protocol は現在の実行対象です。これを過去の header に要求すると、正しく封印された journal を現在の選択によって拒否します。versioned path が `pre_oracle_head` に存在する保証もありません。

legacy の期待 hash を captured bytes から作っても、直前の historical 比較が残るため、任意の現在 bytes を無条件に信頼することにはなりません。

**5. テスト**

以下のテスト計画を採ります。特に bytes 負例は、resolver の後、対象 hash gate の前にだけ改変を入れます。

**6. 変異**

後述の6件を候補とします。hash 不一致の負例は、他 gate で拒否された場合には対象変異を殺した実績に数えません。

## テスト計画

以下の nodeid は、すべて `orchestrator/tests/test_s8b_floor_campaign.py::` を接頭辞とします。

### 新規テスト

| nodeid 案 | 構成・期待結果 |
|---|---|
| `test_public_official_preflight_accepts_versioned_protocol` | 隔離 repo で実 resolver が versioned を選ぶ。公開 `run_campaign()`、実 preflight、実 `_assert_freeze_allowlist()`、certificate 発行まで通す。legacy と versioned の hash は異なり、両 entry がそれぞれの正しい hash を持つ。 |
| `test_public_official_preflight_accepts_legacy_protocol` | 同じ経路で legacy を選ぶ。protocol entry は1件、従来の allowlist と digest を維持する。 |
| `test_public_official_preflight_rejects_resolved_protocol_byte_drift` | 実 authority 検証が返した直後に、選択された versioned bytes の1 byte を変更する。実 preflight は元の expected hash を束縛し、実 `_assert_freeze_allowlist()` が **resolved path の hash 不一致**で拒否する。 |
| `test_public_official_preflight_rejects_legacy_byte_drift_after_capture` | versioned 構成で実 preflight が historical 検証と allowlist 構成を完了した直後、legacy bytes の1 byte を変更する。certificate scan が **legacy path の hash 不一致**で拒否する。 |
| `test_clean_scan_digest_preserves_protocol_namespace_union` | production preflight の allowlist と実 namespace 検査を使用。versioned の移動で path の和が増減しないこと、訂正後の各 path→hash と独立に構成した preimage が一致することを検査する。 |

公開経路のテストでは `_floor_preflight_fn` で実体を置換しません。必要な観測 wrapper は実関数を必ず呼びます。certificate 成功を観測したところでテストを終了させ、計測・official 投入には進みません。

fixture は `T:11382` の prediction/journal 生成部分を再利用できますが、現在の `b"canonical-protocol"` は resolver 入力になりません。公開経路用には valid canonical protocol と committed versioned record を備えた隔離 fixture が必要です。既存の実封印テストの clone・証拠検証構成（`T:11925-12247`）を参照します。

**負例の帰属条件**

- resolved 負例は authority 検証**前**に改変しません。そうすると `C:984-988` などが先に拒否します。
- legacy 負例は historical 検証**後**に改変します。そうしないと `C:5278` が先に拒否します。
- どちらも hold は現在の状態を維持します。
- 対象 path の無条件 hash 比較だけを除いた対照では、同じ入力が certificate 発行まで到達することを親が確認します。
- 負例で digest の正常値比較を先に置きません。hash gate を除いた後、別の assertion が赤になる構成を避けます。

### 既存テストへの影響の全列挙

上記の legacy 既定を保つ設計では、**改名・削除・既存期待値の置換が必須の nodeid は0件**です。

追加 keyword のため変更するのは共有 helper `T:875` です。直接 helper を呼ぶ次の10 nodeid は、既定引数により従来の期待結果を維持します。

- `test_floor_preflight_allowlist_hashes_verified_prediction_and_selector_run_files`
- `test_floor_protocol_expected_pin_hold_and_release_positive_control`
- `test_floor_protocol_head_bytes_positive_control_fires_during_hold`
- `test_floor_preflight_requires_prediction_before_allowlist`
- `test_floor_preflight_requires_protocol`
- `test_floor_preflight_rejects_prediction_that_fails_verification`
- `test_floor_preflight_requires_selector_journal`
- `test_floor_preflight_rejects_undeclared_selector_run_file`
- `test_floor_preflight_rejects_duplicate_key_in_prediction`
- `test_floor_preflight_rejects_duplicate_key_in_journal`

このうち最初のテストは、protocol 自体も capture で1回だけ読む assertion を追加します。hold/release テストは既存の局所的な解除模擬を維持し、versioned 対象の比較も追加確認します。本番の hold を解除する変更ではありません。

既存の clean-scan テスト群（`T:11205-11379`）と `test_frozen_artifacts.py` は期待値を変更しません。凍結23件の manifest・keyset・held/keep 分割も不変です。

## 変異事前登録の候補

nodeid の接頭辞は前節と同じです。

| 対象 file:line | 変異 | 期待失敗 nodeid |
|---|---|---|
| `C:7507-7516` | 渡す path を常に legacy に戻す。 | `test_public_official_preflight_accepts_versioned_protocol` |
| `C:5313-5320` | legacy entry を削除し、resolved entry への単純置換に戻す。 | `test_public_official_preflight_accepts_versioned_protocol` |
| `C:5455-5459` | 選択 versioned を再び chain 側に分類する。 | `test_public_official_preflight_accepts_versioned_protocol` |
| `C:5313-5320` | resolved entry の expected を実行 protocol hash ではなく、capture 時の bytes hash にする。 | `test_public_official_preflight_rejects_resolved_protocol_byte_drift` |
| `C:5471-5482` | legacy entry の hash 比較だけを省略する。 | `test_public_official_preflight_rejects_legacy_byte_drift_after_capture` |
| `C:5293` | journal header の expected protocol hash を実行用 resolved hash にする。 | `test_public_official_preflight_accepts_versioned_protocol` |

path validator の versioned 対応漏れも versioned 正例で検出できますが、上表の6件とは別の変異実績に水増ししません。

## 残る不確実性

- 公開入口から certificate まで通す隔離 fixture の具体的な既存 helper の組合せと、certificate 後の停止位置は親の実装・実測で確定する必要があります。
- bytes 負例が指定の hash gate に到達し、対象比較を除いた対照でのみ受理されることは未実測です。
- digest の結論は静的な構成式の確認です。versioned／legacy 両構成の実値照合は親が行います。
- hold 中の frozen-artifacts テストは全23件の bytes 一致を証明しません。`test_frozen_artifacts.py:179` 以降では held の4件を除いて検査するため、不変確認と hold marker を区別して報告する必要があります。

コード変更、patch 作成、commit、pytest 実行は行っていません。

## 総括

legacy の系譜検査を残し、実行用 hash を resolver が選んだ path へ束縛します。  
capture・path validator・scan の分類を揃え、exact 集合一致と無条件 hash 比較を維持します。  
resolver は再実行せず、公開入口の検証済み record を渡します。  
journal の historical hash と digest schema は変更しません。  
二重比較による誤対象の拒否は解消しますが、hold 全体の効力を証明したとは扱いません。  
受入判断は、公開経路の正例2件と gate 帰属を確認した負例2件の実測に委ねます。