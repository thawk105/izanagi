## 現行の受理・拒否挙動

`V`＝既存の path 構文検査を通る集合、`F`＝固定 4 path、`S`＝`selector-runs/` 配下、`P`＝指定された `protocol_relpath` の singleton（`None` なら空集合）です。

- validator：現行 `V ∩ (F ∪ S)` → 変更後 `V ∩ (F ∪ S ∪ P)`。追加受理は指定 exact path だけです。
- scan：現行は `F ∪ S` を bounded、それ以外の既存 pattern 一致を chain に分類。変更後は指定 path だけを bounded に移します。
- `None` 時の validator／scan の受理集合、未知 file・symlink 等の拒否条件は維持しています。

## 実装した内容

- [s8b_floor_campaign.py:5201](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/campaign/s8b_floor_campaign.py:5201)：resolved path の capture、legacy／resolved の hash 束縛を分離。historical 比較と journal header は維持。
- 同 `:5393–5619`：exact path の受理・分類と keyword 中継。両 scan に渡し、v3 schema と preimage は維持。
- 同 `:7192–7548`：authority record を wrapper → core → preflight に中継。fresh official の `None` は拒否。
- [test_s8b_floor_campaign.py:781](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_floor_campaign.py:781)：所有内 fixture の authority 配線と観測関数の keyword 対応。
- 同 `:15329–15590`：指定 5 テスト、実関数を呼ぶ観測 wrapper、負例の比較除去対照を追加。

変更は所有 2 ファイルのみです。既存テスト名の削除、既存期待値の変更は AST 比較で 0 件でした。

## 実走結果

**pytest 実走 0 件：pass 0／fail 0。runner 基盤停止 1 件。**

次の 2 nodeid を指定しましたが、`qstat -Q preflight rc=1`、runner rc=16、`child_started=false` で起動前に停止しました。

- `orchestrator/tests/test_s8b_protocol_builder.py::test_clean_scan_accepts_exact_versioned_protocol_chain_record`
- `orchestrator/tests/test_s8b_protocol_builder.py::test_clean_scan_rejects_overbroad_versioned_protocol_names`

完走した検査は、AST parse、`git diff --check`、`check_codex_agents.py`、`check_docs.py` です。いずれも問題なしでした。

## 波及可能性の静的列挙

**所有外 consumer に未解決の衝突があります。**

[test_s8b_ratified_freeze.py:988](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_ratified_freeze.py:988) の共有 fixture は official core を直接呼び、authority を渡しません。裁定の `None` 拒否により停止する経路で、`test_s8b_ratified_verify.py:2209–2216` にも波及します。所有外なので変更していません。

repo 全体の参照検索では、さらに以下を確認しました。

- `test_s8b_protocol_builder.py`：既定 `None` の clean scan consumer。
- `test_s8b_freeze_io.py`、`test_pegasus_floor_tools.py`：core 呼出し・source 順序検査。
- `test_floor_submit_receipt.py`：core の AST 検査。
- `s8b_launch_cert.py`、そのテスト、`s8b_v2_freeze_fixture.py`：digest field／schema の参照。
- `test_s8b_dependency_prefix_bridge.py`：所有テストの共有 fixture を import。
- `test_frozen_artifacts.py`：変更禁止成果物の間接検証対象。

裁定 6 の consumer は、すべて未実走です。

## 未実走・未確認

以下の指定 5 nodeid は**実装済み・未実走**です。接頭辞は `orchestrator/tests/test_s8b_floor_campaign.py::`。

- `test_public_official_preflight_accepts_versioned_protocol`
- `test_public_official_preflight_accepts_legacy_protocol`
- `test_public_official_preflight_rejects_resolved_protocol_byte_drift`
- `test_public_official_preflight_rejects_legacy_byte_drift_after_capture`
- `test_freeze_allowlist_path_rejects_unselected_versioned_protocol`

公開経路テストは certificate dict の構成・2 scan・strict 検証後で停止します。certificate file の永続発行までの要求は未充足です。

collection／real-repo 分類／growth hold の関数集合・harness／所要台帳 90% 被覆のメタテストも未実走です。負例の単一理由性、揮発 payload 変更対照、M1–M6、受入全走、所要台帳登録も未確認です。

## 総括

本体の exact path 束縛と指定 5 テストを追加しましたが、**依頼は未完了です**。  
所有外 official fixture の authority 未配線が、裁定の fail-closed 要件と衝突しています。  
解消には、その fixture 配線を含む所有範囲または裁定の訂正が必要です。  
テスト成功・closed は申告しません。commit、git add、qsub、official 投入は行っていません。