## 所見

参照略号：`C`＝[s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py)、`T`＝[test_s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py)。行番号は統合後の現物。

1. **real / must-fix / 中 — 正例の「certificate発行まで」が未実装。**  
   根拠：`T:15483–15497` は実preflightの戻り値を検査した直後に例外を投げ、`T:15510,15519` はその例外を成功条件にする。実際のfile発行は `C:7574`、発行後再検査は `C:7577` にあり、到達しない。`T:15336–15337` もこの停止を明記している。  
   再現の筋道：P1/P2を実行しても、`_official_launch_preflight` の観測wrapperから例外が伝播し、`issue_launch_certificate` は呼ばれない。  
   最小の是正案：指定正例の停止点を、隔離fixture内の実certificate発行・再検査後へ移し、発行されたbytesとprotocol束縛を確認する。  
   **成果物影響：現状の5 passedを「公開入口からcertificate file発行まで検証済み」とする受入レポートは、証明範囲を過大に記録する。productionの発行不具合を確認した所見ではない。**

2. **real / nit / 低 — 提供差分ではfix前後の「変更1箇所」を独立に裏取りできない。**  
   根拠：[s5-implementation.diff:180](/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/s5-implementation.diff:180) が既に裁定8のfallbackを含む。この差分を記載された旧blobへメモリ内で適用すると、現物のC/Tと両方byte一致した。  
   再現の筋道：差分内の `None` 分岐を確認すると、fix前のfail-closedではなくfallbackが記録されている。  
   最小の是正案：親の最終報告では「現在の提供差分とのbyte一致」と「fix前後の比較」を区別する。  
   **成果物影響：コード・受理集合は変わらないが、fixの変更範囲に関する監査記録の根拠が混同される。**

3. **refuted / nit扱い・是正不要 / 深刻度なし — exact以外の追加受理、下位関数内でのpath導出。**  
   根拠：`C:5413–5415,5462–5466` の追加項は両方とも  
   `protocol_relpath is not None and rel == protocol_relpath`。  
   `C:5429,5520–5522,5607–5620` は受領値を中継するだけで、resolver・導出関数を呼ばない。既存のselector prefixとchain用正規表現は裁定1が維持した項であり、新しいprotocol受理条件ではない。  
   照合の筋道：構文適合集合を `V`、固定集合を `F`、selector配下を `S`、指定値を `p` とすると、受理集合は厳密に `V ∩ (F ∪ S ∪ {p})`。`None`なら最後の集合は空。  
   **成果物影響：裁定外のversioned族をallowlist keyとして追加受理する差分はない。**

4. **refuted / nit扱い・是正不要 / 深刻度なし — `None`時の受理・分類・digest変更。**  
   根拠：`C:5220–5224,5316–5325,5415,5464,5530–5547`。条件式で以下を確認した。
   - `p=None`なら追加述語は常に偽。validatorの受理集合、`bounded_actual`、chainへ進む条件は旧版と同じ。
   - 実効pathはlegacy `L`。`L∈F`なのでcapture集合は `F∪{L}=F`、ソート順・読取り回数も同じ。
   - legacy entryは一旦captureのhashになるが、`allowlist[L]=protocol_sha256`で上書きされ、旧版と同じ値・挿入順になる。
   - `chain_records`が同じなので、`{**freeze_allowlist, **chain_records}`、v3 schema、pathソート、JSON直列化、SHA256のpreimageは同じ。

   裁定8のfallbackは `p=L` を下位へ渡すが、追加項 `rel==L` は既存項 `rel∈F` に包含されるため、こちらも同じ結論になる。  
   **成果物影響：同じ入力bytes・列挙結果の下で、既定経路の受理可否・allowlist・digestに差分はない。versioned修正前の停止経路について旧digestの存在は主張しない。**

5. **refuted / nit扱い・是正不要 / 深刻度なし — 裁定8によるproduction検査の弱体化、`None.path`参照。**  
   根拠：`C:7164–7189` はresolverのrecordを返すか例外を投げる。resolverも `C:1056–1075` でrecord返却または拒否となり、実装上の `None` 戻り経路はない。公開wrapperは `C:7229` でauthority検証を完了してから `C:7246` でrecordを渡す。coreが読む属性は `C:7527` の `.path` だけ。  
   repo内参照を再検索した結果、非testコードの呼出しは **`C:7233` の1箇所**。他は定義、テスト内の呼出し・alias・monkeypatch・参照だった。
   - pilot：`C:7524` に入らず、dereferenceしない。`T:8065` のNone stubもwrapperでは中継されるだけ。
   - resume：`C:7519` のfresh分岐に入らず、dereferenceしない。
   - private core直接呼出し：既定Noneを `C:7526` でlegacyへfallbackし、所見4の旧条件になる。

   **成果物影響：公開fresh officialはresolved pathへ束縛されたまま。fallbackを理由とするcertified選択や台帳値の追加変更は認めない。**

6. **refuted / nit扱い・是正不要 / 深刻度なし — 現状維持箇所・禁止事項の変更。**  
   現物読解と旧blob比較の根拠：
   - historical比較 `C:5281`、journal header `C:5296` は該当ASTが旧版と一致。
   - 固定4メンバー `C:312`、chain patterns `C:318`、certificate field `C:5559–5566` は旧版と一致。
   - digest schema/preimageは `C:5530–5547` の現物で確認。
   - `freeze_verification_hold.py`、stats、contract、attempt launcherはHEADとfile全体がbyte一致。`FORMULA_ID`、result schema既定、launcherの2署名も変更なし。
   - `test_frozen_artifacts.py:40` のmanifest対象 **23件すべてHEADとbyte一致**。
   - テスト関数名集合は **354→359、削除0、追加5**。差分上も `-def test_` は0行。変更された既存5テストのassertとdecoratorはAST一致し、既存期待値変更・skip追加はない。

   **成果物影響：凍結参照、式、schema既定、既存テストの期待結果を変更する差分はない。**

7. **refuted / nit扱い・是正不要 / 深刻度なし — hold比較対象の不一致、拒否の握り潰し。**  
   根拠：hold対象は `C:5248` の `hash(captured[p]) != protocol_sha256`。同じ `p` に `C:5325` が同じ期待hashを設定し、無条件検査 `C:5485–5489` がscan時のbytesを比較する。両scanへの配線は `C:5609,5620`。production差分に拒否を飲み込む例外処理追加はない。  
   `T:15433–15457` の比較除去は明示された負例対照だけで、両scanが同じ変更関数を呼ぶ。N1の注入はauthority返却後、N2は実preflight返却後である（`T:15459–15475`）。  
   コメント・docstringにhold全体の効力を証明したとの追加主張は見つからない。結論は「captureとscan間でbytes不変のfresh officialでは、この局所holdの有無で最終受理可否は変わらない」に限定される。停止位置・marker・途中変更・hold全体は含まない。  
   **成果物影響：比較先はresolved protocolへ揃う。hold全体の検証済み認定や、拒否を成功として扱う変更はない。**

## 裁定適合表

| 対象 | 判定 | 現物根拠 |
|---|---|---|
| 裁定1：validator署名・条件 | 適合 | C:5393、5413 |
| 裁定1：assert署名・分類 | 適合 | C:5422、5462 |
| 裁定1：digest署名・中継 | 適合 | C:5500、5520 |
| 裁定1：official preflight署名・中継 | 適合 | C:5601、5607、5618 |
| plan 1：authority保持・中継 | 適合 | C:7229、7246 |
| plan 2：core既定None | 適合 | C:7260 |
| plan 3：official配線〔裁定8で訂正〕 | 適合 | C:7525–7547。旧fail-closed要件は撤回済み |
| plan 4：preflightのNone→legacy | 適合 | C:5203、5220 |
| plan 5：capture集合・file検査 | 適合 | C:5224–5235 |
| plan 6：hold比較先変更 | 適合 | C:5244–5251 |
| plan 7：legacy/resolved hash分離 | 適合 | C:5316–5325 |
| plan 8：exact validator | 適合 | C:5413–5415 |
| plan 9：exact bounded分類 | 適合 | C:5462–5467 |
| plan 10：digest中継・schema維持 | 適合 | C:5520、5530–5547 |
| plan 11：両scanへの中継 | 適合 | C:5609、5620 |
| plan 12：historical・journal維持 | 適合 | C:5281、5296。旧AST一致 |
| plan 13：fixture keyword追加 | 適合 | T:886。戻り値不変 |
| plan 14：docstring更新 | 適合 | C:5503–5513 |

指定5 nodeidはすべて存在する。ただし、**P1/P2のcertificate file発行到達要件は未実装**（所見1）。所要台帳登録・consumer全走・M1–M6の完了は、この静的レビューでは認定しない。

## 裁定パッケージ候補

なし。scope外へ広げるreal所見は確認しなかった。

## 総括

裁定1の4署名とplan v2の14項目は、裁定8による訂正を含め適合している。  
受理集合の追加は指定exact pathだけで、None・legacy fallbackの集合とdigest条件は旧版と同じ。  
must-fixは、指定正例がcertificate file発行まで到達しない検証要件の不足1件。  
提供差分は既にfix後なので、fix前後の変更1箇所という履歴主張は独立確認できない。  
pytestは実行していない。新規5 passed・fix後82 passedは親の実走報告として扱い、本レビューの実測とはしていない。