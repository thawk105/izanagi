単独段 dispatch: stage=consult; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s1-brief.md` — 親の段 1 brief
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s2-plan.md` — 段 2 plan (攻撃対象)
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語
4. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-09/t1851-unit-c3b-floor-range/ruling-package.md` — C3b 裁定 1 / 2 / 5
5. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py`
6. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/freeze_verification_hold.py`
7. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py`

repository root は上記 worktree である。親の checkout を見に行かないこと。

## 依頼 — レンズ A: 受理集合と正しさ防壁への攻撃

plan を守らせず検査せよ。**plan を実装したとき、正しさ防壁が実質的に弱まる経路を探す。**
親 brief 自身も検査対象である。所見は real / refuted を自分で付け、根拠を file:line で書け。

必ず扱う攻撃面:

1. **legacy entry の恒真化。** plan は `allowlist[legacy]` の期待値を、同じ関数が同じ file から
   読んだ `captured[legacy]` の hash にする。その後 `_assert_freeze_allowlist()` が同じ file を
   読み直して比較する。**これは自己参照であり、capture と assert の間の書き換えしか検出しない。**
   現行は独立の期待値 (`protocol_sha256`) を要求していた。
   - この entry は実質どんな改竄を捕まえるか。捕まえないものは何か。
   - `:5274-5280` の `historical_protocol` 比較 (pre_oracle_head の Git blob との一致) が
     独立の権威として残るので恒真でないと plan は言う。それは本当か。
     `historical_protocol` が到達しない構成・分岐はあるか。
   - `sha256(historical_protocol)` を期待値にする案の方が強いか。強いなら、それを採らない理由は
     成立するか。
2. **versioned path を `chain_records` から `bounded_actual` へ移す影響。** chain record 側の検査
   (`:5455-5459` の分類と `clean_scan_digest` への寄与) が、移動によって失われる保証はあるか。
   複数の versioned protocol が存在する将来状態で、選択されなかった versioned はどちらの集合に入り、
   検査の強度は変わるか。
3. **path validator の緩和が受理集合を広げるか。** plan は `_validate_freeze_allowlist_path()` の
   有界範囲へ versioned protocol 命名規則を加える。これは allowlist の key として受理する path 集合を
   広げる変更である。**「同じ強度の検査を正しい対象へ向けるだけ」という親と plan の主張は、
   この 1 点で成立しているか。** 広がった集合を通って何が新たに受理されうるか、具体例で示せ。
4. **hold の扱い。** plan は `:5245` の比較対象を `captured[protocol_relpath]` へ変える。
   変更後、hold は何を保留し、無条件検査は何を拒否するか。**「hold が結果を 1 bit も変えない」
   という C3b の所見は plan 適用後も真か。** 真なら、それを成果物へどう書くべきか
   (D1936 項 11 は「hold 機構全体の効力を証明したとは書かない」と命じている)。
   `HELD = False` にした場合の挙動も読解で確かめ、hold 解除を提案はしないこと。
5. **負例の帰属。** plan の 2 つの負例が「対象 gate を外したときだけ緑になる」条件を満たすか。
   先に赤を出す別 gate を file:line で探せ。特に resolved 負例が
   `_require_supplied_protocol_authority()` / `_scan_floor_protocol_index_at_commit()` の
   bytes 一致検査より後に改変を入れられるか、実際の呼び出し順序で確かめよ。
   legacy 負例が `:5278` より後に入れられるかも同様に確かめよ。
6. **親 brief の実測値とその一般化。** brief は resolved path・2 つの sha256・`ccbench_pin` 1 field 差を
   実測値として書いている。これらが **1 構成の観測**であって全構成の性質でない点を、
   brief または plan が一般化して使っていないか。特に「resolved == legacy のときは digest 不変」
   という結論が、どの前提の下でだけ成り立つか。
7. **規律 2 (正しさゲートを緩める変異を許さない) への抵触。** plan のどの項目が、
   性能や利便ではなく「通すため」に検査を弱める向きに働くか。1 件でもあれば real として挙げよ。

## 禁止

- plan を弁護しない。良い点の列挙に紙面を使わない。
- 実装・patch・commit をしない。
- hold の解除、`HELD_CHECK_IDS` の変更、凍結成果物の bytes 変更を提案しない。
- scope 外の層 (attempt registry の slot 一意性、B2 inspector の被覆全単射照合、本番共有 root の
  fixture 残存、official campaign の投入) を実装する案を出さない。real な所見なら
  「裁定パッケージ候補」として分けて返せ。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を提案しない。

## 制約

書込可能な tmp が無いので pytest は不要。静的検査でよい。走らせていない検査を緑と書かないこと。
予算が尽きそうなら途中結論を下記の形式で書いて終われ (無出力が最悪である)。

## 出力形式

- `## 所見` — 1 件ごとに `real` / `refuted`、深刻度、file:line 根拠、再現の筋道、最小の是正案
- `## 裁定パッケージ候補` — real だが scope 外のもの
- `## plan のどこを変えるべきか` — 採否を親が決められる粒度で
- `## 総括` — 3〜8 行
