単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/output/insights/2026-09-14/t1851-c3c-protocol-binding/s4-adjudication.md` — **段 4 裁定。これが実装の正本である。** plan v2、テスト計画 5 nodeid、変異事前登録、禁止事項がここにある
2. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/output/insights/2026-09-14/t1851-c3c-protocol-binding/s1-brief.md` — 段 1 brief (アンカー表。裁定 7 の訂正が優先する)
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語
4. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/output/insights/2026-09-09/t1851-unit-c3b-floor-range/README.md` — 実投入 988501.nqsv の実測 (§3〜§5)
5. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/campaign/s8b_floor_campaign.py` — 編集対象
6. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_floor_campaign.py` — 編集対象
7. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_protocol_builder.py` — 期待値を変えてはいけない consumer (`:1606-1641`)
8. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/campaign/freeze_verification_hold.py` — 変更禁止

repository root は `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author` である。
**ここ以外の worktree・checkout を読み書きしてはならない。**

## 所有範囲 (これ以外の file を 1 byte も変えてはならない)

- `orchestrator/campaign/s8b_floor_campaign.py`
- `orchestrator/tests/test_s8b_floor_campaign.py`

docs・`output/` 配下・他の test file・`tools/`・`hooks/` は所有外である。

## 依頼

**段 4 裁定の「plan v2 (確定)」14 項目と「テスト計画 (確定 5 nodeid)」を実装せよ。**

要点だけ再掲する (詳細と署名は裁定 1 と plan v2 を正本とする)。

- official preflight の allowlist が、実行時に resolver が選んだ protocol の canonical sha256 を
  legacy 固定 path `output/s8b-freeze/floor_protocol.json` へ束縛している。これを resolved protocol の
  実 path へ直す。
- 受理する allowlist path に追加してよいのは **`protocol_relpath` と exact 一致する 1 件だけ**である。
  命名規則・正規表現・prefix 一致で受理してはならない。
- `protocol_relpath` は呼び手から受け取った値だけを使う。関数内で resolver から導出してはならない。
- 新 keyword はすべて既定 `None` とし、`None` のときの受理集合・digest・挙動は現行と 1 bit も違わないこと。
- `_require_supplied_protocol_authority()` の戻り値は `None` になりうる
  (`orchestrator/tests/test_s8b_floor_campaign.py:8053` の stub が `mode="pilot"` で `None` を返す)。
  **無条件に `.path` を取り出してはならない。** official 分岐で `None` なら fail-closed で拒否する。
- `historical_protocol` 比較 (`:5278`) と journal `expected_header.protocol_sha256` (`:5293`) は
  **現状維持**。resolved 側へ向け直してはならない。
- `clean_scan_digest` の schema `s8b-clean-scan-digest/v3` と preimage の構成は変えない。
- `_official_launch_preflight` は 2 回の `clean_scan_digest` 呼出しの **両方**へ `protocol_relpath` を渡す。

## scope の前に現行挙動を明記せよ

実装を始める前に、次を出力の `## 現行の受理・拒否挙動` 節へ書け。

- `_validate_freeze_allowlist_path()` が現在受理する path 集合と拒否する path 集合
- `_assert_freeze_allowlist()` が `bounded_actual` と `chain_records` に分ける現在の条件
- 変更後にそれぞれがどう変わるか (差分を集合で)

## テスト

段 4 裁定の 5 nodeid を実装する。名前は裁定のとおりにする。

- 公開経路のテストでは `_floor_preflight_fn` で実体を置換しない。観測 wrapper は実関数を必ず呼ぶ。
- 負例の注入位置は裁定の「負例の帰属条件」に従う。N1 は実 authority 検証の return 後、
  N2 は `:5278` より後・1 回目の `clean_scan_digest` より前。
- 負例は「その gate を外したときだけ緑になる」ものにせよ。他の gate が先に赤を出す構成は帰属しない。
  **機構の正例・負例は実体を名指しし、依存先を stub しない。**
- certificate 発行を観測したら終了する。計測段・official 投入へ進んではならない。
- 期待値に揮発 payload (working tree の hash、現行 commit、実行時刻など) を焼き込まない。
  理由と件数を固定して揮発部分を外し、揮発源を編集しても緑か確認せよ。
- fixture へ現行 hash を差し込んでテストを甘くしてはならない。
- **テスト新設の単位について、親の名指しを網羅と見なさず、制約 meta-test を自ら洗い出して走らせよ**
  (file 集合の列挙、nodeid 命名規則、test 関数名集合を検査するメタテストが repo 内に無いか調べる)。
- `monkeypatch` は最後の手段とする。対象実装まで読み、resolver や注入 seam
  (`_read_bytes`、`_floor_preflight_fn`、`repo_root`) の正規経路が使えないかを先に確かめよ。
- submodule の index lock を作れない sandbox 由来の偽赤が出たら、それを実装差分へ帰属せず
  「sandbox 由来・親環境で要再現」と報告せよ。

## 禁止

- docs を編集しない。`output/` 配下を編集しない。commit しない。`git add` もしない。
- 所有外の file を編集しない。特に `orchestrator/tests/test_s8b_protocol_builder.py` の
  `test_clean_scan_accepts_exact_versioned_protocol_chain_record` と
  `test_clean_scan_rejects_overbroad_versioned_protocol_names` は期待値を変えずに緑を維持すること。
- **既存テストの期待値を変更・反転・緩和・skip・削除しない。** 既存テストが赤になるなら実装が誤りである。
  期待値が誤りだと判断した場合は実装を変えず、報告して止めよ。
- **既存テストを削除・改名しない。** 関数名集合を減らしてはならない。
- 凍結成果物 (`output/s8b-freeze/` 配下、`output/s1-freeze/` 配下) の bytes を変えない。
- `freeze_verification_hold.py` を変えない。`HELD`、`HELD_CHECK_IDS`、hold の射程を変えない。
- `_PREFLIGHT_FIXED_FILES` の既存メンバー、`_CHAIN_RECORD_PATTERNS`、digest schema、
  `build_launch_certificate` の field、`FORMULA_ID`、result schema の既定を変えない。
- `launch_floor_attempt()` / `launch_probed_floor_attempt()` の署名と挙動を変えない。
- `tools/pegasus/` の shell を変えない (親が resolver 経由であることを実測済み)。
- official campaign を投入しない。`qsub` しない。
- 受理集合を、裁定 1 が許した exact 1 path 以外に広げない。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を足さない。本題だけを実装する。

## 検査と報告

- 緑を報告するときは **実走した nodeid と範囲を必ず併記**せよ。実走できなかったものは `closed` と
  申告せず「実装済み・未実走」と書け。子の実走は親の全走を代替しない。
- 変更した production symbol を repo 全体で grep し、**所有外 caller・共有 fixture・consumer test の
  波及可能性を静的に列挙**して報告せよ (名前の推測でなく参照関係で引く)。
- 段 4 裁定が挙げた consumer (裁定 6 の一覧) のうち、自分が実走できたもの・できなかったものを分けて書け。
- 指示外の受理集合変更をしていないことを、上の `## 現行の受理・拒否挙動` の差分集合で示せ。

## 出力形式

- `## 現行の受理・拒否挙動`
- `## 実装した内容` — file:line 粒度
- `## 実走結果` — nodeid と範囲、pass/fail の実数
- `## 波及可能性の静的列挙`
- `## 未実走・未確認`
- `## 総括` — 3〜8 行
