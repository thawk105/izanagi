単独段 dispatch: stage=review; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s4-adjudication.md` — 段 4 裁定 (テスト計画 5 nodeid、負例の帰属条件、変異事前登録 6 件、裁定 5 の所要台帳、裁定 6 の consumer)
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/s5-implementation.diff` — 実装差分の逐語
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s5-author.md` — 実装子の自己報告
4. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py` — 統合後の現物
5. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py` — 統合後の現物
6. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_protocol_builder.py` — 期待値を変えてはいけない consumer (`:1606-1641`)

repository root は上記 wave worktree である。他の worktree を読み書きしてはならない。
worktree 内は自由に検索してよい (`git grep`、`rg`、`ls-tree`)。

## 依頼 — レンズ D: テストの帰属・恒真・揮発と閉包の再検査

**新規テストが「その gate を外したときだけ赤になる」ことを保証しているか、
恒真・過剰決定になっていないかを検査せよ。** 所見ごとに real / refuted を付け file:line 根拠を書け。

必ず扱うこと。

1. **負例 N1 / N2 の帰属。** 注入位置が裁定の条件を満たすか。**先に赤を出す別 gate を
   file:line で探せ。** N1 は `_require_supplied_protocol_authority` と
   `_scan_floor_protocol_index_at_commit` の bytes 一致検査より後か。N2 は `historical_protocol`
   比較より後、1 回目の `clean_scan_digest` より前か。
   **どちらも「対象の hash 比較を外すと緑になる」ことを、コードを外した状態の読解で確かめよ。**
   他の assertion が先に赤になる構成なら real として挙げよ。
2. **N3 の過剰決定。** 「別の versioned path を allowlist key に載せると拒否される」テストが、
   `_validate_freeze_allowlist_path` の「有界範囲外」で拒否されているか、それとも
   `bounded_actual != set(freeze_allowlist)` や「未知 file」など別の理由で拒否されているか。
   別理由なら、その変異 (M3) の kill 実績に数えられない。
3. **恒真なテスト。** 新規テストのうち、実装を無効化しても緑のままになるものはないか。
   特に (i) 期待値を被検査対象と同じ経路から導出しているもの、(ii) 述語が候補集合に含意されて
   恒真になっているもの、(iii) 両層を stub して機構を通らず緑になっているものを探せ。
4. **揮発 payload。** 期待値に working tree の hash、現行 commit、実行時刻、絶対 path、ホスト名、
   負荷依存の秒数が焼き込まれていないか。焼き込まれていれば real。
   fixture へ現行 hash を差し込んでテストを甘くしていないか。
5. **正例 P1 / P2 の実効性。** 公開経路 (`run_campaign` またはそれに準ずる production 入口) を
   通っているか。`_floor_preflight_fn` で実体を置換していないか。観測 wrapper が実関数を
   呼んでいるか。certificate 発行まで到達しているか。計測段・official 投入へ進んでいないか。
6. **既存テストの関数名集合。** 差分の前後で `orchestrator/tests/test_s8b_floor_campaign.py` の
   `def test_` 関数名集合が**減っていない**ことを数で示せ。改名も減少に数える。
7. **consumer 閉包の再検査。** 実装が変えた symbol について、裁定 6 が挙げた consumer 一覧に
   漏れがないか確かめよ。実装で新たに生まれた symbol・keyword の consumer も数えよ。
   private symbol の変更は公開 API の consumer 表に出ないので symbol 名で production 全体を grep せよ。
8. **pin 閉包の再検査。** 実装が触った行に、file 全体 sha256 golden、行番号 literal、
   正規表現アンカー、関数名・件数を数える meta-test、docstring 逐語 pin が掛かっていないか。
   **path 検索だけでは見つからない型があるので、それぞれ別の検索で当たれ。**
   特に `orchestrator/tests/test_pegasus_floor_tools.py:1380-1393` の source アンカー検査が
   実装の整形変更で外れていないか確かめよ。
9. **所要台帳。** 新規 nodeid が `orchestrator/tests/acceptance_duration_ledger.json` に
   未登録であること (親が受入後に登録する) を確認し、0.0 の placeholder や合成秒が
   混入していないか調べよ。
10. **変異事前登録 6 件の anchor 実在。** 段 4 裁定の M1〜M6 について、変異対象の逐語 (old) が
    統合後の現物に **ちょうど 1 箇所**存在するかを確かめ、存在しない・複数ある場合は
    置換可能な最小の逐語を提案せよ。**同じ入力を拒否する層が前後・内側にも無いか**も読解し、
    単一理由性が立たない変異は指摘せよ。

## 禁止

- 実装を弁護しない。良い点の列挙に紙面を使わない。
- コードを書き換えない。patch を出さない。commit しない。
- 既存テストの期待値変更・skip・削除を提案しない。
- scope 外の層へ広げる案を出さない。real なら「裁定パッケージ候補」へ分けよ。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を提案しない。
- 件数を書くときは数えた command と対象集合を併記せよ。数えていない件数を書かない。

## 制約

書込可能な tmp が無いので pytest は不要。静的検査でよい。テスト実測は親が行うので、
走らせていない検査を緑と書かないこと。予算が尽きそうなら途中結論を下記の形式で書いて終われ。

## 出力形式

- `## 所見` — `real` / `refuted`、must-fix / nit、深刻度、file:line 根拠、再現の筋道、最小の是正案、成果物影響 1 行
- `## 負例の帰属表` — N1 / N2 / N3 それぞれに 帰属成立 / 不成立 と先行 gate
- `## 変異 anchor 表` — M1〜M6 の逐語一意性と単一理由性
- `## consumer / pin 閉包の追加分`
- `## 裁定パッケージ候補`
- `## 総括` — 3〜8 行

## この時点までの経緯 (必ず前提にせよ)

- 段 5 実装子は pytest を 1 件も実走できなかった (sandbox で runner rc=16)。
- 親の実走: 新規 5 nodeid は **5 passed**。`test_s8b_ratified_freeze.py` は当初 **28 failed**。
- 28 failed の発生源は、段 5 が入れた `_protocol_authority is None` の fail-closed だった。
  親は **裁定 8** を追記して plan v2 項 3 を撤回し、official 分岐を
  「record があれば `.path`、無ければ `_FLOOR_PROTOCOL_REL`」の fallback へ直させた。
  裁定 8 の全文は射影 1 の file 末尾にある。**裁定 8 自体も検査対象である。**
- 段 6 fix 子はこの 1 箇所を直した後、model call 上限 100 に当たって **報告を出さずに死んだ**
  (`limit_trigger: max_model_calls`、`codex_exit_code: -15`)。したがって
  **fix の自己報告は存在しない。** 親は差分を現物で監査し「裁定 8 の署名どおり・他の変更ゼロ・
  テスト file は byte 一致」と確認したが、**この監査を裏取りするのはあなたの仕事である。**
- 親の実走 (fix 後): `test_s8b_ratified_freeze.py` は **82 passed**。

裁定 8 について特に見るべき点。

1. fallback が規律 2 を緩めていないか。production の official 経路が resolved protocol へ
   exact に束縛されることを、コードの呼び出し順で確かめよ。
2. `_run_campaign_core` の非 test 呼び手が公開 wrapper 1 箇所だけであるという親の主張を、
   repo 全体の参照で数え直せ。違えば real。
3. fallback が効く経路 (record なしの official) で、変更前と挙動が 1 bit も違わないことを確かめよ。
