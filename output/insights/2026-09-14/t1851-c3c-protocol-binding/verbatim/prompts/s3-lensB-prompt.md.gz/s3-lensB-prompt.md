単独段 dispatch: stage=consult; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s1-brief.md` — 親の段 1 brief
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s2-plan.md` — 段 2 plan (攻撃対象)
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語
4. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py`
5. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py`
6. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_frozen_artifacts.py`

repository root は上記 worktree である。親の checkout を見に行かないこと。
worktree 内は自由に検索してよい (`git grep`、`rg`、`ls-tree` など)。

## 依頼 — レンズ B: 閉包と consumer 取り残し

plan を守らせず検査せよ。**plan が変える識別子・定数・path・関数の consumer を全数列挙し、
取り残しを探す。** 親 brief のアンカー表自身も検査対象である。所見は real / refuted を自分で付けよ。

必ず扱う攻撃面:

1. **変更する識別子の consumer 全列挙。** plan は次を変える。それぞれについて repo 全体
   (`orchestrator/`、`tools/`、`hooks/`、`docs/`、`output/`) の参照を数え、更新が要るものを
   file:line で挙げよ。名前の推測でなく参照関係で引くこと。private symbol の変更は公開 API の
   consumer 表に出ないので、symbol 名で production 全体を grep せよ。
   - `_PREFLIGHT_FIXED_FILES` (定数)
   - `_validate_freeze_allowlist_path()`
   - `_assert_freeze_allowlist()`
   - `clean_scan_digest()`
   - `_floor_preflight_freeze_allowlist()` とその keyword 引数
   - `_run_campaign_core()` の引数列
   - `_require_supplied_protocol_authority()` の戻り値
   - `_CHAIN_RECORD_PATTERNS`
2. **pin 閉包。** plan が触る行に、次の型の pin が掛かっていないか調べよ。**path 検索だけでは
   見つからない型があるので、それぞれ別の検索で当たれ。**
   - file 全体の sha256 golden (key 名にも値の字面にも掛からない)
   - 行番号を literal に焼いた test (path 検索で hit した test の中身を読む)
   - 正規表現アンカーを持つ閉包 pin (整形変更で外れる)
   - 関数・定数の名前集合や件数を数える meta-test
   - docstring の逐語を要求する test
   - `tools/check_docs.py` の dispatch 契約や登録簿
3. **新規 test file / 新規 nodeid の受入要件。** plan は新規テストを 5 件追加する。
   `orchestrator/tests/acceptance_duration_ledger.json` への登録、自走 harness、file 集合列挙の
   メタテストのうち、どれが要るか。既存の登録規則を file:line で示せ。
   新規 test file を作らず既存 file へ足す場合に不要になるものも分けて書け。
4. **job body 側の取り残し。** official 床値の投入経路は
   `tools/pegasus/floor_campaign.sh` / `tools/pegasus/submit_floor.sh` と
   `tools/pegasus/admission_registry.json` を通る。plan の変更が、これらが渡す引数・環境変数・
   期待 path と食い違わないか確かめよ。shell 側が legacy 固定 path を直接読む箇所があれば挙げよ。
5. **同名識別子の二義化。** plan は `protocol_relpath` という新しい keyword を導入する。
   repo 内に同名・類似名の field や引数があり、意味が違うものはないか
   (`protocol_path`、`protocol_sha256`、`supplied_protocol_path`、`floor_protocol.path` など)。
6. **親 brief のアンカー表の誤り。** brief の 22 行のアンカー表の各行を現物と照合し、
   行番号・記述が違うものを挙げよ。plan が brief の誤りを継承していないか確かめよ。
7. **既存テストの関数名集合。** plan は「改名・削除・既存期待値の置換が必須の nodeid は 0 件」と
   主張する。`_floor_preflight_freeze_allowlist` と `_assert_freeze_allowlist` と
   `clean_scan_digest` を呼ぶ既存テストを全数列挙し、この主張が成立するか確かめよ。
   plan が挙げた 10 件が網羅かどうかを数で示せ。

## 禁止

- plan を弁護しない。良い点の列挙に紙面を使わない。
- 実装・patch・commit をしない。
- hold の解除、`HELD_CHECK_IDS` の変更、凍結成果物の bytes 変更を提案しない。
- scope 外の層 (attempt registry の slot 一意性、B2 inspector の被覆全単射照合、本番共有 root の
  fixture 残存、official campaign の投入) を実装する案を出さない。real な所見なら
  「裁定パッケージ候補」として分けて返せ。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を提案しない。
- 件数を書くときは、数えた command と対象集合を併記せよ。数えていない件数を書かない。

## 制約

書込可能な tmp が無いので pytest は不要。静的検査でよい。走らせていない検査を緑と書かないこと。
予算が尽きそうなら途中結論を下記の形式で書いて終われ (無出力が最悪である)。

## 出力形式

- `## 所見` — 1 件ごとに `real` / `refuted`、深刻度、file:line 根拠、再現の筋道、最小の是正案
- `## consumer 表` — 識別子ごとに参照 file:line と更新要否
- `## pin 閉包の表` — pin の型ごとに所在と抵触有無
- `## 裁定パッケージ候補` — real だが scope 外のもの
- `## plan のどこを変えるべきか`
- `## 総括` — 3〜8 行
