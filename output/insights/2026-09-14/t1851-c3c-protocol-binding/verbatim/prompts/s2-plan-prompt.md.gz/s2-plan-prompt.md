単独段 dispatch: stage=plan; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s1-brief.md` — 親の段 1 brief (scope・不変条件・実アンカー表・(P1)〜(P4))
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語 (確定済みユーザー裁定)
3. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-09/t1851-unit-c3b-floor-range/README.md` — 実投入 988501.nqsv の実測記録 (停止点と gate 入力の実値)
4. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-09/t1851-unit-c3b-floor-range/ruling-package.md` — 裁定 1 / 2 / 5 の択一と親推奨
5. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py` — 変更対象
6. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/freeze_verification_hold.py` — 凍結保留
7. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py` — 既存テスト
8. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_frozen_artifacts.py` — 凍結 23 件の bytes pin

repository root は上記 worktree であり、親の checkout を見に行かないこと。

## 依頼

**D1936 項 11 (案 a) を実装するための plan を file:line 粒度で起草せよ。** 実装はしない。

対象の欠陥は 2 件で、どちらも `s8b_floor_campaign.py` の official preflight 1 面にある。

- 欠陥 1: `_floor_preflight_freeze_allowlist()` が `allowlist[_FLOOR_PROTOCOL_REL] = protocol_sha256`
  と置く。`_FLOOR_PROTOCOL_REL` は legacy 固定 path、`protocol_sha256` は実行時に
  `resolve_current_floor_protocol()` が選んだ protocol の canonical sha256 である。
  resolver が versioned protocol を選ぶ限り両者は構造的に一致しない。
- 欠陥 2: 凍結保留 `s8b-floor.protocol-bytes-expected-pin` が保留するのは同関数の `elif` 側だけで、
  `_assert_freeze_allowlist()` が同じ 2 値の同じ比較を無条件に行う。

親が worktree 上で実測した値 (2026-09-14):
`resolve_current_floor_protocol().path` =
`output/s8b-freeze/floor-protocols/e576e9cd1369bba3ae8faca084d1b7256bf919a7dd2e5d6facb093cd9e242c01--511c9538e4e8efa54b45cda62e72389ed3b706ec.json`、
その sha256 = `2c8cf9be929d83653814ecf5f2d5ed134a2af89686d796b8144da2fd45dfa58a`、
legacy file の sha256 = `261cec1c7f423b3eebff41ee716d2bfe2c6fa9a10a9dd86d91eaf71612e74aac`。

## 必ず扱うこと

1. **`_assert_freeze_allowlist()` の `bounded_actual != set(freeze_allowlist)` (exact 一致要求) と
   `_PREFLIGHT_FIXED_FILES` の関係。** legacy path はこの固定集合にあるので `bounded_actual` から
   外れない。一方 versioned path は `_CHAIN_RECORD_PATTERNS` に掛かり `chain_records` へ落ちる。
   allowlist の key を単に置換すると `preflight scope と allowlist が不一致` を新たに踏むか否かを
   コードで確かめ、踏むなら固定集合側をどう resolved path 込みにするかまで書け。
2. **`clean_scan_digest()` の digest preimage が変わるか。** `freeze_allowlist ∪ chain_records` の
   和で作るので、versioned が chain_records から allowlist へ移っても和は変わらないはずである。
   legacy entry の sha256 値が変わる分だけ digest が変わるか、resolved == legacy の場合は不変か、
   の 2 場合を分けて結論せよ。
3. **resolved path をどう `_floor_preflight_freeze_allowlist()` へ渡すか。** 呼び手は
   `s8b_floor_campaign.py:7504-7524` の 1 箇所だけで、`_require_supplied_protocol_authority()`
   (`:7136-7171`) が既に resolver 記録を保持している。新しい引数を足すのか、関数内で
   resolver を呼ぶのかを、副作用順序 (resolver が Git subprocess を呼ぶ) と
   テスト注入面 (`_floor_preflight_fn`、`_read_bytes`) の両方から比較して選べ。
4. **`:5274-5280` の `historical_protocol` 比較と `:5285-5292` の journal `expected_header.protocol_sha256`。**
   これらは pre_oracle_head 時点の legacy blob に束縛されている。resolved 側へ向け直すべきか、
   pre_oracle 系譜として現状維持が正しいか、どちらかを根拠付きで決めよ。親の provisional 裁定は
   現状維持だが、これは攻撃対象である。
5. **正例・負例のテスト設計。** 公開 production 経路 (`_floor_preflight_freeze_allowlist` の実体と
   `_assert_freeze_allowlist`) を通し、(i) versioned resolution で通る正例、(ii) resolved protocol の
   bytes を 1 byte 変えた負例、(iii) legacy resolution で従来どおり通る正例、を nodeid 案つきで書け。
   負例は「その gate を外したとき初めて緑になる」ものにせよ (他の gate が先に赤を出す負例は帰属しない)。
   既存テストのうち改名・削除・期待値変更が必要なものを nodeid で全列挙せよ。
6. **変異事前登録の候補。** この修正を殺す変異 (mutation) を 4〜6 件、対象 file:line と
   期待失敗 nodeid の対応で提案せよ。

## 禁止

- コードを書き換えない。patch も出さない。commit しない。
- 凍結成果物の bytes を変える案 (legacy の再封印) を出さない — D1936 項 11 が却下済み。
- `freeze_verification_hold.HELD` の解除、`HELD_CHECK_IDS` の変更、hold の射程拡大を出さない
  (それぞれユーザー明示解除のみ / 受理集合を広げる向き)。
- 受理集合を広げる案を出さない。同じ強度の検査を正しい対象へ向けるだけにする (規律 2)。
- `FORMULA_ID`、result schema の既定 (v4)、`launch_floor_attempt()` /
  `launch_probed_floor_attempt()` の署名・挙動を変える案を出さない。
- attempt registry の slot 一意性、B2 (inspector) の被覆全単射照合、本番共有 root の fixture 残存に
  触る案を出さない (D1936 項 12 / 項 13 と本依頼で scope 外)。
- official campaign の投入を含む案を出さない。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を足さない。本題だけを扱う。

## 制約

書込可能な tmp が無いので pytest を走らせる必要はない。静的検査でよい。テスト実測は親が行うので、
走らせていない検査を緑と書かないこと。予算が尽きそうなら途中結論を下記の出力形式どおり書いて終われ
(無出力が最悪である)。

## 出力形式

- `## 現状` — 実際に読んだ file:line で欠陥 2 件を再確認した結果
- `## 変更計画` — file:line 粒度。各項目に「なぜこれが最小か」を 1 行
- `## 上記 6 項目への回答`
- `## テスト計画` — nodeid 案、正例 1 / 負例 2 以上、既存テストへの影響の全列挙
- `## 変異事前登録の候補`
- `## 残る不確実性` — 親が実測で決めるべき点
- `## 総括` — 3〜8 行
