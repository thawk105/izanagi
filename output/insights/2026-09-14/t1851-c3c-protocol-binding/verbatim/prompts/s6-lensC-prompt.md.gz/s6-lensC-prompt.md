単独段 dispatch: stage=review; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s4-adjudication.md` — **段 4 裁定。実装の正本。** 裁定 1 の署名、plan v2 の 14 項目、確定 5 nodeid、禁止事項
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/s5-implementation.diff` — 実装差分の逐語
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s5-author.md` — 実装子の自己報告
4. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py` — 統合後の現物
5. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py` — 統合後の現物
6. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語

repository root は上記 wave worktree である。他の worktree を読み書きしてはならない。

## 依頼 — レンズ C: 裁定適合と受理集合の実差分

**実装が段 4 裁定どおりか、受理集合が裁定 1 の許した範囲を超えていないかを検査せよ。**
実装子の自己報告を信じず、現物で確かめる。所見ごとに real / refuted を付け file:line 根拠を書け。

必ず扱うこと。

1. **裁定 1 の署名適合。** `_validate_freeze_allowlist_path`、`_assert_freeze_allowlist`、
   `clean_scan_digest`、`_official_launch_preflight` の 4 つが、裁定 1 に書かれた署名と条件式の
   とおりになっているか。**exact 一致以外 (命名規則・正規表現・prefix・`in` 演算子での部分一致) で
   path を受理していないか。** 1 箇所でもあれば real として挙げよ。
2. **`protocol_relpath` の出所。** 各関数が呼び手から受け取った値だけを使っているか。
   関数内で resolver を呼んだり `_derived_reseal_protocol_relpath` から導出していないか。
3. **既定 `None` の挙動不変。** `protocol_relpath=None` のとき、受理する path 集合・
   `bounded_actual` の分類・`chain_records` の内容・digest の preimage が変更前と 1 bit も
   違わないことを条件式で示せ。違うなら real。
4. **`None` 戻り値の扱い。** `_require_supplied_protocol_authority()` が `None` を返す経路で
   `.path` を deref していないか。official 分岐で `None` のとき裁定 8 の fallback になっているか。
   `mode="pilot"` / `resume` / private core 直接呼出しの 3 経路それぞれで確かめよ。
5. **現状維持を命じた箇所が実際に不変か。** `historical_protocol` 比較 (旧 `:5278`)、
   journal `expected_header.protocol_sha256` (旧 `:5293`)、digest schema
   `s8b-clean-scan-digest/v3`、`build_launch_certificate` の field、`_PREFLIGHT_FIXED_FILES` の
   既存メンバー、`_CHAIN_RECORD_PATTERNS`。**差分に現れていないことだけで不変と判定せず、
   統合後の現物を読んで確かめよ。**
6. **禁止事項の違反。** `freeze_verification_hold.py` の変更、凍結成果物の bytes 変更、
   既存テストの改名・削除・期待値変更・skip 追加、`FORMULA_ID`、result schema の既定、
   `launch_floor_attempt` / `launch_probed_floor_attempt` の署名。
   既存テストの**関数名集合が減っていないか**を差分で数えよ。
7. **hold の二重比較。** 実装後、hold が保留する比較と無条件検査が同じ対象を見ているか。
   成果物へ書くべき限定文 (裁定 3) を超える主張が、コメントや docstring に混入していないか。
8. **規律 2。** 実装のどこかに「通すために検査を弱める」向きの変更がないか。
   拒否条件を消した箇所、例外を広げた箇所、`try/except` で拒否を飲み込んだ箇所を探せ。
9. **成果物影響。** 各所見について、放置したとき certified 選択・レポート・台帳の値・受理集合・
   参照がどう変わるかを 1 行で書け。**書けない所見は must-fix にせず nit とせよ。**

## 禁止

- 実装を弁護しない。良い点の列挙に紙面を使わない。
- コードを書き換えない。patch を出さない。commit しない。
- hold の解除、`HELD_CHECK_IDS` の変更、凍結成果物の bytes 変更を提案しない。
- scope 外の層 (attempt registry の slot 一意性、B2 inspector の被覆全単射照合、本番共有 root の
  fixture 残存、official 投入) へ広げる案を出さない。real なら「裁定パッケージ候補」へ分けよ。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を提案しない。

## 制約

書込可能な tmp が無いので pytest は不要。静的検査でよい。テスト実測は親が行うので、
走らせていない検査を緑と書かないこと。予算が尽きそうなら途中結論を下記の形式で書いて終われ。

## 出力形式

- `## 所見` — `real` / `refuted`、must-fix / nit、深刻度、file:line 根拠、再現の筋道、最小の是正案、成果物影響 1 行
- `## 裁定適合表` — 裁定 1 の 4 署名と plan v2 の 14 項目それぞれに 適合 / 不適合 / 未実装
- `## 裁定パッケージ候補`
- `## 総括` — 3〜8 行

## この時点までの経緯 (必ず前提にせよ)

- 段 5 実装子は pytest を 1 件も実走できなかった (sandbox で runner rc=16)。
- 親の実走: 新規 5 nodeid は **5 passed**。`test_s8b_ratified_freeze.py` は当初 **28 failed**。
- 28 failed の発生源は、段 5 が入れた `_protocol_authority is None` の fail-closed だった。
  親は **裁定 8** を追記して plan v2 項 3 を撤回し、official 分岐を
  「record があれば `.path`、無ければ `_FLOOR_PROTOCOL_REL`」の fallback へ直させた。
  裁定 8 の全文は射影 1 の file 末尾にある。**裁定 8 自体も検査対象である。**
- 段 6 fix 子はこの 1 箇所を直した後、model call 上限 100 に当たって **報告を出さずに死んだ**
  (`limit_trigger: max_model_calls`、`codex_exit_code: -15`)。したがって
  **fix の自己報告は存在しない。** 親は差分を現物で監査し「裁定 8 の署名どおり・他の変更ゼロ・
  テスト file は byte 一致」と確認したが、**この監査を裏取りするのはあなたの仕事である。**
- 親の実走 (fix 後): `test_s8b_ratified_freeze.py` は **82 passed**。

裁定 8 について特に見るべき点。

1. fallback が規律 2 を緩めていないか。production の official 経路が resolved protocol へ
   exact に束縛されることを、コードの呼び出し順で確かめよ。
2. `_run_campaign_core` の非 test 呼び手が公開 wrapper 1 箇所だけであるという親の主張を、
   repo 全体の参照で数え直せ。違えば real。
3. fallback が効く経路 (record なしの official) で、変更前と挙動が 1 bit も違わないことを確かめよ。
