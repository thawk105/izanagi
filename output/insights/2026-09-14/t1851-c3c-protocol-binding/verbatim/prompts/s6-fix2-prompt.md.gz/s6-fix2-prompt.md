単独段 dispatch: stage=fix; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/s4-adjudication-with-item11.md` — **段 4 裁定 + 追記。正本。** 末尾の **裁定 11** が本依頼の内容である
2. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/conftest.py` — 編集対象
3. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_real_repo_serialization.py` — 編集対象
4. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_floor_campaign.py` — **読むだけ。** `:15329-15360` が clone 元を読む helper、`:15510-15566` が対象 4 テスト

repository root は `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author` である。
**ここ以外の worktree・checkout を読み書きしてはならない。**

## 所有範囲 (これ以外の file を 1 byte も変えてはならない)

- `orchestrator/tests/conftest.py`
- `orchestrator/tests/test_real_repo_serialization.py`

`test_s8b_floor_campaign.py` と `orchestrator/campaign/` 配下は**所有外**である。読むだけにせよ。

## 所見と依頼

**所見 (real / must-fix):** 新規の公開経路テスト 4 件は `git clone` で**実親 repo と実共有 submodule を
clone 元として読む** (`test_s8b_floor_campaign.py:15346,15350` の `git clone <ROOT>` と
`git clone <ROOT>/external/ccbench`)。しかしこの 4 nodeid は `conftest.py` の real-repo 分類に
未登録で、P/S lock も `xdist_group("real-repo")` も付かない。受入全走は 2 shard / 8 worker で
回るため、lock の無い共有 repo 読取りは非帰属赤の源になる。

**同じ file の同型テストは既に登録済みである** —
`test_s8b_floor_campaign.py::test_real_seal_protocol_to_floor_official_core_e2e` は
`_REAL_REPO_BOTH_READER_NODES` にあり、golden 側にも「helper が実親 repo と実共有 submodule を
clone source として直接読む reader」という注記が付いている。**登録が確立した慣例であり、
未登録は慣例違反である。**

**依頼: 次の 4 nodeid を、この既存の慣例どおり「親 repo 読取り + ccbench 読取り」の分類へ登録せよ。**

```
test_s8b_floor_campaign.py::test_public_official_preflight_accepts_versioned_protocol
test_s8b_floor_campaign.py::test_public_official_preflight_accepts_legacy_protocol
test_s8b_floor_campaign.py::test_public_official_preflight_rejects_resolved_protocol_byte_drift
test_s8b_floor_campaign.py::test_public_official_preflight_rejects_legacy_byte_drift_after_capture
```

**`test_freeze_allowlist_path_rejects_unselected_versioned_protocol` は clone しないので登録しない。**

## 閉包を自分で引ききること

`conftest.py` の `_build_real_repo_access_map()` は、分類 partition が互いに素であることと、
その和が `_REAL_REPO_NODE_INVENTORY` と**完全一致**することを起動時に検査する
(一致しなければ `RuntimeError`)。`test_real_repo_serialization.py` は同じ集合を golden literal で
持ち、`test_real_repo_group_collection_exactly_matches_canonical_nodes` が exact 照合する。

**したがって、片方だけ直すと必ず赤になる。** 次をすべて自分で洗い出して直せ。親の列挙を網羅と
見なすな。

- 分類 partition の集合 (`_REAL_REPO_BOTH_READER_NODES` など) と `_REAL_REPO_NODE_INVENTORY`
- `test_real_repo_serialization.py` の対応する golden literal
- 件数を literal で持つ assertion (集合の要素数、shard 分割数など)
- 優先順序を literal で持つ assertion
  (`test_real_repo_priority_order_is_literal_and_writers_follow_barrier` を読め)
- 他に同じ集合・件数・順序を literal で持つ場所が無いか、識別子名・件数・nodeid 文字列の
  **3 通りの検索**で確かめよ (path 検索だけでは見つからない型がある)

## 必ず実走せよ — 走らせ方

**この sandbox では `tools/run_tests.py` は rc=16 で走らない。`python -m pytest` も拒否される。**
test file 末尾の自走 harness を使う。

```
PYTHONPATH=. python3 orchestrator/tests/test_real_repo_serialization.py
```

`PYTHONPATH=.` は必須である。`conftest.py` の import 時検査は、この走行で必ず通る。

**実走は上の 1 本に絞れ。** `test_s8b_floor_campaign.py` の自走は非常に重く、前回の fix 子は
model call 上限で報告を出さずに死んだ。所有外 file の全走は親が行う。
**実走した command と pass/fail の実数・rc を必ず報告せよ。** 走らなければ、試した command と
出た rc・stderr の実文言を報告せよ (「実走不能」とだけ書かない)。

## 禁止

- docs を編集しない。`output/` 配下を編集しない。commit しない。`git add` もしない。
- 所有外の file を編集しない。
- **登録簿と golden の拡張以外の期待値を変えない。** 既存 nodeid の分類を動かさない。
  既存テストの改名・削除・skip 追加・反転・緩和をしない。
- **新しい lock 機構・新しい分類軸・新しい gate・新しい golden file を作らない。**
  既存の分類へ 4 nodeid を足すだけにする。
- 凍結成果物の bytes を変えない。`freeze_verification_hold.py` を変えない。
- 期待値へ揮発 payload (working tree hash、現行 commit、実行時刻、絶対 path、ホスト名) を焼き込まない。
- fixture へ現行 hash を差し込んでテストを甘くしない。
- official campaign を投入しない。`qsub` しない。
- 仮想リスク向けの追加をしない。本題だけを直す。

## 報告

- 緑には実走 nodeid と範囲を併記する。実走できなかったものは `closed` と申告せず
  「実装済み・未実走」と書く。
- 所見への対応表を `closed` / `partial` / `regressed` で出す。
- **自分が引いた閉包の一覧** (直した箇所と、検索して「直す必要が無い」と判断した箇所) を出せ。
- 所有外 caller・共有 fixture・consumer test の波及可能性を静的に列挙する。

## 出力形式

- `## 所見への対応表`
- `## 直した内容` — file:line 粒度
- `## 引いた閉包` — 直した箇所 / 検索したが不要と判断した箇所、各々に検索 command
- `## 実走結果` — command、nodeid、pass/fail の実数、rc
- `## 波及可能性の静的列挙`
- `## 未実走・未確認`
- `## 総括` — 3〜8 行
