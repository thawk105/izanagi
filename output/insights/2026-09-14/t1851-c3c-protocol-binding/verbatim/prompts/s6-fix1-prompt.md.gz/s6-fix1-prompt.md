単独段 dispatch: stage=fix; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/s4-adjudication-with-item8.md` — **段 4 裁定 + 裁定 8 (追記)。実装の正本。** 裁定 8 が plan v2 項 3 を訂正している
2. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/campaign/s8b_floor_campaign.py` — 編集対象 (前段の自分の実装が入っている)
3. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_floor_campaign.py` — 編集対象
4. `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author/orchestrator/tests/test_s8b_ratified_freeze.py` — **読むだけ。** `:988` が衝突源
5. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/rulings-d1936-items-11-15.md` — D1936 項11〜15 の逐語

repository root は `/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-c3c-author` である。
**ここ以外の worktree・checkout を読み書きしてはならない。**

## 所有範囲 (これ以外の file を 1 byte も変えてはならない)

- `orchestrator/campaign/s8b_floor_campaign.py`
- `orchestrator/tests/test_s8b_floor_campaign.py`

`test_s8b_ratified_freeze.py` と `test_s8b_ratified_verify.py` は**所有外**である。読むだけにせよ。

## 所見と依頼

**所見 (real / must-fix):** 前段の実装が `_run_campaign_core` の official 分岐へ
`_protocol_authority is None` の fail-closed を入れたため、`test_s8b_ratified_freeze.py` が
**28 件赤**になる。親が実走で確認した (Pegasus request `996095.nqsv`、全件の発生源は
`s8b_floor_campaign.py:7526`)。

**依頼: 裁定 8 の署名どおりに直せ。**

```
_run_campaign_core(..., _protocol_authority=None)
    mode == "official" のとき:
        protocol_relpath = (
            _FLOOR_PROTOCOL_REL if _protocol_authority is None
            else _protocol_authority.path
        )
    以後の preflight / _official_launch_preflight へこの値を渡す。
```

- `_protocol_authority is None` を理由に official を拒否する分岐を**削除**する。
- `_protocol_authority` から `.path` 以外を読まない。
- 公開 wrapper (`run_campaign`) に「record が非 None であること」の assert を**新設しない**
  (`_require_supplied_protocol_authority` が解決失敗時に例外を投げるので恒真になる)。
- 他の変更をしない。前段の実装の残りは裁定どおりなので触らない。

## 必ず実走せよ — 走らせ方

**この sandbox では `tools/run_tests.py` は rc=16 で走らない。`python -m pytest` も拒否される。**
所有テスト file の末尾にある自走 harness を使う。

```
PYTHONPATH=. python3 orchestrator/tests/test_s8b_floor_campaign.py
```

`PYTHONPATH=.` は必須である。**実走した nodeid と pass/fail の実数を必ず報告せよ。**
このやり方でも走らなければ、試した command と出た rc・stderr の実文言を報告せよ
(「実走不能」とだけ書かず、何をどう試して何が返ったかを書く)。

所有外 file の実走 (`test_s8b_ratified_freeze.py` など) は親が行う。試みてもよいが、
走らなければ親へ回せ。

## 禁止

- docs を編集しない。`output/` 配下を編集しない。commit しない。`git add` もしない。
- 所有外の file を編集しない。
- **既存テストの期待値を変更・反転・緩和・skip・削除しない。既存テストを改名・削除しない。**
  赤なら実装が誤りである。期待値が誤りだと判断したら実装を変えず報告して止めよ。
- 凍結成果物 (`output/s8b-freeze/`、`output/s1-freeze/`) の bytes を変えない。
- `freeze_verification_hold.py` を変えない。
- `historical_protocol` 比較と journal `expected_header.protocol_sha256` を変えない。
- `_PREFLIGHT_FIXED_FILES` の既存メンバー、`_CHAIN_RECORD_PATTERNS`、digest schema
  `s8b-clean-scan-digest/v3`、`build_launch_certificate` の field、`FORMULA_ID`、
  result schema の既定、`launch_floor_attempt` / `launch_probed_floor_attempt` の署名を変えない。
- 受理する allowlist path を、裁定 1 が許した exact 1 件以外に広げない。
  命名規則・正規表現・prefix 一致で受理してはならない。
- official campaign を投入しない。`qsub` しない。
- 期待値へ揮発 payload (working tree hash、現行 commit、実行時刻、絶対 path、ホスト名) を焼き込まない。
- fixture へ現行 hash を差し込んでテストを甘くしない。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を足さない。

## 報告

- 緑には実走 nodeid と範囲を併記する。実走できなかったものは `closed` と申告せず
  「実装済み・未実走」と書く。子の実走は親の全走を代替しない。
- 所見への対応表を `closed` / `partial` / `regressed` で出す。
- 所有外 caller・共有 fixture・consumer test の波及可能性を静的に列挙する。

## 出力形式

- `## 所見への対応表` — closed / partial / regressed
- `## 直した内容` — file:line 粒度
- `## 実走結果` — command、nodeid、pass/fail の実数、rc
- `## 波及可能性の静的列挙`
- `## 未実走・未確認`
- `## 総括` — 3〜8 行
