単独段 dispatch: stage=focus; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding

## 必読事項の射影

次の絶対パスを読む。読めなければ即停止し、読めなかったパスを報告せよ。

1. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/output/insights/2026-09-14/t1851-c3c-protocol-binding/s4-adjudication.md` — **段 4 裁定と全追記 (裁定 8〜13)。正本。**
2. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s6-lensC.md` — レビュー C の所見
3. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s6-lensD.md` — レビュー D の所見
4. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/artifacts/dev-wave-t1851-c3c-protocol-binding/s6-fix2.md` — fix 子 2 の自己報告
5. `/work/1/SFC/tanab/dev-wave-jobs/dev-wave-t1851-c3c-protocol-binding/mutation-probe-spec.json` — 変異 spec (probe 版)
6. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/conftest.py` — 統合後の現物
7. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_real_repo_serialization.py` — 統合後の現物
8. `/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py` — 統合後の現物

repository root は上記 wave worktree で、HEAD は `0bbd5b5be` (clean) である。
worktree 内は自由に検索してよい。**書き込みはしない。**

## 依頼 — fix 後の焦点再レビュー

**所見ごとに `closed` / `partial` / `regressed` の対応表を出すこと。表が無ければ root cause が
閉じたとは判定しない。** 実装子・fix 子・親の自己報告を信じず現物で確かめる。

### 1. レビュー所見の対応状況

レビュー C / D の real 所見 (C-1/D-1、C-2/D-5、D-2、D-3、D-4) について、親の裁定 9〜13 と
統合後の現物を突き合わせ、closed / partial / regressed を付けよ。

- **裁定 9** は「テストを拡張せず主張範囲を訂正する」とした。その根拠として親は
  「preflight 以後に legacy 固定 path (`_FLOOR_PROTOCOL_REL`) を束縛する consumer は無い」と
  主張している。**この主張を repo 全体で数え直せ。** 反例が 1 つでもあれば regressed。
- **裁定 11** は登録簿の拡張を命じた。fix 子 2 は「inventory と分類済み golden は 141→145、
  両資源 reader は 64→68、資源対象は 139→143」と報告した。**この 3 組の件数を自分で数え直せ。**
  数えた command を書け。違えば real。
- **裁定 11 の閉包が本当に閉じたか。** 件数・順序・集合を literal で持つ場所を、識別子名・
  件数の数字・nodeid 文字列の **3 通りの検索**で洗い直し、更新漏れが無いか確かめよ。
  fix 子 2 が「不要と判断した」箇所の判断も検算せよ。
- **裁定 12** の逐語一意性。射影 5 の spec の各 `old` が現物に **ちょうど 1 箇所**あるか数え直せ。

### 2. 変異の単一理由性 (これが本依頼の重点)

レビュー D は M1 / M2 / M4 が過剰決定だと指摘した。親は裁定 10 で「probe で実 node 集合を採取し、
単一理由が立つものだけ kill に数える」「M5 を
`            if actual_sha256 != expected:` → `            if False:` へ再照準する」とした。

射影 5 の spec の 6 変異それぞれについて、**読解で次を決めよ。**

- 変異を入れたとき、確定 5 nodeid (P1/P2/N1/N2/N3) のうちどれが赤になるか。**予測集合を書け。**
- 赤理由が 1 つに絞れるか。同じ入力を拒否する層が前後・内側にあるか (file:line で)。
- 絞れない変異について、**単一理由が立つ最小の再照準案**があれば出せ。無ければ
  「冗長 gate として単独変異の証拠から外す」と明記せよ。
- 親の M5 再照準 (`if False:`) が単一理由になるか。N1 と N2 の両方を落とすなら、それは
  1 つの gate の無効化なので単一理由と数えてよいか、理由付きで判定せよ。

### 3. 非帰属赤の判定の検算

親は `test_real_repo_serialization.py::test_real_repo_writers_do_not_materialize_oracle_environment_candidates`
の赤を次の実測で非帰属と判定した。**この判定が正しいか読解で検算せよ。**

- 同 file 単独走 (55 passed / 1 failed / 1 skipped)、同 nodeid 単独走 (1 failed)。
- 変更面を基底 `7e73d448e` へ全部戻した状態でも同 nodeid は 1 failed。
- 内側の `test_p3_s4_loop.py::test_drive_iteration_checkpoint_survives_across_calls` は単独で 1 passed。
- `test_p3_s4_loop.py` と `test_real_repo_serialization.py` を**一緒に**収集すると
  **467 passed / 1 skipped** で赤が消える。

親の結論は「狭い file 選択走に固有の偽赤であり、受入全走 (全件収集) では出ない」である。
**wrapper が `orchestrator.tests.test_p3_s4_loop` を import して関数を直接呼ぶ構造を読み、
収集有無で挙動が変わる機序を file:line で特定せよ。** 特定できなければ「機序未特定」と書け
(推測で埋めない)。受入全走で再現しうると判断する根拠があれば real として挙げよ。

## 禁止

- 実装を弁護しない。良い点の列挙に紙面を使わない。
- コードを書き換えない。patch を出さない。commit しない。
- 既存テストの期待値変更・skip・削除を提案しない。
- 凍結成果物の bytes 変更、hold の解除、`HELD_CHECK_IDS` の変更を提案しない。
- scope 外の層 (attempt registry の slot 一意性、B2 inspector の被覆全単射照合、本番共有 root の
  fixture 残存、official 投入) へ広げる案を出さない。real なら「裁定パッケージ候補」へ分けよ。
- 仮想リスク向けの新 gate・新検査・新台帳・一般化を提案しない。
- 成果物影響 (certified 選択・レポート・台帳の値・受理集合・参照がどう変わるか) を 1 行で
  書けない所見を must-fix にしない。
- 件数を書くときは数えた command と対象集合を併記せよ。数えていない件数を書かない。

## 制約

書込可能な tmp が無いので pytest は不要。静的検査でよい。テスト実測は親が行うので、
走らせていない検査を緑と書かないこと。予算が尽きそうなら途中結論を下記の形式で書いて終われ。

## 出力形式

- `## 所見対応表` — 所見ごとに closed / partial / regressed と現物根拠
- `## 変異の単一理由性` — 6 変異それぞれの予測赤 nodeid 集合・単一理由の成否・再照準案
- `## 非帰属赤の検算` — 機序の特定 / 未特定、受入全走での再現可否の判断
- `## 新たな所見` — real / refuted、must-fix / nit、成果物影響 1 行
- `## 総括` — 3〜8 行
