## 所見

以下、`C` は [s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/campaign/s8b_floor_campaign.py)、`T` は [test_s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-c3c-protocol-binding/orchestrator/tests/test_s8b_floor_campaign.py)、`S4` は指定の裁定文書を指します。判定は静的読解です。

- **real / must-fix / 中 — P1/P2 は certificate のファイル発行に未到達。**  
  `T:15484` で実 preflight が返り、`:15497` で観測例外を投げます。実際の `issue_launch_certificate` は `C:7574` なので通りません。公開入口・実 preflight・両 scan・strict 検証は通りますが、「発行まで」の要求は未充足です。最小是正は、隔離先で実 issuer による発行を確認することです。計測へ進める必要はありません。  
  **成果物影響:** P1/P2 の到達保証は「certificate 構成・strict 検証まで」に限定されます。

- **real / must-fix / 中 — M4 の赤は hash gate に帰属しない。**  
  `C:5325` を capture bytes の自己 hash に変えると、N1 が注入した空白を含む hash が allowlist に入り、`T:15470` の独立期待値との比較が先に失敗します。これを通しても `T:15488` の digest 期待値が拒否します。`C:5486` は変更後の期待値と実 bytes が一致するため拒否しません。最小是正は、M4 を「scan hash 比較の kill」と数えず、期待値の出所を検査する観測 assertion へ帰属を訂正することです。  
  **成果物影響:** N1 自体の帰属と、M4 の kill 帰属は別に記録する必要があります。

- **real / must-fix / 中 — 新規公開経路テストの共有 repo reader 分類が漏れている。**  
  `T:15346,15350` は実 ROOT と実 ccbench を clone 元として読みます。しかし公開経路の新規 nodeid は `conftest.py` の分類にありません。`conftest.py:2128,2209` は未登録を `None` とし、`:1436` は lock を取得せず通します。既存の同種 reader は `conftest.py:590`、独立集合は `test_real_repo_serialization.py:192` にあります。  
  集計コマンドは `python3` による AST の `test_public_official_preflight_` 抽出と、両分類ファイルへの `str.count(name)`。対象 **4 関数すべて出現 0** でした。  
  **成果物影響:** 単独の成功結果では共有資源を使う受入時の隔離を保証できません。所有範囲外の是正は下記へ分離します。

- **real / must-fix / 低 — 変異事前登録に逐語 old がない。**  
  `S4:220–225` は位置と意味の指定であり、置換用 old は登録されていません。さらに M3 の条件行を改行なしで切り出すと M6 の深いインデント行にも部分一致します。最小是正は下表の一意な逐語を登録することです。  
  **成果物影響:** 現状では「事前登録済み old の一意性を確認した」とは報告できません。

- **real / nit / 低 — fix 前後の独立証拠が不足。**  
  指定 `s5-implementation.diff:180–183` 自体が既に fallback です。diff の旧 blob に各 hunk をメモリ上で適用した結果も、index の後側 blob も、現在の C/T と byte 一致しました。したがって現在の署名とテスト file の一致は確認できますが、「fail-closed 版から fix がその箇所だけ変えた」という履歴は、この資料だけでは裏取りできません。最小是正は既存の fix 前 snapshot を監査証拠として対応付けることです。  
  **成果物影響:** fix の限定性は現状照合済み、時系列の独立監査は未成立です。

- **refuted / 修正不要 — N1/N2 の先行 gate 誤帰属、期待値の揮発値焼込み、両層 stub による恒真化。**  
  帰属は下表の条件付きで成立します。期待 hash は drift 前に Git blob から取り、scan の戻り値から作っていません（`T:15420–15426`）。時刻・ホスト情報は既存予約 fixture の入力にありますが、固定期待値として焼かれていません（`T:2478–2488`）。観測 wrapper は実関数を呼びます。  
  **成果物影響:** 新規テスト全体が恒真である根拠はありません。ただし実行時 ROOT の commit・材料に依存するテストです。

## 負例の帰属表

| 負例 | 判定 | 先行 gate と比較除去時の読解 |
|---|---|---|
| N1 | **帰属成立。ただし現行 HELD 下** | 注入 `T:15464` は実 authority の return 後。`C:984` の committed bytes 比較、`:7177,7179` の supplied bytes/hash 比較は済んでいます。`C:5248` は HELD により通らず、他の preflight 検査は legacy・journal を対象とします。対象 entry の `C:5486` だけを両 scan で除けば、allowlist と digest は元の期待値を保持し certificate 観測まで到達する読解です。HELD 解除時は `C:5248` が先に拒否します。 |
| N2 | **帰属成立** | 注入 `T:15474` は実 preflight return 後なので、historical 比較 `C:5281` より後、最初の scan `C:5607` より前です。capture/allowlist は既に確定しています。両 scan の legacy hash 比較だけを除けば、後続に legacy bytes を再拒否する gate はありません。 |
| N3 | **validator への帰属成立。scan 枝は過剰決定** | `T:15582` は validator を直接呼び、`C:5417` の「有界範囲外」で拒否されます。M3 を入れるとここが例外を出さず赤になります。一方 `T:15584` の scan 枝は validator を緩めても、実在集合 `{selected}` と allowlist `{other}` が違い、`C:5473` で拒否されます。この枝を M3 の単一理由性の証拠には数えられません。 |

N1/N2 の対照は `T:15439–15457` で実 `_assert_freeze_allowlist` の対象比較だけを変更し、両 scan に同じ実体を使います。検索・namespace 検査を stub していません。比較除去後の「到達可能」と、負例テスト自体の `pytest.raises` が赤になることは区別しています。

## 変異 anchor 表

`S4` に逐語 old がないため、以下は**登録候補**です。出現数は `python3` の `C_text.count(old)` で、対象を統合後 C 全文として数えました。

| 変異 | 最小 old 候補・位置 | 一意性 | 単一理由性 |
|---|---|---|---|
| M1 | `        _protocol_authority=protocol_authority,` — `C:7246` | 1 | P1 の `T:15469` が先に拒否。これを除いても allowlist assertion・hash 拒否が残ります。公開配線の検査として扱い、単一の hash gate の kill としない。 |
| M2 | `        _FLOOR_PROTOCOL_REL: hashlib.sha256(captured[_FLOOR_PROTOCOL_REL]).hexdigest(),` — `C:5318` | 1 | P1 の `T:15470` が先に拒否。さらに `C:5473` の scope 比較も拒否するため、単一理由性は不成立。 |
| M3 | `\n            or (protocol_relpath is not None and rel == protocol_relpath)):` — `C:5415` | 改行付き 1。改行なし部分文字列は 2 | validator 直接呼出し `T:15582` なら成立。scan 枝には別の scope gate が残る。 |
| M4 | `    allowlist[effective_protocol_relpath] = protocol_sha256` — `C:5325` | 1 | 不成立。`T:15470`、後続の digest assertion が拒否。scan hash gate の実績ではない。 |
| M5 | `            if actual_sha256 != expected:` — `C:5486` | 1 | N2 の時系列では成立。legacy のみ除外し、両 scan に適用する必要がある。 |
| M6 | `\n                        or (protocol_relpath is not None and rel == protocol_relpath)):` — `C:5464` | 1 | 成立する読解。selected が chain に移り、`C:5473` の bounded 集合比較で拒否。 |

実測の mutation kill は報告しません。

## consumer / pin 閉包の追加分

**consumer**

- 裁定 6 にない直接の source consumer は `test_floor_submit_receipt.py:279–306`。core の reservation 分岐を AST で検査します。変更箇所による破綻は見当たりません。
- 新規テストから生じた追加 consumer は、上述の `conftest.py` と `test_real_repo_serialization.py` の reader 分類です。
- `test_s8b_dependency_prefix_bridge.py:14` は T を import しますが、参照する helper は今回変更した campaign wrapper ではありません。import だけを理由に直接 consumer と数えません。
- private symbol 名と新 keyword を production の `orchestrator/`・`tools/` 全体で `rg` 検索し、C 内を AST の Call/keyword/Name でも照合しました。`_run_campaign_core` の非 test 呼出しは **1 箇所、C:7233**。定義を除いた AST Call 集合です。
- 同じ AST 集計で、新 keyword `_protocol_authority` の引渡しは **1 箇所**、`protocol_relpath` の keyword 引渡しは **6 箇所**（`C:5429,5521,5609,5620,7538,7544`）でした。
- `test_s8b_protocol_builder.py:1614` の既定 `None` は versioned file を従来どおり chain に分類します。`:1617,1626` の期待値変更は不要です。

**裁定 8**

`C:7229 → 7189 → 7246 → 7525 → 7538/7544` の順で、実 resolver の record が exact path として渡ります。実 authority に `None` return はなく、production の保護を緩めるという所見は **refuted** です。

record なしでは実効値が legacy になり、capture 集合は旧集合と同じです。`C:5325` が legacy entry を旧来の `protocol_sha256` に上書きし、分類への追加条件も既存 fixed 集合に含意されます。実 preflight/scan の受理条件・allowlist・digest は旧経路と同じです。ただし callable seam には新 keyword が渡るので、「任意の旧 stub まで完全同一」という主張には拡張できません。

**pin**

path 検索に加え、別々に以下を検索しました。

- 全 file hash：旧 blob の sha256 を計算し `rg -l <sha256> orchestrator tools`。C/T の旧全文 golden は見つかりませんでした。
- 行番号：`lineno`、`splitlines()[` 等。変更行番号を固定した assertion は見つかりませんでした。
- source/正規表現：`getsource`、`source.index`、`re.search/fullmatch`。
- 関数集合・件数：`test_definitions`、`test_functions`、`test_names`、`startswith("test_")`。
- docstring：`__doc__`、`ast.get_docstring`。変更 docstring の逐語 pin は見つかりませんでした。

指定の `test_pegasus_floor_tools.py:1380–1393` は、現物文字列に対する index 順序・run-linked/journal 引数・禁止正規表現を静的に評価し、アンカーが維持されていました。pytest 成功を意味しません。

**既存関数名と所要台帳**

- コマンド：`python3` で diff 旧 blob `09cbd7703` と現物 T を `ast.parse` し、`def test_` 名集合を比較。**362 → 367、削除・改名による消失 0、追加 5**。
- コマンド：新規名集合を JSON 全文へ `str.count`。新規 nodeid は **5 件すべて未登録**。
- コマンド：`sum(v == 0 for v in duration_seconds_by_nodeid.values())`。既存台帳には **118 件のゼロ値**がありますが、`git show HEAD:<ledger>` と現物は byte 一致です。本変更による placeholder・合成秒の混入とは認定しません。親による成功 JUnit からの登録は残っています。

## 裁定パッケージ候補

**共有 repo reader 分類漏れ。** 新規公開経路 nodeid を、既存の parent/ccbench reader 分類へ登録する所有範囲の裁定が必要です。既存 golden の期待値変更案は本レビューでは提示しません。新しい lock 機構を設ける話ではありません。

## 総括

- N1/N2 の hash 比較への帰属は、現行 HELD と指定時系列の下で成立します。
- N3 は validator 直接呼出しで識別できますが、scan 枝は過剰決定です。
- M1/M2/M4 の赤を単一の hash gate の kill と数えることはできません。
- P1/P2 のファイル発行到達と、共有 repo reader 分類の閉包が未充足です。
- 裁定 8 の fallback は production の exact 束縛を維持します。fix 前後の独立証拠には留保があります。
- pytest・変異は未実走です。親申告の成功結果と本レビューの静的判定は分離しています。