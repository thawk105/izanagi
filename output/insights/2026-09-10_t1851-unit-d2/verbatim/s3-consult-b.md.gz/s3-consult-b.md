結論は「現プランのまま author 投入は拒否、最小修正後に受理」です。静的検査のみで、pytest は未実走です。

### D2-C01 高: producer と consumer の接続が受入対象から抜けている

- file:line: [s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_campaign.py:7389)、[同](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_campaign.py:7962)、[test_s8b_floor_campaign.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_floor_campaign.py:15061)
- 実在反例: `production` 判定を恒偽にする、または finalization の prefix 捕捉を外す変異でも、plan記載の consumer、registry、floor-stats テストは手作業で proof を供給するため通り得る。
- 成果物影響: consumers は v5 を読めても producer は v4 のままとなり、D1341 の一括 land を実証できない。
- 最小修正: 既存の `test_default_production_result_is_v5`、`test_v5_prefix_covers_every_consumed_non_competing_session`、`test_finalize_pending_replays_live_v5_prefix` を受入 nodeid に追加する。新規 gate は不要。
- scope: 内。

### D2-C02 高: real-registry fixture が低層 append で機構を飛ばす余地がある

- file:line: [s8b_floor_attempt_launcher.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_attempt_launcher.py:386)、[s8b_attempt_registry.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_attempt_registry.py:2513)、[attempt_registry_core.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/attempt_registry_core.py:39)
- 実在反例: production plan の binding は freeze、protocol、schedule の3値だけで、7-key proof に manifest/run identity はない。さらに正規 v2 reservation は issued consumption marker を必須とする。fixture が core row を直接生成して JSONL を差し替えると inspector は実走しても、producer adapter と marker 機構は通らない。
- 成果物影響: F649 型の偽陽性となり、「実装済み producer と接続した」とは言えない。同一 freeze/protocol/schedule で manifest bytes だけ異なる別 run の proof も区別できない。
- 最小修正: helper は consumer の実 root、manifest hash、run id/path、cells、schedule を受け、正規 launcher／issued marker 経路で reservation を作る。困難なら consumer fixture は「live prefix 検査」の証拠に限定し、producer 接続は D2-C01 の既存テストで別途実証する。
- scope: fixture の正直性と受入選定は内。proof 自体へ manifest/run 束縛を追加する変更は既存 verifier 改訂になるため外。

### D2-C03 中: 未知 schema の「従来どおり result-schema」は実コードと一致しない

- file:line: [s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:2352)、[同](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3274)、[同](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3311)
- 実在反例: v4-shaped unknown schema は最初の key 検査を通り、shared verifier の schema エラーが `cause="floor-projection"` に包まれる。v5-shaped unknown は余分な `attempt_registry` により先に `cause="schema-keys"` となる。後段の `cause="result-schema"` には到達しない。
- plan の単純実装反例: `schema=` を既存 try 内へ足すと `FloorContractError` は `cause="result-perf-condition"` に分類される。
- 成果物影響: 拒否集合は維持できるが、診断分類を「維持した」とは主張できない。
- 最小修正: top-level helper の冒頭で schema membership を独立検査し `result-schema` に正規化する。その場合は「従来維持」ではなく意図的な分類正規化と記し、`launch_validate` 公開入口で reason/cause を固定するテストを追加する。
- scope: 直接確認事項なので内。

### D2-C04 中: schema-aware 化で既存正例が確実に赤くなる

- file:line: [test_s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:1616)
- 実在反例: `test_degraded_result_observation_is_exactly_bound_to_manifest` は全値を `None` で作り、`result["schema"]` も `None` のまま helper を正例として呼ぶ。schema を `result_keys_for_mode` に渡す変更後は必ず拒否される。
- 成果物影響: 関連既存 suite を緑にできない。
- 最小修正: この fixture の schema を `FC.LEGACY_RESULT_SCHEMA` に明示設定する。
- scope: 内。

### D2-C05 中: holdout で `result["schema"]` を使うと controlled rejection を壊す

- file:line: [s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1426)
- 実在反例: schema 欠損 result に対し、plan 文言どおり添字参照すると exact-key 検査前に裸の `KeyError` となる。現在は `FreezeError` で拒否される。
- 成果物影響: 不正成果物が管理された consumer エラーではなく例外漏れになる。
- 最小修正: `result.get("schema")` を使い、readable membership を先に検査してから key 集合を導出する。
- scope: 内。

### D2-C06 中: ledger 3負例は作り方次第で対象変異を殺さない

- file:line: [s8b_floor_stats.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_stats.py:1134)、[s8b_attempt_registry.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_attempt_registry.py:1077)
- 実在反例:
  - shared root 全体を消す「欠損」は holdout admission で先に落ち、registry 読取を試さない。
  - JSONL を任意 byte で短縮すると replay-invalid で落ち、`len(rows) < row_count` 分岐を試さない。
  - 同一 slot の再予約は正当な後続 append にならない。
- 成果物影響: prefix-short 判定や registry 読取を削除した変異が生存し得る。
- 最小修正: 各負例を新鮮な fixture から作る。欠損は正規 `registry.jsonl` だけを除去する。短縮は保存した「より短いが replay 可能な完全 prefix」へ戻す。append は別 slot の正規 row とし、`proof.row_count < live row count` と旧 proof の再 inspection 成功を先に断言する。consumer 側では具体的な registry cause も検査する。
- scope: 内。

静的には、`RESULT_SCHEMA == LEGACY_RESULT_SCHEMA == "s8b-floor-result/v4"` なので `_synthetic_floor_result` の alias を明示 legacy へ替えるだけなら bytes は変わりません。ただし新しい既定 v4 分岐が registry helper を呼ばず、直列化順も変えないことが条件です。`FORMULA_ID` と凍結23件へ触れる必要はありません。C3c先行／FORMULA後続改版との差は持ち越しとして明記すればよく、本D2を止める理由にはなりません。

## 総括

blocking は producer nodeid の受入漏れと、real-registry fixture が正規 producer／marker 経路を飛ばし得る点です。加えて未知 schema の現行 cause は plan の記述と不一致で、既存 ratified 正例も schema-aware 化により赤くなります。上記の限定修正後なら、6ファイル範囲、既存 verifier／inspector 流用、新規 official 本走なし、凍結23件と `FORMULA_ID` 維持のまま author へ進められます。