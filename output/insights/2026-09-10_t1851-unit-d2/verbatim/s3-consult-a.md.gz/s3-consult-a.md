結論として、shared verifier 自体の前向き束縛は成立しています。ただし、現プランのままでは producer と consumer の接続、および短縮拒否の実証に穴があります。

### D2-C-01 — 高 — fixture が実 producer の v5 出力を通らない

- file:line: `orchestrator/tests/test_s8b_ratified_freeze.py:1014-1043`、`orchestrator/campaign/s8b_floor_campaign.py:7389`、`:6815-6853`
- 実在反例: ratified fixture は `measure_fn=_emitter_measure` を渡すため、`attempt_registry_plan` は `None` となり、producer が返す result は v4 です。計画する v5 分岐は、その v4 result に proof を後付けする構成です。holdout fixture も `s8b_v2_freeze_fixture.py:128-365` の手組み result です。
- 成果物影響: `assemble_result` が v5 schema を出さない、または proof を落とす変異があっても、新 consumer fixture は手動 v5 を受理して緑になれます。producer と両 consumer の一括 land を実証できません。
- 最小修正: 共通 helper の proof 取得を production と同じ `_build_floor_attempt_registry_plan` と `_capture_floor_attempt_registry_prefix` 経由に固定する。さらに既存の `test_default_production_result_is_v5`、`test_v5_prefix_covers_every_consumed_non_competing_session`、`test_finalize_pending_replays_live_v5_prefix` を受入対象へ含める。新 gate や新 checker は不要です。
- scope: 内。fixture と既存 producer node の受入だけです。

### D2-C-02 — 高 — pinned prefix が genesis だけだと短縮 gate を実証しない

- file:line: `orchestrator/campaign/s8b_attempt_registry.py:1023-1086`、`orchestrator/tests/s8b_v2_freeze_fixture.py:368-522`
- 実在反例: `create_attempt_registry` の直後に proof を捕捉すると `row_count == 1` です。その後に別 slot を append しても正当 append 正例にはなりますが、「row_count 未満へ短縮」は空 file にするしかなく、replay-invalid で先に落ちます。`len(rows) < row_count` の `attempt-registry-prefix-too-short` を削除する変異を殺せません。
- 成果物影響: 台帳短縮拒否を満たしたという受入記録が、欠損または壊れた JSON の拒否しか証明しない状態になります。また実 producer の proof が試行行を含む状態とも異なります。
- 最小修正: proof 捕捉前に production plan の slot で少なくとも一つの正規 reservation を完成させ、`row_count >= 3` を明示する。捕捉後は別 slot を正規 append し、`live_count > pinned_count`、旧 proof の再 inspection 成功、valid genesis までの短縮で `prefix-too-short` を確認する。
- scope: 内。既存 core、registry、inspector の利用だけです。

### D2-C-03 — 中 — 未知 schema の現在 cause とプラン記述が一致しない

- file:line: `orchestrator/campaign/s8b_ratified_freeze.py:2352-2408`、`:3274-3316`、`orchestrator/campaign/s8b_floor_stats.py:753-778`
- 実在反例: 正当な v4 result の `schema` だけを v6 に変えて周囲の hash と承認を再構築すると、現在の `launch_validate` は shared verifier で先に落ち、cause は `floor-projection` です。単純に schema を `result_keys_for_mode` へ渡すだけなら、今度は catch 節により `result-perf-condition` になります。どちらもプラン記載の `result-schema` ではありません。
- 成果物影響: 成果物は拒否されたままですが、公開 consumer の拒否分類が計画と異なります。
- 最小修正: `_validate_result_top_level_keys` の最初で schema が v4/v5 のどちらかを明示検査し、未知なら `cause="result-schema"` を返す。その後に schema-aware key 集合を導出する。
- scope: 内。明示された既存 cause 保持要件です。

### D2-C-04 — 中 — 「7 key 全てが独立 replay で拒否」は過大な説明

実際の拒否層は次のように分かれます。

| 変異 | 実際に効く層 |
|---|---|
| `schema`、`registry_schema`、型不正 | proof shape validator |
| `freeze_sha256`、`protocol_sha256` の内側だけの変更 | artifact との自己 cross-binding |
| `schedule_sha256` | 外部 schedule からの独立期待値 |
| `row_count`、`chain_head_sha256` | live prefix inspector |
| file 欠損、改竄、短縮 | 実 generation 全 replay |

- 実在反例: `attempt_registry.freeze_sha256` だけの変異は、independent expected を reported proof に置換しても `s8b_floor_stats.py:795-801` で拒否されます。したがって、その負例は独立照合変異を殺した証拠にはなりません。
- 成果物影響: runtime は現在 fail-closed ですが、受入記録がどの境界を証明したかを誤認します。
- 最小修正: 7 key matrix を上記の層別に記録し、型検査には既存 core proof tests、独立性には schedule、実 replay には row/head と file 3種を根拠として使う。
- scope: 内。test の期待と変異記録だけです。

### D2-C-05 — 低 — ratified の引用済み v4 正例は公開入口まで届かない

- file:line: `orchestrator/tests/test_s8b_ratified_freeze.py:1441-1472`
- 実在反例: このテストは `load_ratified_freeze` までで、`launch_validate` を呼びません。launch 層だけで v4 に registry を要求する変異は、この node 単独では生存します。
- 成果物影響: v4 非遡及受理の明示的証拠になりません。
- 最小修正: default fixture が `LEGACY_RESULT_SCHEMA`、`attempt_registry` 不在であることを明示し、その同じ fixture を `launch_validate` まで通す。既存 launch 正例への数行追加で足ります。
- scope: 内。

補足すると、`RESULT_SCHEMA` と `LEGACY_RESULT_SCHEMA` は現在どちらも v4 であり、serializer は key sort を行うため、holdout fixture の参照を後者へ固定する変更自体は静的には byte-neutral です。ただし実装前のため、新旧 fixture bytes の実比較はまだできません。

変異候補では「schema 引数除去」と「v5 を v4 key 集合で検査」は同じ v5 正例で落ちる重複証拠です。また後段の schema check や診断文字列だけの変異は、先行する top-level gate が同じ成果物を拒否するなら意味変異として数えるべきではありません。tail 完全一致への退行は正当 append 正例、v4 遡及は明示的な v4 `launch_validate` 正例でのみ直接殺せます。

pytest は read-only consult のため未実走であり、緑は申告しません。

## 総括

shared verifier は両公開 consumer から実際に呼ばれ、7 key exact validation、外部 binding 再導出、対象世代 replay、先頭 N 行 head 照合を行っています。v4 は registry 非要求、正当 append は受理する設計です。完成前に直すべき中心点は、手動 v5 fixture と実 producer の接続、`row_count > 1` の prefix fixture、未知 schema cause の先行分類です。