新規の実在欠陥は見つかりませんでした。P-F1/P-F2 の修正を前提に、追加 blocker なしの条件付き受理です。ただし静的レビューのみであり、緑判定ではありません。

## 所見

### D2-R01

- 重大度: 重大、受入阻害
- file:line: [s8b_v2_freeze_fixture.py:515](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:515)、[同:522](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:522)
- 具体的反例: ratified の正規 journal 全体には `campaign-start`、`round-start` などが含まれる。それを `sessions` に渡すため admission inspector が `session-invalid` で停止する。
- 成果物影響: production の誤受理ではないが、ratified の v5 正例と全負例が公開入口 `launch_validate` に到達せず、受入証拠を作れない。
- 最小修正: inspector に渡す値だけを `session-start` と `session` へ射影する。保存する journal と検査自体は変更しない。
- scope: 内
- 判定: real、既知 P-F1

### D2-R02

- 重大度: 中、拒否形式回帰
- file:line: [s8b_holdout_freeze.py:1446](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1446)、[s8b_ratified_freeze.py:2410](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:2410)
- 具体的反例: v4-shaped result の `schema` を `[]` または `{}` にすると、`frozenset` membership が `TypeError` を送出する。
- 成果物影響: holdout 公開入口および直接検証経路で、従来の管理された `FreezeError` または `RatifiedFreezeError` を維持できない。受理への弱体化ではない。
- 最小修正: hash を要求しない二つの literal 比較で v4/v5 を判定する。新 gate は不要。
- scope: 内
- 判定: real、既知 P-F2

### D2-R03

- 重大度: なし
- file:line: [s8b_holdout_freeze.py:1629](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1629)、[s8b_ratified_freeze.py:3287](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3287)、[s8b_floor_stats.py:1112](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_stats.py:1112)
- 具体的反例候補: v5 result を保ったまま実 registry を削除、改竄、または有効 genesis まで短縮する。
- 成果物影響: bypass しない。両 consumer は `repo_root`、実 protocol、freeze、schedule を shared verifier へ渡す。shared verifier は実値から binding を独立導出し、prefix inspector を実行する。
- 最小修正: なし
- scope: 内
- 判定: refuted

### D2-R04

- 重大度: なし
- file:line: [s8b_v2_freeze_fixture.py:437](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:437)、[同:480](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:480)、[同:504](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:504)
- 具体的反例候補: proof と期待値を同じ fixture dict から作る自己照合、または手書き JSONL による恒真正例。
- 成果物影響: 該当しない。production plan、実 genesis、実 registry writer、issued marker を使用し、最初の reservation 後に production capture を行い、その後に別 slot を append している。捕捉時は genesis と start、pre-observation seal により `row_count >= 3` となる。
- 最小修正: なし
- scope: 内
- 判定: refuted

### D2-R05

- 重大度: なし
- file:line: [s8b_floor_campaign.py:6816](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_campaign.py:6816)、[同:7962](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_campaign.py:7962)
- 具体的反例候補: production が v5 schema を付けても proof を載せない、または consumer fixture が producer capture と異なる形式を作る。
- 成果物影響: 該当しない。preserved producer は capture の返値がある場合だけ v5 と `attempt_registry` を同時に組み立てる。新 fixture も同じ `_build_floor_attempt_registry_plan` と `_capture_floor_attempt_registry_prefix` を使用する。
- 最小修正: なし。親で既定 production 3 node を修正後に再走する。
- scope: 内
- 判定: refuted

### D2-R06

- 重大度: なし、静的判定
- file:line: [test_s8b_holdout_freeze.py:1900](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_holdout_freeze.py:1900)、[同:1937](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_holdout_freeze.py:1937)、[同:1964](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_holdout_freeze.py:1964)、[test_s8b_ratified_freeze.py:1535](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:1535)、[同:1562](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:1562)、[同:1582](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:1582)
- 具体的反例候補: M3/M4 が fixture setup の再検査だけを壊す、M6 が診断だけを変える。
- 成果物影響: 構造上は該当しない。capture 後の append に対する prefix 比較は公開 consumer が最初の検証点である。proof mutation は fixture 完成後に注入され、live ledger 負例も公開入口で検査される。M6 では exact-key 検査を外すと validator が未知 key を正規化時に落とすため、reported と independent が一致して余剰 key が誤受理され、公開負例が意味的に反転する。
- 最小修正: なし
- scope: 内
- 判定: refuted。ただし M1〜M6 の `KILLED` は親の実測前なので未確定

## 受理境界の結論

- v4: 明示 legacy schema、registry 不要のまま。ratified 正例は `launch_validate` まで強化されている。
- v5: exact schema の場合だけ v5 top-level keys を選択する。
- 未知 schema: legacy key fallback 後に既存拒否順で拒否する。新 gate はない。
- prefix proof: 7 key の欠損、余剰、値不正を両公開入口から投入する。
- 独立性: freeze、protocol、schedule から expected binding を再導出し、実 registry を replay する。
- append: pinned head は先頭 N 行で比較され、現在末尾との一致を要求しない。
- 凍結23 bytes、`FORMULA_ID`、proof key 集合への変更は差分にない。

実測は行っていません。親記録では holdout v5 正例だけが公開 consumer を通過し、ratified は P-F1 で setup 停止しています。したがって P-F1/P-F2 修正後の焦点走、production 3 node、M1〜M6 が完了するまでは緑とは扱えません。

## 総括

P-F1/P-F2 はともに real で必須修正です。その修正想定では、新規の実在欠陥、shared verifier bypass、fixture 自己照合、append 契約違反、mutation の setup-only kill は確認されませんでした。判定は「追加 blocker なし、既知2件修正後に親実測で受理」です。