## 総括

[対象ファイル](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/orchestrator/tests/test_t1998_stock_inline_pair.py:481) のfixtureと名指しテストだけを修正しました。HEAD全史を探索する `_commit_without_preregistration` を除去し、既存 `_temporary_preregistration_repo` に `committed_missing` を追加しました。現行loaderファイルをそのままコピーして一時Git repoへcommitし、測定commitには事前登録blobを含めず、commit後のworktreeには正規documentを配置する構成です。

対象テストは既存SHA不一致テストと同じ `repository_root` / `repo_root` 引数と `contract_loader_binding._REPO_ROOT` seamを使い、公開consumerを呼びます。拒否条件の期待値は変更していません。

- code: `measurement-preregistration-sha-mismatch`
- field: `preregistration.measurement.sha256`
- arm: `unknown`

単独実走はすべて `python3 tools/run_tests.py -q` 経由で、同ファイルの次のnodeidを個別に指定しました。

- `test_measurement_commit_without_preregistration_blob_is_rejected`
- `test_real_admission_and_receipts_accept_only_the_fixed_pair`
- `test_baseline_and_target_source_identities_may_normally_differ`
- `test_current_preregistration_sha_mismatch_is_rejected`
- `test_measurement_preregistration_sha_mismatch_is_rejected`
- `test_load_preregistration_rejects_worktree_blob_mismatch`
- `test_load_preregistration_returns_document_identity_from_real_head`

全7件とも `qstat -Q preflight rc=1` によりrunnerが終了code 16、`child_started=false` を返しました。したがって**実装済み・未実走**です。同じ理由による不正拒否と既存正例の正当受理は、実走ではまだ確認できていません。構文解析と `git diff --check` は通過しました。

波及先は共有fixtureを利用する現在document不一致、測定blob不一致、worktree/blob不一致の既存テストです。追加引数の既定値は `False` で、既存呼出しの構築手順を維持しています。production・期待値・docsの変更、作業repoのgit add/commit、親treeへの操作は行っていません。今回の単独検査は親の受入全走を代替しません。