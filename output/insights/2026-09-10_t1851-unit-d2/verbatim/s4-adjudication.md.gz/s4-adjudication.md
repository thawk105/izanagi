# T-1851 D2 段4裁定 / plan v2

## 採否

| 所見 | real/refuted と処置 |
|---|---|
| A-01 / B-01 producer 接続の受入漏れ | real、採用。既存 production v5 node 3 本を親の焦点走に加える。consumer fixture単体はlive-prefix consumer検査の証拠とし、本走同等のE2Eとは言わない |
| A-02 genesisだけのprefix | real、採用。捕捉前に正規reservationを作り pinned row_count>=3。捕捉後は別slotを正規append。短縮はreplay可能なgenesisまでとし、prefix-too-shortを公開consumerから確認 |
| B-02 低層appendとmarker bypass | real、採用。core rowを手書きしてJSONLへ入れず、既存registry writerとissued markerによる正規reservationを使う。consumerの実root/protocol/scheduleからplanを導出。manifest/run fieldをproofへ追加する提案はscope外、不採用 |
| A-03 / B-03 未知schemaのcause | planの「従来どおりresult-schema」は誤り、real。提案された診断名の正規化は不採用。下記のlegacy key fallbackで既存の拒否順/causeを維持する |
| B-04 schema=Noneの既存private helper正例 | realだが正例入力や期待値を変更しない。top-level helperはkey検査に留め、既存fallbackを保つのでこの正例を維持できる |
| B-05 schema欠損の裸KeyError | real、採用。getを使う。v5 exact一致だけをv5 key選択へ、それ以外はlegacy key選択にする |
| A-04 7 key全て独立replayという過大説明 | real、採用。shape、artifactとのcross-binding、独立schedule、live prefix、JSONL replayの層を分けて記録 |
| A-05 ratifiedのv4正例がload止まり | real、採用。明示legacyかつproof不在の同じfixtureをlaunch_validateまで通す |
| B-06 ledger負例の過剰決定 | real、採用。消すのは対象registry.jsonlだけ。短縮は完全な有効prefix。appendは別slot。各ケースはfresh fixture |
| 親 M4 setup先落ち | 採用。fixture生成にcapture後appendの旧proof再inspectを埋め込まず、公開consumerを検証点とする。helper単独確認をconsumerのkillと混ぜない |

## 確定実装

編集は6file以内:
- orchestrator/campaign/s8b_holdout_freeze.py
- orchestrator/campaign/s8b_ratified_freeze.py
- orchestrator/campaign/s8b_floor_contract.py (陳腐化コメントのみ)
- orchestrator/tests/s8b_v2_freeze_fixture.py
- orchestrator/tests/test_s8b_holdout_freeze.py
- orchestrator/tests/test_s8b_ratified_freeze.py

consumerのkey選択は、既存s8b_floor_stats.verify_floor_artifactのkey_schema分岐と同じ向きにする。
schemaがRESULT_SCHEMA_V5とexact一致するときだけv5、それ以外はLEGACY_RESULT_SCHEMAをkey契約として使う。
未知schemaを受理するという意味ではない。既存key検査、shared verifierのschema拒否、後段schema比較を保持する。
holdout/ratified後段のschema比較はv4/v5の2世代だけを認め、その他を管理された既存エラーで拒否する。
schema欠損はget経由で既存key検査へ渡す。新しいschema拒否gateやcause正規化を追加しない。
これによりprivate key helperのschema=None正例、v4-shaped unknownのfloor-projection、v5-shaped unknownのschema-keysを維持する。
proofのkey集合・意味・既存shared verifier/inspector/producerを変更しない。RESULT_SCHEMA aliasとFORMULA_IDも変更しない。

fixtureの既定は明示LEGACY_RESULT_SCHEMAでbyte-neutralに保ち、v5を明示指定したときだけ正規writer由来のproofを載せる。
productionと同じ_build_floor_attempt_registry_plan / _capture_floor_attempt_registry_prefixを再利用する。
正規reservationにはissued markerを使い、対象consumerが読むrootと同一のtemp repoに全証拠を置く。
proof捕捉時に最低1 reservation、row_count>=3。後続appendは別slot。row_countとlive行数の差は公開consumer受理後に検算する。
実装が既存部品だけで閉じない場合は不足を報告する。新たなproduction APIやwriter/inspectorを作らない。
良性fixtureに手書きJSONL、検証器/inspector/予約器のstub、偽の成功returnを使わない。
負例のfile破損・短縮はfixtureの専用registryに限定し、外側のhash/承認は正規fixture生成順で束縛して手前の拒否を避ける。

## 受理・拒否

不正拒否: v5 proofのschema/registry_schema不正、7 keyの欠損/余剰/不正値、実registryの不在・改竄・有効prefixへの短縮を両公開consumerから拒否する。
正当受理: 正規writerで作ったv5 proofを両公開consumerが受理し、正当な後続append後も先頭N行のproofを受理し、既存v4をregistry無しで受理する。
通る正例: pinned row_count>=3で正規にcapture後、別slotをappendしたtemp repoからbuild_v2_g1_candidateおよびlaunch_validateが成功する。
7 keyは schema / registry_schema / freeze_sha256 / protocol_sha256 / schedule_sha256 / row_count / chain_head_sha256。
shapeの拒否を全て独立replayの証拠と呼ばない。schedule偽装で独立期待、row/headとfile負例でlive replayを検証する。

## 親の受入

- 既存production node: test_default_production_result_is_v5、test_v5_prefix_covers_every_consumed_non_competing_session、test_finalize_pending_replays_live_v5_prefix。
- 編集test2file単独走、fixture直接consumerのtest_s8b_ratified_verify.py、contract/stats/registryの既存v4/v5/prefix系を参照関係で焦点走へ含める。
- 凍結23件とFORMULA_IDを維持。親が変異、受入全走、既存producerによる所要台帳更新、記録、最終受入、landを行う。
- C3bのregistry実値域は未観測のまま。本waveは新規official本走を含めない。今回の直接指示と新裁定記録の順序差はcarry-assessment.mdへ記録。

## 変異事前登録

mutation-candidates.md の M1〜M6を採用する。実装後にexact anchor一意性と単一理由性を確認し、意味を変えない冗長変異は採用せず根拠を記録する。
M1/M2はそれぞれ異なるconsumer公開入口でv5受理が壊れる変異であり、同一consumerで重複のschema固定変異は数えない。
M3はindependent prefixをreportedへ置換する自己照合、M4は現在末尾比較、M5はlegacy registry要求、M6はproof exact key検査除去。
KILLEDは公開consumerの意味的な受理/拒否が反転した実測に限る。診断文字列だけ、setupだけ、pinだけの赤は数えない。
初回はprobeとして失敗node完全集合を採取し、その集合を事前登録した固定commit本走を行う。既存harnessと使い捨てworktreeを使い新harnessは作らない。

## 範囲境界

凍結bytes、FORMULA_ID、規律2を維持。実装はCodex authorのみ、親はコード/テストを編集しない。
実装用treeは .codex/worktrees/t1851-d2-author、基準7d79909507bb72700dc85933ad37e94608dfbbde。
official床値の再走、allowlist/hold修正、proofへの追加key、汎用gate/台帳/一般化、自己改善実装、次wave、pushは行わない。

