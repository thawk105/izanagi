結論は「新規 real なし、P-F1/P-F2とも closed」です。提示された最終パッチの静的検査と、親提示の修正後実測に基づく判定です。

| 所見 | 状態 | 確認結果 |
|---|---|---|
| P-F1 | closed | admission inspectorへ渡す`session`引数だけを`session-start`と`session`へ射影。元journal、正規writer、issued marker、保存内容は変更していない。両v5正例を含む親実測も通過 |
| P-F2 | closed | v4/v5判定を二つのliteral比較へ変更し、`[]`と`{}`でも`TypeError`にならない。両consumerの4回帰nodeが管理された既存例外で通過 |
| 新規所見 | closed | P-F1/P-F2修正による新たな受理拡大、検査迂回、拒否形式回帰は確認されない |
| partial | なし | 今回の焦点所見について残る部分修正なし |
| regressed | なし | 初稿で確認された保証の後退なし |

確認した不変事項は次のとおりです。

- 認識するschemaは引き続きv4/v5の二つだけ。未知schema向けの新gateやcause正規化は追加されていない。
- v5 exact一致以外をlegacy keyへ送る既存fallbackには未接触。
- private helperの`schema=None`に対するlegacy key選択正例は維持される。公開consumerが後段で未知schemaを拒否する契約との矛盾もない。
- P-F1の射影はadmission inspector専用で、live registryを検査する独立prefix inspectorを弱めていない。
- genuine registry writer、issued marker、production plan/captureの配線には変更がない。
- 凍結23件のbytes、`FORMULA_ID`、proofの7 key集合は不変。
- 新gate、台帳、一般化、後続裁定の先行実装はない。

実測として認定できるのは、親提示の以下の範囲だけです。

- 修正後の両v5正例とunhashable回帰4 node: 6 passed / 50.79s
- 初稿proof/ledger matrixとv4正例: 20 passed / 58.10s
- 既存production 3 node: 3 passed / 27.27s

consumer全体、関連35 file、M1〜M6、受入全走は未実走として留保します。新規official本走もありません。

## 総括

P-F1はinspector入力契約の局所修正、P-F2は非hash schemaの既存管理拒否を回復する局所修正として閉鎖されています。既存のv4 fallback、private helper正例、writer・marker・独立prefix検査を損なう差分はなく、焦点再レビューとして追加 blocker はありません。