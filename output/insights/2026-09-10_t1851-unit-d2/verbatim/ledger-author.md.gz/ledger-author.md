台帳更新済みです。既存producerだけで新規566件を追加し、既存22,483件のentry行は改行を含めbyte exact、値も不変と静的確認しました。更新後は23,049件、削除は0件です。

受領証の`verdict=child-green`、`child_rc=0`を確認しました。`ledger-input.md`、受領証のtested_tip、このtreeのHEADはいずれも`f3067b5cef1d9f72f82d9d3ed3e3c96f8c74a76c`で一致しています。

実行コマンドと入力pathは以下です。両コマンドともrc=0でした。

```bash
python3 tools/update_acceptance_duration_ledger.py --add-only /work/1/SFC/tanab/.izanagi-acceptance-shards/95af7239467bc7ccff1485f45807a5e3/shard-0/junit.xml /work/1/SFC/tanab/.izanagi-acceptance-shards/95af7239467bc7ccff1485f45807a5e3/shard-1/junit.xml

python3 tools/update_acceptance_duration_ledger.py --check --add-only /work/1/SFC/tanab/.izanagi-acceptance-shards/95af7239467bc7ccff1485f45807a5e3/shard-0/junit.xml /work/1/SFC/tanab/.izanagi-acceptance-shards/95af7239467bc7ccff1485f45807a5e3/shard-1/junit.xml
```

更新時は`added=566`、`skipped_existing=22366`。除外はwriter base keyが1件、frozen suiteが139件、frozen removedとfailure/errorは各0件でした。同入力のcheckでは`added=0`、`skipped_existing=22932`、除外140件で、生成bytesと更新済み台帳が一致しました。

JUnitを静的に数え、各shardが11,536件、合計23,072件であることも確認しました。skipは62件と6件、failure/errorは0件です。入力の内訳は既存22,366件＋追加566件＋除外140件＝23,072件と整合します。今回の入力にない既存117件も保持されています。

変更pathは[orchestrator/tests/acceptance_duration_ledger.json](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/orchestrator/tests/acceptance_duration_ledger.json)のみです。producer、test、docsは未変更、git add／commitも未実施です。開始時から存在した未追跡artifactsには触れていません。

波及可能性は台帳を読む受入schedulerの所要時間参照と、そのconsumer testです。共有fixtureやcallerのコード変更はありません。凍結対象の除外規則も変更していません。今回実走したのはproducer更新とcheckであり、全受入、焦点テスト、consumer testは未実走です。親の成功受入結果は入力根拠として扱っています。

## 総括