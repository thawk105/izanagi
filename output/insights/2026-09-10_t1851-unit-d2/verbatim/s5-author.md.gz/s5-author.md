実装済みですが、テスト基盤障害により未実走です。`closed` 扱いにはできません。

変更した6 file:

- [s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/campaign/s8b_holdout_freeze.py)
- [s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/campaign/s8b_ratified_freeze.py)
- [s8b_floor_contract.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/campaign/s8b_floor_contract.py)
- [s8b_v2_freeze_fixture.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/s8b_v2_freeze_fixture.py)
- [test_s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/test_s8b_holdout_freeze.py)
- [test_s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/test_s8b_ratified_freeze.py)

実装内容:

- 両 consumer は v5 exact の場合だけ v5 key 集合を選択し、それ以外は shared verifier と同じ legacy key fallbackを使用。
- 後段では v4/v5だけを受理。未知 schema 専用 gateやcause正規化は追加していない。
- schema欠損は `get` 経由となり、裸の `KeyError` を回避。
- schemaが `None` の既存 private helper 正例は入力を変更せず維持。
- v4 fixtureは明示的に `LEGACY_RESULT_SCHEMA` を使用し、registryなしの公開受理を保持。
- v5 fixtureは専用temp repo内でproduction plan、現行reservation、issued marker、genuine registry writerを使用。捕捉時はreservationを含むrow_count 3以上で、その後に別slotを正当にappend。
- consumer成功後にpinned headとlive行数差を確認する構成。setup内で旧proofを再inspectionしていない。
- 両公開consumerへ、proof 7項目それぞれの欠損・不正値、余剰key、registry欠損・pinned prefix改竄・有効genesisへの短縮を追加。
- `verify_floor_artifact_with_live_admission`、`inspect_attempt_registry_prefix`、reservation/marker機構はstubしていない。

s4所見への対応:

- A-01/B-01のproduction node 3本は変更せず、親の実走対象として残した。
- A-02/B-02のrow_count、別slot append、正規writer、issued markerをfixtureへ反映。
- A-03/B-03/B-04/B-05はlegacy fallbackと既存拒否順を維持。
- A-05は既存v4正例を`launch_validate`まで強化。
- B-06はledger各負例をfresh fixture化し、短縮は完全なgenesis prefix。
- M4 setup先落ちを避け、公開consumerを旧proofの最初の検証点にした。

検証状況:

- `git diff --check`: 成功
- HEAD: `7d79909507bb72700dc85933ad37e94608dfbbde`
- 差分は指定6 fileのみ
- `RESULT_SCHEMA = LEGACY_RESULT_SCHEMA`、`FORMULA_ID=s8b-floor-stats/v2`を維持
- U+0300〜U+036Fなし
- git add、commit、merge、docs編集なし

`tools/run_tests.py`による焦点走、個別v4/v5走、collectionを計5回試行しましたが、すべて `qstat -Q` の `Unknown user-id` でchild未起動、rc=16でした。テストfailureは観測されておらず、緑も申告できません。

所有外の波及・残件:

- `build_production_emitter_g1` / `load_emitter_g1`利用元のoracle report、manifest、driver、verdict、`test_s8b_ratified_verify.py`
- consumer、contract、stats、registryの既存焦点テスト
- 新規38 parameterized nodeid候補のacceptance duration ledger更新と制約meta-test
- production 3 node、変異M1〜M6、全受入、台帳更新、commit、land
- これらは指示どおり親の担当

## 総括

v5のlive prefix proofを両公開consumerへ接続し、v4互換、未知schemaの既存拒否順、正当appendを維持する実装まで完了しました。テストはPegasus dispatch認証障害で一件も起動できていないため、状態は「実装済み・未実走」です。