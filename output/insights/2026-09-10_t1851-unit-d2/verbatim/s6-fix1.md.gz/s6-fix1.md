P-F1 / P-F2 を局所修正しました。post-fix テストは指示どおり親へ委ねており、いずれも `closed` ではありません。

| 所見 | 状態 | 対応 |
|---|---|---|
| P-F1 | partial | full journal の保存を維持し、inspector の `sessions` だけを `session-start` / `session` へ射影 |
| P-F2 | partial | 両 consumer の v4/v5 判定を非hash比較へ変更。`[]` / `{}` の管理された拒否テストを追加 |

変更箇所:

- [s8b_v2_freeze_fixture.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/s8b_v2_freeze_fixture.py:522)
- [s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/campaign/s8b_holdout_freeze.py:1447)
- [s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/campaign/s8b_ratified_freeze.py:2412)
- [test_s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/test_s8b_holdout_freeze.py:1930)
- [test_s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author/orchestrator/tests/test_s8b_ratified_freeze.py:1555)

波及と不変事項:

- 新規回帰は4 node候補。公開入口で consumer 固有例外を確認し、ratified 側は局所比較も直接検査。
- 新gate、cause正規化、shared verifier、FORMULA_ID、凍結bytes、M1〜M6は変更なし。
- 初稿6ファイルのstage状態は維持。fix は5ファイルのunstaged差分。
- `s8b_floor_contract.py`、親tree、既存期待値、未追跡insightsには未接触。
- `git diff --check`、`git diff --cached --check`、禁止Unicode範囲検査は成功。

未実走:

- 正規v5と後続appendの両公開consumer正例
- `[]` / `{}` の新規回帰4 node
- production 3 node、変異、meta-test、受入全走

既報の `qstat` 障害を再試行していないため、緑や回帰なしとは申告しません。親による実走、台帳更新、stage、commit、landが残っています。

## 総括

P-F1とP-F2は実装済みですが、post-fix実走前のため両方とも `partial` です。差分は指定範囲内に閉じ、検査契約や受理集合の追加変更はありません。