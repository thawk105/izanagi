単独段 dispatch: stage=fix; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance5-python-stack.txt — 実際に長時間化しているtest。読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/orchestrator/tests/test_t1998_stock_inline_pair.py — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/docs/dev-wave/workers.md — DW-S05-A/B/CとDW-S06-B。読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger。所有はorchestrator/tests/test_t1998_stock_inline_pair.pyのfixtureと名指しtestだけ。
T1851の保全producer一括統合の受入で、このtestの_commit_without_preregistrationがHEAD全史を走査し、各commitのloader63blobをgit showして30分以上を消費している。
実スタックはtest_measurement_commit_without_preregistration_blob_is_rejected -> _commit_without_preregistration -> _contract_loader_binding -> _git_bytes -> subprocess.communicate。
現在loader63fileが異なるbranchで進化しており「同じloader bytesで事前登録documentが無い祖先」があるというfixture前提は安定しない。
修正は既存_temporary_preregistration_repoを利用した決定的な一時Git fixtureに限定する。現在のloader63fileはそのままコピー/commitし、測定commitにだけpreregistration blobが無い状態を作る。worktreeの現在documentは正規bytesに保つ。
既存test_measurement_preregistration_sha_mismatch_is_rejectedと同じrepository_root/repo_root引数とcontract_loader_binding._REPO_ROOT seamを用い、実consumerを呼ぶ。
期待値・例外code/field/armは変更禁止。measurement-preregistration-sha-mismatch / preregistration.measurement.sha256 / unknownを保持。
不正拒否: 実Git commitに事前登録blobが無い測定を公開consumerが同じ理由で拒否する。
正当受理: 既存の正規blobを持つ測定正例を引き続き通す。
新gate/台帳/timeout/skip/xfail/検査緩和、production変更は禁止。全史探索を一時repo構築へ置換する局所fixture修正だけ。
git add/commit/docs/他fileを編集しない。テストはtools/run_tests.py経由だけ。対象testと既存preregistration正負例を単独実走し、できなければ未実走と報告。
親の受入中のtreeには触れない。末尾に ## 総括 を置き、800 bytes以上で変更・同じ拒否条件の証拠・実走/未実走・波及を報告。日本語、U+0300〜U+036F禁止。
