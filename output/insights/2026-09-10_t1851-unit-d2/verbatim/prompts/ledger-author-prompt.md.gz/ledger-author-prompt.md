単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance-green.json — 親が成功受領証を複製したもの。child-greenを確認。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/ledger-input.md — 実測JUnitの所在。読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/tools/update_acceptance_duration_ledger.py — 既存producer契約。読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/docs/dev-wave/workers.md — DW-S05-A/B/C。読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger。所有はorchestrator/tests/acceptance_duration_ledger.jsonだけ。
parentのmain統合後受入で得たJUnitを入力に、既存producer tools/update_acceptance_duration_ledger.py --add-onlyで台帳を更新するD95 author。
JSONを手書き/手計算/独自mergeしない。既存entryをbyte exactに保ち、新規nodeだけを実測から追加。producerやtestの変更禁止。
入力のsourceは受入tested_tipとこのtreeのHEADが同じか親のledger-input.mdで確認する。不一致なら変更せず報告。
全受入の繰返しや新規テストを作らない。producer --check --add-onlyを同入力で確認し、既存entry不変と件数を静的検算。
git add/commit、docs編集、他file編集はしない。未登録の凍結対象を除外する既存producer規則を緩めない。
結果は入力path、producerの実コマンド/rc/件数、既存entry不変、変更path、未実走を800bytes以上の日本語で報告。
U+0300〜U+036F不使用。末尾に必ず ## 総括。
