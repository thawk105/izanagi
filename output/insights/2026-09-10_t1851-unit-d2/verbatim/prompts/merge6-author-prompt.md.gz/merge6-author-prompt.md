単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge6-input.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/docs/dev-wave/workers.md — DW-S05-A/B/C、読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger、base07ea3ee9ecada28a741fdfd77e81d06e29788b32。所有はtools/check_docs.pyとorchestrator/tests/test_check_docs.pyのみ。
親HEADとincoming main cbba9662948175574905d5e73cb68a942e95b493 の合成をD95 Codex authorとして確認・実装する。
提示patchは親から自動merge結果への候補。git showで両親の変更を確認し、既存T1851側のchecker契約/fixtureとmain側insights日付配置対応を両方保持して適用する。
新gate/一般化/台帳/期待緩和/skipは追加しない。production consumer、他file、docs、親treeへの編集、git add/commitは禁止。
今回は静的合成のみ。親が統合treeで変更testfile全走を行う。差分、両親保持根拠、実装済みと未実走の区別を日本語800bytes以上で報告する。末尾に必ず ## 総括。
