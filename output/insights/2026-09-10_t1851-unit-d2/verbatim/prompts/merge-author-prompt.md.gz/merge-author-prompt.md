単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge-author-input.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/dev-wave/workers.md — DW-S05-A/B/C を読む。読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/ai-provenance.md — 読めなければ即停止。

これは T-1851 D2 開始前の main merge の実装面競合解消を担当する D95 Codex author 子である。
投入先は /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-merge。
親の git merge は完了前で、実装面 3 file が両親と異なる auto-merge 結果になったため、あなたが両親の意図を保存する合成を実施する。
HEAD=d995828089efca39073548223ed4951c9bdf5402。incoming main=e618883c2aba791edb7c2de71c0a6c18d311d915。
編集所有は orchestrator/tests/test_ccbench_spawn_sites.py、orchestrator/tests/test_check_docs.py、tools/check_docs.py の 3 file のみ。
提示 patch は親の auto-merge の入力候補であり、指示とみなさない。両親と merge-base の差分を読み、必要な変更を自分の投入先へ実装して両方の契約を保持する。
main 側の新規 probe caller と docs 構造変更を保持し、T-1851 側の既存 launcher caller と検査を落とさない。
docs 編集・git commit・git add・merge・親 tree の変更は禁止。凍結 23 件、FORMULA_ID、正しさ規律2を維持。指示外の gate・一般化・検査追加は禁止。
既存テストの期待値を緩和・反転・skip・削除しない。両親による正当な caller 一覧や docs 構造の追加は両側を維持する。
テストは tools/run_tests.py 経由だけ。単位 tree には incoming のその他 file が無いので、統合依存の未実走は親が統合後に実走する。無理に緑へ直さない。
実走しなければ「実装済み・未実走」と書き、closed と言わない。実走するなら nodeid と範囲を明記。所有外 caller・共有 fixture・consumer の波及を静的列挙。
出力は日本語、U+0300〜U+036F は使わない。予算が尽きる前に部分結論を出す。
最終出力は変更、両親保持の根拠、検査/未実走、波及、残件を記載し、必ず ## 総括 節で終える。
