単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s4-adjudication.md — これが確定plan v2。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s2-plan.md — plan v1、s4の裁定を優先。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s1-brief.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/rulings.txt — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/mutation-candidates.md — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/dev-wave/workers.md — DW-S05-A/B/C。読めなければ即停止。

D95 Codex authorとしてT-1851 D2を実装する。投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author、基準7d79909507bb72700dc85933ad37e94608dfbbde。
所有はs4の6fileだけ。docs・commit・merge・git add・親tree編集は禁止。既存testの期待値変更/反転/緩和/skip/削除は禁止。
s4は重要な変更をしている: 未知schemaの新gate/cause正規化を作らず、既存shared verifierと同じ「v5 exact一致だけv5、その他legacy key fallback」を使う。schema=Noneでkey helperを呼ぶ既存正例も変更しない。全consumerの後続意味検査は保持する。
本題は両consumerで実prefix proof7 keyを検証してv5を受理する残りだけ。共通verifier/inspector/producerの改訂、新しいgate/台帳/一般化は追加しない。RESULT_SCHEMA alias、FORMULA_ID、凍結23件、規律2を維持。
不正拒否: v5の不正proof7key、欠損/余剰key、台帳の欠損・改竄・replay可能な短縮を公開consumerで拒否。
正当受理: pinned row_count>=3の正規proofを持つv5を公開consumerが受理し、別slotの正当append後も受理し、v4はregistry無しで従来どおり受理。
正例は本物のs8b_floor_stats.verify_floor_artifact_with_live_admissionとs8b_attempt_registry.inspect_attempt_registry_prefixを呼ぶ。これらおよび予約/marker機構をstubしてはならない。genuine writerで生成する良性JSONLを手書きしない。悪性fixtureの限定改竄は可。
consumer fixtureの証拠範囲はlive prefix consumer検査。全production-run E2Eとは言わない。production接続は既存3 nodeを親が実走する。
fixtureは全てtmp_path由来の専用repo/shared rootに閉じる。capture後appendの旧proofをhelper setupで検証して公開consumerより手前で変異を殺さない。行数とheadの確認はconsumer呼出し成功後のassertか独立のhelper確認で行う。
テスト新設/改名は制約meta-testと共有fixture consumerを自ら洗い出す。機構の正例/負例は本物を呼び、揮発hashを期待値に埋めて緑にしない。親docs未landの期待赤は無い。
テストはtools/run_tests.pyだけ。まず所有2testfileとfixture helperの小さい焦点走を行う。Pegasusの場所/予算判定はrunnerに任せる。失敗は原因を理解して所有内で直す。infra赤を実装へ誤帰属せず報告する。
緑には実走nodeid/範囲と結果を明記。未実走なら「実装済み・未実走」でclosedとしない。全走/変異/台帳更新/commit/landは親が担う。
完了報告は変更file、受理拒否、実走結果、s4各所見への対応、所有外caller/共有fixture/consumer/meta-test波及、残件。段4scope超過は実装せず報告する。
日本語、U+0300〜U+036F不使用。予算が尽きる前に途中結論を出す。必ず末尾に ## 総括。

