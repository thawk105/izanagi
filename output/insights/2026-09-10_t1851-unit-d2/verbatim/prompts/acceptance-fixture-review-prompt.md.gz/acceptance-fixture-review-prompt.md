単独段 dispatch: stage=focus; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance5-python-stack.txt — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance-fixture-fix-prompt.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance-fixture-fix.patch — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/acceptance-fixture-fix.md — 読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger。D2一括統合の受入を長時間止めたtest_t1998_stock_inline_pairの局所fixture修正を独立レビューする。
変更は既存一時Git fixtureへのcommitted_missing分岐と名指し負例のみ。旧HEAD全史探索を実在するtemp commitへ替えた。
測定commitのprereg blobのみ欠損、current文書とloader63fileは正規bytes、公開consumerの同じcode/field/armで拒否されるか確認。
production/期待値/テスト集合を弱めず、既存SHA不一致/正例fixtureは既定値不変か。新gate/skip/timeout/台帳を追加していないか。
所見はclosed/partial/regressed表で返し、実在欠陥だけmust-fix、scope外の一般化を足さない。
read-onlyなので実走しない。親が同file全走を実行中。日本語、800 bytes以上、末尾 ## 総括。U+0300〜U+036F禁止。
