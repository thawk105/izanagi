単独段 dispatch: stage=consult; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s1-brief.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s2-plan.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/parent-measurements.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/rulings.txt — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/carry-assessment.md — 読めなければ即停止。

T-1851 D2 段3の独立敵対相談。プランを守らず、親brief/P1/P2と親実測の解釈自体も攻撃する。
レンズ: 整合・実効性。既存fixtureを壊さずv5分岐を導入できるか、real registry fixtureがconsumerの実root/manifest/scheduleと一致するか、stubで機構を飛ばしていないか(F649)、変異の単一理由性(F28)と実装範囲/テスト波及を攻撃。
投入先=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2。今回の直接ユーザー指示はD2完成と保全中producerの一括land、新規official本走なし、凍結23件/FORMULA_ID維持、規律2厳守。別セッションの新裁定がC3c先行/FORMULA後続改版を述べても、本セッションを止める根拠にせず差を明記する。実装しない。
既存 shared live verifier と registry inspector を流用する。新しい gate・checker・台帳・一般化・official本走は提案しない。必要なconsumer本体/fixturesの欠陥に限定し、成果物の受理/拒否/参照を変える理由を示せない仮想リスクはscope外と分類する。
読む主コードはplanの6fileと、その既存live verifier/registry/producer呼出し。実装済み保全prefix producerとの接続を確かめる。
所見は ID、重大度、file:line、実在反例、成果物影響、最小修正、scope内外。親の変異候補が冗長gate/診断文字列だけを殺していないかも検査する。
未知schemaの現在のcauseとplanが述べるcause一致は実コードで確認する。新旧fixture bytesは動的alias固定による実変化がないか確認。
read-onlyではtmp書込不能、静的検査のみでよい。pytest未実走を緑としない。予算が尽きそうなら部分結論を出して終了。日本語、U+0300〜U+036F 不使用。必ず末尾に ## 総括。

