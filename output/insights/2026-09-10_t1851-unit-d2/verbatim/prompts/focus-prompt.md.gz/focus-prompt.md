単独段 dispatch: stage=focus; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s4-adjudication.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s6-review-a.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s6-review-b.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/parent-fix1-findings.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s6-fix1.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/fix1.patch — 読めなければ即停止。

最終差分への焦点再レビュー。投入先=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2。
初稿の独立レビュー2本はP-F1/P-F2以外に新real無し。現在はfix1を親に統合した6fileで、コード/テストは全てCodex author由来。
親のpost-fix実測は両v5正例とunhashable回帰4nodeの6 passed /50.79s。初稿holdoutのproof/ledger matrixとv4正例は20 passed /58.10s。
P-F1=admission inspectorへのsession/session-start射影、P-F2=非hashな2schema比較を実コードで確認し、所見ごとのclosed/partial/regressed表を必ず出す。
未知schemaの新gate/cause正規化を足していないこと、v4 key fallback/private helper None正例が維持されること、genuine writer/marker/独立prefix inspectorの配線を弱めていないことを確認。
既存production3nodeの親実測は3 passed /27.27s。consumer全体、関連35file、変異M1〜M6、受入全走は親が後続で完了させるので未実走を緑としない。
scopeは本題6file。凍結23bytes/FORMULA_ID維持、新規official本走なし。新gate/台帳/一般化、後続裁定の先行実装は提案しない。
read-onlyなので静的検査でよい。pytestを走らせない。予算が尽きる前に途中結論を出す。日本語、U+0300〜U+036F不使用、末尾に ## 総括。

