単独段 dispatch: stage=plan; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s1-brief.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/rulings.txt — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/output/insights/2026-09-09_t1851-unit-c3b-floor-range/next-unit-d2.md — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/dev-wave/workers.md — DW-S02 を読む。読めなければ即停止。

投入先 /work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2 で T-1851 D2 の最小プランを file:line 粒度で起草する。実装しない。
既存 v5 producer/shared live verifier/registry inspector は継承済み。holdout/ratified の入口と実 consumer fixtures の残りを閉じる。schema の受理集合だけを広げず、実台帳 replay と prefix proof 7 key を実証する。凍結23件/FORMULA_ID/規律2/既存v4受理を保持。
親の main merge は所要台帳だけ ours を維持し、3 auto-merge code files は別 D95 author が処理中。本題 consumer と独立している。
既存の fixture helper と genuine registry の構築経路を特定して再利用し、正例/負例/後続appendをどの consumer 公開入口から確かめるか記す。機構の依存先 stub は不可。既存テスト期待の変更は不要を基本とし、必要な schema fixture 分岐は明示する。
DW-O13: official C3b は registry 計測前停止。今回の非性能テスト実証を official 値域と混同しない。新しい predicate を発明しない。
範囲外仮想リスク gate/台帳/一般化/official 本走を足さない。consumer の不正拒否と正当受理の両方を2文に分け、正例を示す。
read-only では tmp 書込不能なので静的検査のみ、pytest 緑は要求しない。親がテスト実走する。予算が尽きそうなら部分結論を出して終える。U+0300〜U+036F 不使用。
出力は日本語。編集対象・実装手順・検証/変異候補・依存/未確定をまとめ、末尾に必ず ## 総括。

