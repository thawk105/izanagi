単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge3-caller-input.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-merge2/docs/dev-wave/workers.md — DW-S05-A/B/C、読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-merge2。所有はorchestrator/tests/test_ccbench_spawn_sites.pyだけ。
親wave HEAD88635567ec22f88632c8064e7bb10e2240643161とincoming main0de9d75ec4ed87298be22633e8f39a475b266fbeのcaller一覧合成をCodex authorとして行う。
このtreeのbaseはc68d08d9e452138c383e9b92076bf91451912700。提示patchはbaseから親の自動merge候補への差分。
両親のcaller行番号変更を確認し、T-1851 floor callerと新T-2514 A1 callerを両方保持する。新gateやテスト期待緩和を追加しない。
同treeの既存tools/check_docs.pyとtest_check_docs.py差分は前回merge2成果で所有外、触らない。その他も編集禁止。
docs/commit/git add/mergeは禁止。今回は静的合成のみで親がテスト実走。未実走と明記しclosedと言わない。
変更/両親根拠/未実走/波及を日本語で短く報告し、末尾に必ず ## 総括。U+0300〜U+036F不使用。
