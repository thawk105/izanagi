単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge3-author-prompt.md — 権限/所有/未実走契約を継承。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge4-caller-input.patch — 今回の追補候補。読めなければ即停止。

同treeの前回merge3成果に対する追補。所有はtest_ccbench_spawn_sites.pyだけ。
親1d9798c0516f8a84416355a75d337d8d5c1ce3baと新main80dbd146e54dbeb568751a7b24b2e75867001d7aの合成。
新mainのt2187 probeにT2417 policy腕経路が入りcaller行が3910/4303へ移った。git showで実calleeを確認し、提示patchの正当な登録追従を実装する。
T1851 floor caller4707/8636、T2514 A1 caller7268はそのまま保持。他file/docs/commit/addを禁止。
新gate/一般化なし。静的確認のみ、親が統合後実走。日本語で短く根拠と未実走を報告、末尾 ## 総括。
