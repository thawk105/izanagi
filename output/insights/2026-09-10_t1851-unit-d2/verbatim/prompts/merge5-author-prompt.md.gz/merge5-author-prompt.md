単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge5-input.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger/docs/dev-wave/workers.md — DW-S05-A/B/C、読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-ledger、base76f1e30a0。所有はorchestrator/tests/test_backoff_extended_sweep.pyだけ。
親76f1e30a0とincoming main07173b447の自動merge合成をD95 authorとして確認・実装する。
main側T2525/T2526のT2418v2 schema/driver宣言/発見経路テストと、親T1851の構造化rep実行失敗fixtureを両方保持する。
提示patchは親HEADから自動merge結果への候補。git showで両親のproduction/test変更を読み、正規のv2期待追従として妥当か確認して適用する。期待値を緩める、skip、削除、新gate・台帳を追加しない。
親の構造化execution_failureへの追従は残す。コード本体・docs・commit・add・他file・親treeの編集は禁止。
今回は静的合成のみ、親が統合treeで同file全走を行う。実装済み・未実走を明記し、両親保持根拠/差分/波及を800bytes以上の日本語で報告。末尾に ## 総括。
