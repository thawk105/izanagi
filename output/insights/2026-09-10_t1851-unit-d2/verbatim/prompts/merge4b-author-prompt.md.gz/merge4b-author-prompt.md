単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge4-author-prompt.md — 所有と制約を継承。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge4-caller-input.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-merge2/output/insights/2026-09-10_t1851-unit-d2/artifacts/t1851-d2/t1851-d2-merge4-author/attempt-0001.output.md — 未受理の前回出力。読めなければ即停止。

前回子はコード編集完了/CLI rc0だが、出力が494 bytesでF43 fragmentによりlauncher未受理となった。
同treeの前回編集を監査し、同じ所有1fileの完成したauthor成果として確認する。正しければ追加変更しない。
未実走を明示し、両親のcaller保持根拠と編集内容、静的検査、波及を具体的に記録。形式を通すための空文は不要だが、最終本文は800 bytes以上とし必ず ## 総括 を含める。
親の統合treeでは同じ候補差分のcallerテスト44 passed/36.07s (991518の次の本走ログmerge4-caller-tests.log)、子の独立実走ではない。
docs/commit/add/他file編集/新gateは禁止。日本語で報告する。
