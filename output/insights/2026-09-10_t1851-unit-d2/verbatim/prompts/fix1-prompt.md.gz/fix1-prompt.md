単独段 dispatch: stage=fix; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/author-prompt.md — DW-S05の全権限/検査契約を継承。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s4-adjudication.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/parent-fix1-findings.md — 今回の修正対象。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s5-author.md — 初稿の結果。読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/dev-wave/workers.md — DW-S05-A/B/C、DW-S06-B。読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-author。初稿6fileは親がstage済みで残している。その内容に対し P-F1 / P-F2 だけを直す。stage変更/commit/docs/親tree編集は禁止。
既存テストの期待値を変更しない。反転・緩和・skip・削除を禁じる。初稿の正例は検査入力を正して成功させ、基盤や検証器をstubしない。
P-F1: helperがratified journal全体をadmission inspectorへ渡している。journal bytesは全体を保持し、inspectorのsessions引数だけsession/session-startの射影へ直す。
P-F2: v4/v5 schema比較にhashを要求しない形を使う。[]/{}も以前どおりcontrolled rejection。新schema gate/cause正規化はしない。
所有は同6fileで、実質helper/consumer2fileと局所回帰testだけ。新gate/台帳/一般化・shared verifier変更・FORMULA_ID変更・凍結23bytes変更なし。
不正拒否: unhashable schemaを管理されたconsumer errorで拒否する。
正当受理: 正規v5+後続appendが両公開consumerを通る。通る正例は既存2つの新規v5公開正例。
子のqstat Unknown user-idは初稿で5回実測済み。ここで同じ基盤試行を何度も繰り返さず、静的に修正し、親が実走する。未実走なら実装済み・未実走、closedではない。
最終報告は所見ごとのclosed/partial/regressed表（実走未了を明記）、変更、波及、未実走、残件。日本語、U+0300〜U+036F不使用、必ず ## 総括。

