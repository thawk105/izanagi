単独段 dispatch: stage=review; sandbox=read-only; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s4-adjudication.md — 確定scope/plan。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/s5-author.md — Codex author初稿報告。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/pre-fix1-integrated.patch — 親へ統合済みの固定初稿snapshot。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/parent-fix1-findings.md — 既知修正中2件。読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/parent-measurements.md — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/rulings.txt — 読めなければ即停止。
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/mutation-candidates.md — 読めなければ即停止。

T-1851 D2 段6の独立敵対レビュー。レンズ: 正しさ・受理境界: 既存v4、v5 exact keys、prefix 7keyの検証層、実registry独立期待、正当append、不正拒否。shared verifierの既存配線を通るか。
投入先=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2。HEAD 7d79909507bb72700dc85933ad37e94608dfbbde上の未commit初稿6fileを検査する。
6fileの実装はD95 Codex authorの出力で、author.patchと一致する形で親が統合した。親のコード編集は無い。commitはfix後に親が実施する。
親treeのこのsnapshotはレビュー終了までコードを変更しない。別の隔離author treeでP-F1/P-F2だけfix中なので、そのtreeを読むな。
既知P-F1=session-invalidのfixture入力違反、P-F2=unhashable schemaのTypeError。既知を主所見として繰り返すだけでなく他の実在欠陥を探す。これらの修正想定で新たな分類変更/弱体化は採用しない。
本体変更は入口2fileと契約コメントだけ。shared verifier/inspector/producer本体は継承のまま。preserved producerのv5出力/captureとの接続も確認するが、今回無変更の広い系へ仮想リスク対策を増やさない。
ユーザー直接指示 D2一括land/新規official本走なし/凍結23bytesとFORMULA_ID維持を優先。C3c/版改訂の後続裁定を今回のstop理由にしない。
s4は未知schemaを新gateで正規化する案を不採用。legacy key fallbackで既存の拒否順とschema=Noneのprivate helper正例を維持する。ここを「直す」提案はしない。
新テストが機構の実体を通るか、mutationがfixture setup/他層/診断だけを殺していないかを重点確認(F649/F28)。
所見ごとにID、重大度、file:line、具体的反例、成果物影響、最小修正、scope内外、real/refutedを示す。新gate/台帳/一般化やproof key追加はscope外。
read-onlyなのでpytestは要求せず静的検査のみ。未実走を緑としない。実測は親が担当。予算が尽きる前に部分結論を出す。
日本語、U+0300〜U+036F不使用。必ず末尾に ## 総括。

