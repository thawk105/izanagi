単独段 dispatch: stage=author; sandbox=workspace-write; parent=/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2
必読事項の射影:
- /work/1/SFC/tanab/dev-wave-jobs/2026-09-10_t1851-unit-d2/merge2-from-main.patch — 読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/dev-wave/workers.md — DW-S05-A/B/C、読めなければ即停止。
- /work/1/SFC/tanab/izanagi/docs/ai-provenance.md — 読めなければ即停止。

投入先=/work/1/SFC/tanab/izanagi/.codex/worktrees/t1851-d2-merge2。main c68d08d9e452138c383e9b92076bf91451912700 をbaseに、保全wave ce2769c329123837f9fda92cac8c90837edabe17 の独自変更とmainの新worker権威を両方保つmerge合成を行うD95 author。
所有はtools/check_docs.pyとorchestrator/tests/test_check_docs.pyの2fileだけ。
patchは親の自動merge候補。両親の差分を読み、mainのgpt-6-astra/medium採用pinとwave側DW-O26 production symbol grep条項の両方を保持する。必要なら候補patchを適用して内容を確認する。
docsを編集せず、git add/commit/mergeは禁止。他file・親treeは触れない。
既存テストの期待値を緩めず、両親が要求する正当なliteral/byte数の合成だけを実装する。新gate・台帳・一般化は追加しない。
テストはtools/run_tests.py経由のみ。今回はmainベースのdocsがwave側DW-O26を持たないので統合依存の赤を緑へ直さない。静的合成を行い、親が統合treeで実走する。
未実走は実装済み・未実走としclosedとは書かない。実走するならnodeid/範囲/rcを明記。所有外docs/caller/共有fixtureの波及を列挙。
日本語、U+0300〜U+036Fは使わない。最終出力に変更・両親保持根拠・検査/未実走・残件、末尾に必ず ## 総括。
