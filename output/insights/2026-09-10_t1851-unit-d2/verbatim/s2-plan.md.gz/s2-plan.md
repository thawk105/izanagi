## 最小プラン

### 編集対象

- [orchestrator/campaign/s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1419)
  - `result["schema"]` を `result_keys_for_mode(..., schema=...)` に渡し、v4 と v5 それぞれの exact key 集合を選ぶ。
  - [同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1439) の v4 固定比較を、既存 `LEGACY_RESULT_SCHEMA` と `RESULT_SCHEMA_V5` のみを認める比較へ置換する。
  - [同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:1622) の `verify_floor_artifact_with_live_admission` 呼出しは維持する。v5 の受理は必ずここで実 registry replay と照合された後に限る。

- [orchestrator/campaign/s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:2352)
  - `_validate_result_top_level_keys` が document の schema を読み、[result_keys_for_mode](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_contract.py:170) へ明示的に渡す。
  - 未知 schema は従来どおり `floor-artifact-invalid`、`cause="result-schema"` で拒否し、エラー分類を変えない。
  - [同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:2393) の `_validate_result` も v4/v5 の exact 2 世代だけを認める。
  - [同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3274) の ratified 固有 key 検査と、[同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3281) の shared live verifier の両方を通す順序は維持する。

- [orchestrator/campaign/s8b_floor_contract.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_contract.py:29)
  - 「現 producer は v4」の陳腐化コメントだけを、registry 有効時は v5、互換既定は v4 alias という現況へ直す。
  - [同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_contract.py:35) の `RESULT_SCHEMA = LEGACY_RESULT_SCHEMA`、`READABLE_RESULT_SCHEMAS`、[同ファイル](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_floor_contract.py:44) の `FORMULA_ID` は変更しない。

- [orchestrator/tests/s8b_v2_freeze_fixture.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:128)
  - `_synthetic_floor_result` の既定 schema を動的な `RESULT_SCHEMA` 参照ではなく `LEGACY_RESULT_SCHEMA` として明示し、既存 fixture を常に v4 に保つ。
  - [candidate_repository](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/s8b_v2_freeze_fixture.py:368) に明示的な `result_schema` 分岐を追加する。既定は v4、v5 指定時だけ `attempt_registry` を追加し、それ以外は拒否する。
  - 同 fixture 内に、production の registry plan、`s8b_attempt_registry.create_attempt_registry`、`capture_attempt_registry_prefix`、`inspect_attempt_registry_prefix` を使う共通 helper を置く。proof は手書きせず、実 JSONL を replay して取得する。
  - proof 捕捉後に別 slot の正当な reservation row を追加し、reported proof の `row_count` より live row 数が大きい状態を作る。既存 [prefix fixture の構築順](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_attempt_registry.py:3707) と [後続 append 正例](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_attempt_registry.py:3760) を踏襲し、verifier や inspector は patch しない。

- [orchestrator/tests/test_s8b_holdout_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_holdout_freeze.py:1811)
  - 既存正例に、result が v4、`attempt_registry` 不在でも `build_v2_g1_candidate` が成功することを明示する。
  - v5 fixture を作り、公開入口 [build_v2_g1_candidate](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_holdout_freeze.py:2016) から、7 key exact proof、実 replay、後続 append が共存した正例を確認する。
  - 同じ公開入口へ、7 key 各値の変異と、registry file の欠損、pinned prefix 改竄、`row_count` 未満への短縮を個別投入し、すべて `FreezeError` になることを確認する。

- [orchestrator/tests/test_s8b_ratified_freeze.py](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:967)
  - `build_production_emitter_g1` に既定 v4 の schema 分岐を追加し、v5 指定時だけ共通 registry fixture の proof を result へ入れてから result hash、generation、approval、pointer を組む。
  - proof 変異 callback は proof 挿入後、result の直列化前だけに適用する。既存 `mutate` の順序と既定 fixture bytes は変えない。
  - [既存 v4 正例](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_ratified_freeze.py:1441) を保持し、v5 は公開入口 [launch_validate](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/campaign/s8b_ratified_freeze.py:3567) から確認する。
  - holdout と同じ 7 key、欠損、改竄、短縮 matrix を `launch_validate` に通す。shared verifier や registry inspector の stub は置かない。

不正拒否: 両 consumer は v5 proof の7項目の不正、registry 欠損、pinned prefix 改竄、pinned `row_count` より短い ledger を公開入口から拒否する。  
正当受理: 両 consumer は実 registry が proof 捕捉後に正当に append されていても、先頭 N 行の head が一致する v5 を受理し、registry を持たない既存 v4 も引き続き受理する。

### 検証と変異候補

親で次を非性能テストとして実走する。

- contract の既存 schema alias、readable set、v4/v5 key-set テスト。
- holdout の既存 v4 正例、新規 v5 正例、7 key と ledger 3種の負例。
- ratified の既存 v4正例、新規 v5正例、同じ負例 matrix。
- 継承済みの real-registry テスト [test_s8b_floor_stats.py:1250](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_floor_stats.py:1250) と prefix append テスト [test_s8b_attempt_registry.py:3760](/work/1/SFC/tanab/izanagi/.claude/worktrees/dev-wave-t1851-unit-c2/orchestrator/tests/test_s8b_attempt_registry.py:3760)。
- 最後に `python3 tools/check_codex_agents.py` と `python3 tools/check_docs.py`。commit 後の provenance 監査は親が行う。

殺すべき変異は、consumer の schema 引数除去、v5 を v4 key 集合で検査する復帰、shared live verifier の迂回、reported proof を独立 proof として流用する自己照合、prefix を現在末尾一致へ変える実装、v4 に registry を要求する遡及変更である。

### 依存と未確定

- `verify_floor_artifact_with_live_admission`、7 key validator、対象世代だけを replay する `inspect_attempt_registry_prefix` は継承物をそのまま使い、編集しない。
- shared fixture の append row は既存 core が生成する正規 row とし、手書き JSON や inspector stub は使わない。author は helper 単体で捕捉 proof と live tail の差、および旧 proof の再 inspection 成功を先に確認する。
- 凍結 manifest 23件、`FORMULA_ID=s8b-floor-stats/v2`、規律2、既存 v4 の受理面には変更を加えない。
- acceptance duration ledger、親 merge の ours 保全、別 D95 author 所有の3 code filesには触れない。
- C3b は registry 計測前停止のままであり、ここで作る値域は pytest 用の非性能 fixture である。official 実測値、追加 gate、追加台帳、一般化、official 本走は主張も実装もしない。
- read-only のため本段では編集も pytest も実行しておらず、緑の申告はしない。仕様上の追加裁定待ちはない。

## 総括

変更は consumer 2本の schema-aware exact key 判定、陳腐化コメント、既存 artifact fixture 2系統への明示的 v5 分岐と実 registry fixture に限定する。v5 は「schema を読める」だけでは通らず、公開 consumer から shared live verifier、対象世代 replay、7 key 独立照合を完走した場合だけ通し、v4 と正当な後続 append は保持する。