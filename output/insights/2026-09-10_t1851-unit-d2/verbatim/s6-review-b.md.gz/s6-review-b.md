結論は、既知のP-F1/P-F2を除き、新規のreal欠陥はありません。固定初稿snapshotに対する静的判定であり、未実走テストを緑とは扱いません。

## 独立所見

### D2-R01

- 重大度: なし
- file:line: `orchestrator/tests/s8b_v2_freeze_fixture.py:370,427,431,437,480,486,505`
- 具体的反例: 手書きJSONLや偽markerならwriter契約を迂回できる。
- 判定: `consume_attempt_ticket`、marker検証、productionと同じplan生成、正規registry作成、reservation writer、productionと同じprefix captureを実際に通しており成立しない。
- 成果物影響: なし。
- 最小修正: 不要。
- scope: 内。
- real/refuted: refuted。

### D2-R02

- 重大度: なし
- file:line: `s8b_v2_freeze_fixture.py:504,505,510`、`test_s8b_holdout_freeze.py:1909`、`test_s8b_ratified_freeze.py:1540`
- 具体的反例: 捕捉後の旧proofをfixture setupが再検査すると、M4が公開consumer到達前に死ぬ。
- 判定: 第一reservation後にcaptureし、別slotをappendした後はlive registryを読むだけ。proof検証は `build_v2_g1_candidate` または `launch_validate` が最初で、row/head確認もconsumer成功後にある。
- 成果物影響: なし。D1337の後続append安定性を公開入口で検査できる。
- 最小修正: 不要。
- scope: 内。
- real/refuted: refuted。

### D2-R03

- 重大度: なし
- file:line: `s8b_v2_freeze_fixture.py:666`、`test_s8b_holdout_freeze.py:1937,1964`、`test_s8b_ratified_freeze.py:1562,1582`
- 具体的反例: 負例が外側hash不一致やfixture setupだけで拒否され、proofまたはlive replayを検査しない。
- 判定: proof変異は正規fixture生成後、外側成果物の直列化前に一項だけ加える。ledger変異は完成済みfresh fixtureの対象registryだけを変更し、その後に公開consumerを呼ぶ。欠損、改竄、短縮は別fixtureで、ledger系は期待reason/causeも固定されている。
- 成果物影響: なし。M3/M6の実際のkill可否は親の変異実測事項として残る。
- 最小修正: 不要。
- scope: 内。
- real/refuted: refuted。

### D2-R04

- 重大度: なし
- file:line: `s8b_v2_freeze_fixture.py:343,539,643`、`test_s8b_holdout_freeze.py:1842`、`test_s8b_ratified_freeze.py:1517,1532`
- 具体的反例: 共有fixtureの既定がv5化し、既存v4成果物にもregistryを要求する。
- 判定: 既定値とsynthetic resultは明示的に `LEGACY_RESULT_SCHEMA`。両既存正例でproof不在を確認し、ratified側は `launch_validate` まで到達させている。
- 成果物影響: 既存v4 bytesと受理面を維持。
- 最小修正: 不要。
- scope: 内。将来のschema alias改訂は今回のstop理由ではない。
- real/refuted: refuted。

### D2-R05

- 重大度: なし
- file:line: `s8b_v2_freeze_fixture.py:437,505`、`s8b_holdout_freeze.py:1427`、`s8b_ratified_freeze.py:2359`
- 具体的反例: consumer fixtureだけが独自proofを作り、保全producerのv5出力と乖離する。
- 判定: fixtureはproducerと同じplan/captureを再利用し、consumer入口はv5 exact時だけv5 key契約を選ぶ。writer、inspector、producer本体には変更がない。これは本走同等E2Eではないため、既存producer 3 nodeの修正後再走は引き続き親の受入条件。
- 成果物影響: 静的な接続欠陥なし。実測留保あり。
- 最小修正: コード修正不要。親が予定済み焦点走を行う。
- scope: コードは内、実走は親担当。
- real/refuted: refuted。

変更は指定6 fileに限定され、production変更は両consumer入口と契約コメントだけです。凍結成果物、FORMULA_ID、proof key追加、新gate、台帳一般化への逸脱はありません。

## 総括

P-F1のsession射影修正とP-F2の非hash型schema修正を前提に、追加修正を要求する新規real所見はありません。fixtureの正規writer接続、公開consumer到達、負例の単一変更、後続append、v4共有fixture保全、scope遵守はいずれも静的に確認できました。最終land可否は、親による修正後の両公開正例、38新規node、既存producer 3 node、M1〜M6の実測結果で確定すべきです。